import { CNMSContextMenuOptions } from "../../src/components/Contextmenu/CNMS_Utils";
import { ContextMenuOptions } from "../../src/components/Contextmenu/utils";

describe("CNMSContextMenuOptions", () => {
  test("contains root and site details menu options", () => {
    expect(CNMSContextMenuOptions.root.map((item) => item.value))
      .toEqual(["cnmsconfiguration", "cnmssitedetails"]);
    expect(CNMSContextMenuOptions.siteDetails.map((item) => item.value))
      .toEqual(["cnmsViewSiteDetails", "cnmsactivealarms"]);
  });
  test("contains expected vehicle actions", () => {
    expect(CNMSContextMenuOptions.vehicle.map((item) => item.value)).toEqual([
      "cnmsTopology", "cnmsInventory", "cnmsViewActiveAlarm",
      "cnmsMoveToMaintenance", "cnmsAddSite", "cnmsViewOnMap", "cnmsDeleteSite",
    ]);
  });
});

describe("ContextMenuOptions", () => {
  test("contains core menu entries and expected submenu actions", () => {
    const values = ContextMenuOptions.map((item) => item.value);
    expect(values).toContain("inventory");
    expect(values).toContain("status");
    expect(values).toContain("deleteDevice");
    const fault = ContextMenuOptions.find((item) => item.value === "fault");
    expect(fault.submenu.map((item) => item.value))
      .toEqual(["viewActiveAlarm", "pollingInterval", "alarmSuppression"]);
  });
  test("all root options have visibility metadata", () => {
    ContextMenuOptions.forEach((item) => {
      expect(item).toHaveProperty("visible");
      expect(item).toHaveProperty("show");
      expect(item).toHaveProperty("previlage");
    });
  });
});
