import React from "react";
import {
  render,
  screen,
  fireEvent,
  waitFor,
  cleanup,
} from "@testing-library/react";
import "@testing-library/jest-dom";
import { jest } from "@jest/globals";

jest.unstable_mockModule("@/RestAPI/api/axiosApicall", () => ({
  SecurityAxios: jest.fn(),
}));

jest.unstable_mockModule("react-redux", () => ({ useSelector: jest.fn() }));

jest.unstable_mockModule("@/utility/encryptLogin", () => ({
  encryptData: jest.fn((value) => `encrypted_${value}`),
}));

jest.unstable_mockModule("@/components/Reusable/Toast/Toast", () => ({
  __esModule: true,
  default: jest.fn(),
}));

jest.unstable_mockModule("@/components/Reusable/Form/MForm", () => ({
  __esModule: true,
  default: ({ title, children }) => (
    <div>
      <h2>{title}</h2>
      {children}
    </div>
  ),
}));

jest.unstable_mockModule("@/components/Reusable/Form/FormField", () => ({
  __esModule: true,
  default: ({ label, value, onChange, disabled, errorMessage, type }) => (
    <div>
      <label htmlFor={label}>{label}</label>
      <input
        id={label}
        aria-label={label}
        value={value ?? ""}
        onChange={onChange}
        disabled={disabled}
        type={type || "text"}
      />
      {errorMessage && <span>{errorMessage}</span>}
    </div>
  ),
}));

jest.unstable_mockModule("@/components/Reusable/Input/MInput", () => ({
  __esModule: true,
  default: ({ label, value, onChange, placeholder, type, disabled }) => (
    <input
      aria-label={label || "Password"}
      placeholder={placeholder}
      value={value}
      onChange={onChange}
      type={type}
      disabled={disabled}
    />
  ),
}));

jest.unstable_mockModule("@/components/Reusable/Button/MButtonPrimary", () => ({
  __esModule: true,
  default: ({ children, onClick, disabled }) => (
    <button onClick={onClick} disabled={disabled}>
      {children}
    </button>
  ),
}));

jest.unstable_mockModule("@/components/Reusable/Dialog/MDialog", () => ({
  __esModule: true,
  default: ({
    open,
    title,
    message,
    onConfirm,
    onClose,
    confirmText,
    confirmDisabled,
    children,
  }) =>
    open ? (
      <div role="dialog">
        <h2>{title}</h2>
        <div>{message}</div>
        {children}
        <button onClick={onConfirm} disabled={confirmDisabled}>
          {confirmText || "Confirm"}
        </button>
        <button onClick={onClose}>Cancel</button>
      </div>
    ) : null,
}));

jest.unstable_mockModule("@/assets/SVGIcons/question_mark.svg", () => ({ __esModule: true, default: "question.svg" }));

// Import mocked modules only after registering the ESM mocks above.
const { default: Securitysettings } = await import(
  "../../src/Pages/Rnmsdashboard/RightUtilityDrawer/components/Security/SecuritySettings"
);
const { SecurityAxios } = await import("@/RestAPI/api/axiosApicall");
const { useSelector } = await import("react-redux");
const { encryptData } = await import("@/utility/encryptLogin");

const mockSecurityData = {
  id: 1,
  isCnms: true,
  defaultPassword: "Test@1234",
  defaultpassword: "Test@1234",
  blockExpiryInHours: 20,
  maxSessionCount: 3,
  noOfPasswordRetries: 5,
  oldPasswordmatch: 3,
  passwordExpiryDays: 60,
  sessionTimeout: 10,
  showPasswordExpiryAlartSecurity: 30,
  passwordRecoveryEmail: "test@example.com",
};

const setupRedux = (isCnms = true) => {
  useSelector.mockImplementation((selector) =>
    selector({
      nodeDetails: { isCnms },
      userSlice: {
        userDetails: {
          data: {
            userName: "admin",
          },
        },
        isReadOnlyMode: false,
        isUserLoggedIn: false,
      },
    })
  );
};

const setupComponent = async (data = mockSecurityData, isCnms = true) => {
  setupRedux(isCnms);

  SecurityAxios.mockResolvedValue({
    status: 200,
    data,
  });

  render(<Securitysettings />);

  await waitFor(() => {
    expect(SecurityAxios).toHaveBeenCalled();
  });

  await screen.findByText("Security Settings");
};

describe("SecuritySettings Component", () => {
  beforeEach(() => {
    jest.clearAllMocks();
    setupRedux(true);
  });

  afterEach(() => {
    cleanup();
  });

  // 1. INITIAL RENDER
  test("renders component and handles loading state", async () => {
    SecurityAxios.mockReturnValue(new Promise(() => {})); // Never resolves to stay in loading
    render(<Securitysettings />);
    expect(screen.getByRole("progressbar")).toBeInTheDocument();
  });

  test("handles empty or null API response", async () => {
    SecurityAxios.mockResolvedValueOnce({ data: null });
    render(<Securitysettings />);
    expect(await screen.findByText("No security settings found")).toBeInTheDocument();
  });

  test("renders disabled fields when isCnms is false (RNMS mode)", async () => {
    setupRedux(false);
    SecurityAxios.mockResolvedValueOnce({ data: mockSecurityData });
    render(<Securitysettings />);
    await waitFor(() => expect(screen.getByLabelText("Password Expiry (Days)")).toBeInTheDocument());
    expect(screen.getByLabelText("Password Expiry (Days)")).toBeDisabled();
  });

  test("validates password complexity and special characters", async () => {
    SecurityAxios.mockResolvedValueOnce({ data: mockSecurityData });
    render(<Securitysettings />);
    await screen.findByText("Security Settings");

    const pwdInput = screen.getByLabelText("Default Password");

    // Test missing special character
    fireEvent.change(pwdInput, { target: { value: "NoSpecial123" } });
    expect(await screen.findByText("Password should contain atleast 1 special character.")).toBeInTheDocument();

    // Test spaces
    fireEvent.change(pwdInput, { target: { value: "Space 123!" } });
    expect(await screen.findByText("Spaces are not allowed")).toBeInTheDocument();

    // Test too short
    fireEvent.change(pwdInput, { target: { value: "Sh@1" } });
    expect(await screen.findByText("Password should be between 8-16 characters.")).toBeInTheDocument();
  });

  test("validates email length and format", async () => {
    SecurityAxios.mockResolvedValueOnce({ data: mockSecurityData });
    render(<Securitysettings />);
    await screen.findByText("Security Settings");

    const emailInput = screen.getByLabelText("Password Recovery Email");

    // Test invalid format
    fireEvent.change(emailInput, { target: { value: "invalid-email" } });
    expect(await screen.findByText("Enter a valid Email")).toBeInTheDocument();

    // Test too short
    fireEvent.change(emailInput, { target: { value: "a@b.c" } }); 
    // Note: length 5 is valid in your code (min 5), so let's test a very short one if logic allows
    fireEvent.change(emailInput, { target: { value: "a@b" } }); 
    // Based on your logic, "a@b" fails emailRegex. 
  });

  test("numeric range validation for various fields", async () => {
    SecurityAxios.mockResolvedValueOnce({ data: mockSecurityData });
    render(<Securitysettings />);
    await screen.findByText("Security Settings");

    const expiryInput = screen.getByLabelText("Password Expiry (Days)");
    fireEvent.change(expiryInput, { target: { value: "10" } }); // Min is 30
    expect(await screen.findByText("Password Expiry Days should be between 30-90.")).toBeInTheDocument();

    const sessionInput = screen.getByLabelText("Session Timeout (Hrs)");
    fireEvent.change(sessionInput, { target: { value: "50" } }); // Max is 48
    expect(await screen.findByText("Session timeout should be between 1-48.")).toBeInTheDocument();
  });

 
  test("renders component successfully", async () => {
    await setupComponent();

    expect(screen.getByText("Security Settings")).toBeInTheDocument();
  });

  test("fetches security settings on mount", async () => {
    await setupComponent();

    expect(SecurityAxios).toHaveBeenCalledTimes(1);
  });

  test("displays all security fields", async () => {
    await setupComponent();

    expect(screen.getByLabelText("Default Password")).toBeInTheDocument();
    expect(screen.getByLabelText("Password Expiry (Days)")).toBeInTheDocument();
    expect(screen.getByLabelText("User Block Duration(Min)")).toBeInTheDocument();
    expect(screen.getByLabelText("Login Retries")).toBeInTheDocument();
    expect(screen.getByLabelText("Session Timeout (Hrs)")).toBeInTheDocument();
    expect(screen.getByLabelText("Old Password Matches")).toBeInTheDocument();
    expect(screen.getByLabelText("Max Session Count")).toBeInTheDocument();
    expect(screen.getByLabelText("Password Recovery Email")).toBeInTheDocument();
  });

  test("shows loader while API request is pending", () => {
    setupRedux(true);
    SecurityAxios.mockReturnValue(new Promise(() => { }));

    render(<Securitysettings />);

    expect(screen.getByRole("progressbar")).toBeInTheDocument();
  });

  test("shows empty message when API returns null", async () => {
    setupRedux(true);
    SecurityAxios.mockResolvedValue({ data: null });

    render(<Securitysettings />);

    expect(
      await screen.findByText("No security settings found")
    ).toBeInTheDocument();
  });

  test("shows empty message when API returns empty object", async () => {
    setupRedux(true);
    SecurityAxios.mockResolvedValue({ data: {} });

    render(<Securitysettings />);

    expect(
      await screen.findByText("No security settings found")
    ).toBeInTheDocument();
  });

  test("handles API fetch failure", async () => {
    setupRedux(true);
    const consoleSpy = jest.spyOn(console, "error").mockImplementation(() => { });

    SecurityAxios.mockRejectedValue(new Error("Network Error"));

    render(<Securitysettings />);

    expect(
      await screen.findByText("No security settings found")
    ).toBeInTheDocument();

    consoleSpy.mockRestore();
  });

  // 2. RNMS MODE

  test("renders disabled fields when CNMS is false", async () => {
    await setupComponent(mockSecurityData, false);

    expect(screen.getByLabelText("Password Expiry (Days)")).toBeDisabled();
    expect(screen.getByLabelText("Login Retries")).toBeDisabled();
  });

  // 3. CNMS MODE

  test("renders editable fields when CNMS is true", async () => {
    await setupComponent();

    expect(screen.getByLabelText("Password Expiry (Days)")).toBeEnabled();
    expect(screen.getByLabelText("Login Retries")).toBeEnabled();
  });

  test("update button is disabled initially", async () => {
    await setupComponent();

    expect(screen.getByRole("button", { name: "Update" })).toBeDisabled();
  });

  // 4. PASSWORD VALIDATION

  test.each([
    ["", "Password is required"],
    ["abc", "Password should be between 8-16 characters."],
    ["abcdefgh1@", "Password should contain atleast 1 uppercase character."],
    ["ABCDEFGH1@", "Password should contain atleast 1 lowercase character."],
    ["Abcdefgh@", "Password should contain atleast 1 number."],
    ["Abcdefg123", "Password should contain atleast 1 special character."],
    ["Abcd 123@", "Spaces are not allowed"],
  ])("validates invalid password: %s", async (password, expectedError) => {
    await setupComponent();

    fireEvent.change(screen.getByLabelText("Default Password"), {
      target: { value: password },
    });

    expect(await screen.findByText(expectedError)).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Update" })).toBeDisabled();
  });

  test("accepts valid password", async () => {
    await setupComponent();

    fireEvent.change(screen.getByLabelText("Default Password"), {
      target: { value: "Strong@123" },
    });

    expect(
      screen.queryByText("Password should contain atleast 1 number.")
    ).not.toBeInTheDocument();

    expect(screen.getByRole("button", { name: "Update" })).toBeEnabled();
  });

  // 5. EMAIL VALIDATION

  test("shows required email validation", async () => {
    await setupComponent();

    fireEvent.change(screen.getByLabelText("Password Recovery Email"), {
      target: { value: "" },
    });

    expect(
      await screen.findByText("Password Recovery Email is required")
    ).toBeInTheDocument();
  });

  test("shows invalid email validation", async () => {
    await setupComponent();

    fireEvent.change(screen.getByLabelText("Password Recovery Email"), {
      target: { value: "invalid-email" },
    });

    expect(
      await screen.findByText("Enter a valid Email")
    ).toBeInTheDocument();
  });

  test("accepts valid email", async () => {
    await setupComponent();

    fireEvent.change(screen.getByLabelText("Password Recovery Email"), {
      target: { value: "new@example.com" },
    });

    expect(screen.getByRole("button", { name: "Update" })).toBeEnabled();
  });

  // 6. NUMERIC VALIDATION

  test.each([
    ["Password Expiry (Days)", "20", "Password Expiry Days should be between 30-90."],
    ["User Block Duration(Min)", "5", "Blocked Duration should be between 10-60."],
    ["Login Retries", "1", "No of retries should be between 3-10."],
    ["Session Timeout (Hrs)", "50", "Session timeout should be between 1-48."],
    ["Old Password Matches", "1", "Old password matches should be between 3-5."],
    ["Max Session Count", "10", "Max Session Count should be between 1-9."],
  ])("validates numeric field %s", async (field, value, expectedError) => {
    await setupComponent();

    fireEvent.change(screen.getByLabelText(field), {
      target: { value },
    });

    expect(await screen.findByText(expectedError)).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Update" })).toBeDisabled();
  });

  test("accepts valid numeric values", async () => {
    await setupComponent();

    fireEvent.change(screen.getByLabelText("Session Timeout (Hrs)"), {
      target: { value: "24" },
    });

    expect(screen.getByRole("button", { name: "Update" })).toBeEnabled();
  });

 

  test("opens confirmation dialog after clicking update", async () => {
    await setupComponent();

    fireEvent.change(screen.getByLabelText("Session Timeout (Hrs)"), {
      target: { value: "24" },
    });

    fireEvent.click(screen.getByRole("button", { name: "Update" }));

    expect(await screen.findByText("Confirm Action")).toBeInTheDocument();
  });

  test("successfully updates security settings", async () => {
    const onSuccess = jest.fn();

    setupRedux(true);
    SecurityAxios
      .mockResolvedValueOnce({ status: 200, data: mockSecurityData })
      .mockResolvedValueOnce({ status: 200, data: {} })
      .mockResolvedValueOnce({ status: 200, data: mockSecurityData });

    render(<Securitysettings onSuccess={onSuccess} />);

    await screen.findByText("Security Settings");

    fireEvent.change(screen.getByLabelText("Session Timeout (Hrs)"), {
      target: { value: "24" },
    });

    fireEvent.click(screen.getByRole("button", { name: "Update" }));

    fireEvent.click(await screen.findByRole("button", { name: "Confirm" }));

    await waitFor(() => {
      expect(onSuccess).toHaveBeenCalledTimes(1);
    });

    expect(SecurityAxios).toHaveBeenCalledWith(
      expect.anything(),
      "post",
      expect.objectContaining({
        sessionTimeout: "24",
      })
    );
  });

  test("handles update API failure", async () => {
    setupRedux(true);

    SecurityAxios
      .mockResolvedValueOnce({ status: 200, data: mockSecurityData })
      .mockRejectedValueOnce(new Error("Update failed"));

    const consoleSpy = jest.spyOn(console, "error").mockImplementation(() => { });

    render(<Securitysettings />);

    await screen.findByText("Security Settings");

    fireEvent.change(screen.getByLabelText("Session Timeout (Hrs)"), {
      target: { value: "24" },
    });

    fireEvent.click(screen.getByRole("button", { name: "Update" }));

    fireEvent.click(await screen.findByRole("button", { name: "Confirm" }));

    await waitFor(() => {
      expect(SecurityAxios).toHaveBeenCalledTimes(2);
    });

    consoleSpy.mockRestore();
  });

});
