import React from "react";
import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { ThemeProvider, createTheme } from "@mui/material/styles";

const mockDispatch = jest.fn();
const mockInventoryAxios = jest.fn();
const mockDispatchContextAction = jest.fn();
let mockState;

jest.mock("react-redux", () => ({
  useDispatch: () => mockDispatch,
  useSelector: (selector) => selector(mockState),
}));

jest.mock("@/RestAPI/api/axiosApicall", () => ({
  InventoryAxios: (...args) => mockInventoryAxios(...args),
}));

jest.mock("@/core/actions/contextActionDispatcher", () => ({
  dispatchContextAction: (...args) => mockDispatchContextAction(...args),
}));

jest.mock("@/components/Reusable/Input/MInput", () => (props) => (
  <input
    aria-label="Search Here"
    placeholder={props.placeholder}
    value={props.value}
    onChange={props.onChange}
  />
));

jest.mock("@/components/Reusable/Scrollbar/ScrollContainer", () => ({ children }) => (
  <div data-testid="scroll-container">{children}</div>
));

jest.mock("@/components/Contextmenu/SubMenu", () => ({ option, isDisabled, onAction }) => (
  <button disabled={isDisabled} onClick={() => onAction(option.value, {})}>
    {option.label}
  </button>
));

jest.mock("@/Pages/Rnmsdashboard/PasswordPromptDialog", () => ({
  open,
  onClose,
  onSubmit,
  resourceName,
  externalError,
}) => open ? (
  <div role="dialog" aria-label="Authentication Required">
    <span>{resourceName}</span>
    {externalError && <span>Incorrect password. Please try again.</span>}
    <button onClick={() => onSubmit("encrypted-test-password")}>Submit password</button>
    <button onClick={onClose}>Cancel password</button>
  </div>
) : null);

import TreeSidebar from "@/Pages/Rnmsdashboard/SidebarTree/TreeSidebar";
import {
  FETCH_ALL_SEGMENTS,
  FETCH_ALL_RESOURCES_WITHIN_SEGMENT_LIST,
  VALIDATE_RESOURCE_PASSWORD,
} from "@/RestAPI/url/endpoint";

const theme = createTheme({
  palette: {
    mode: "light",
    background: { default: "#fff", paper: "#fff", toplogybg: "#fff", tabs: "#fff" },
    text: { primary: "#111" },
    custom: {
      dashboardBorder: "1px solid #ddd",
      icon: { iconFilter: "none" },
    },
  },
});

const baseState = () => ({
  nodeDetails: { isCnms: false, siteDetails: { terminalTypeName: "RNMS Root" } },
  siteDiscovery: { discoveryResults: [] },
  remoteRepDetails: { fetchSiteDetails: [], CnmsDeleteAddSite: {} },
  inventory: {
    resources: [],
    segments: [],
  },
  userSlice: { devicePrivileges: {} },
});

const segment = (segmentId, segmentName) => ({ segmentId, segmentName });
const device = (overrides = {}) => ({
  resourceId: 101,
  resourceName: "Router-01",
  resourceIp: "10.0.0.1",
  status: "Success",
  isDiscovered: true,
  isMaintainance: false,
  imSegmentInfo: { segmentId: 1 },
  imResourceType: {
    resourceTypeId: 7,
    data: {
      inventory: true,
      status: true,
      configured: true,
      fault: true,
      addOrDelete: true,
      linkConfiguration: true,
      view_on_map: true,
      cross_launch: true,
    },
  },
  ...overrides,
});

const renderSidebar = () => render(
  <ThemeProvider theme={theme}>
    <TreeSidebar />
  </ThemeProvider>
);

// The component currently keeps its MUI context menu open when it opens the
// password prompt. MUI consequently marks the app subtree aria-hidden. Query
// the rendered prompt directly so tests can still exercise its controls
// without changing production code.
const getPasswordDialog = () =>
  document.querySelector('[role="dialog"][aria-label="Authentication Required"]');

const getPasswordDialogButton = (label) => {
  const dialog = getPasswordDialog();
  if (!dialog) throw new Error("Authentication prompt is not rendered");
  const button = Array.from(dialog.querySelectorAll("button")).find(
    (candidate) => candidate.textContent.trim() === label
  );
  if (!button) throw new Error(`Password dialog button not found: ${label}`);
  return button;
};

beforeEach(() => {
  mockDispatch.mockClear();
  mockDispatchContextAction.mockClear();
  mockInventoryAxios.mockReset();
  mockInventoryAxios.mockResolvedValue({ data: [] });
  mockState = baseState();
  jest.spyOn(console, "log").mockImplementation(() => {});
  jest.spyOn(console, "error").mockImplementation(() => {});
});

afterEach(() => {
  jest.restoreAllMocks();
});

describe("TreeSidebar – RNMS tree and search", () => {
  test("renders the default root label when terminal nickname is missing", async () => {
    mockState.nodeDetails.siteDetails = null;
    mockState.inventory.segments = [segment(1, "Segment One")];
    renderSidebar();

    expect(screen.getByText("Default Root Name")).toBeInTheDocument();
    expect(screen.getByText("Segment One")).toBeInTheDocument();
    await waitFor(() => expect(mockInventoryAxios).toHaveBeenCalledTimes(2));
  });

  test("fetches segments and resources on mount and dispatches fetched segments", async () => {
    const fetchedSegments = [segment(1, "Segment One")];
    mockInventoryAxios
      .mockResolvedValueOnce({ data: fetchedSegments })
      .mockResolvedValueOnce({ data: [] });

    renderSidebar();

    await waitFor(() => expect(mockDispatch).toHaveBeenCalled());
    expect(mockInventoryAxios).toHaveBeenNthCalledWith(1, FETCH_ALL_SEGMENTS, "get");
    expect(mockInventoryAxios).toHaveBeenNthCalledWith(
      2,
      FETCH_ALL_RESOURCES_WITHIN_SEGMENT_LIST,
      "post",
      [1, 2, 3, 4, 5, 6, 7, 8, 9]
    );
    expect(mockDispatch.mock.calls[0][0]).toMatchObject({ payload: { segments: fetchedSegments } });
  });

  test("logs API errors when initial segment/resource loading fails", async () => {
    const error = new Error("segment service unavailable");
    mockInventoryAxios.mockRejectedValueOnce(error).mockResolvedValueOnce({ data: [] });
    const errorSpy = jest.spyOn(console, "error");

    renderSidebar();

    await waitFor(() => expect(errorSpy).toHaveBeenCalledWith("API Error:", error));
  });

  test("builds and displays segments and devices from Redux inventory data", () => {
    mockState.inventory.segments = [segment(1, "Segment One"), segment(2, "Power Segment")];
    mockState.inventory.resources = [
      device(),
      device({ resourceId: 102, resourceName: "Router-02", imSegmentInfo: { segmentId: 1 } }),
      device({ resourceId: 201, resourceName: "Power-01", imSegmentInfo: { segmentId: 2 } }),
    ];

    renderSidebar();

    expect(screen.getByText("RNMS Root")).toBeInTheDocument();
    expect(screen.getByText("Segment One")).toBeInTheDocument();
    expect(screen.getByText("Power Segment")).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: /Segment One/ }));
    expect(screen.getByText("Router-01")).toBeInTheDocument();
    expect(screen.getByText("Router-02")).toBeInTheDocument();
  });

  test("sorts devices alphabetically within their segment", () => {
    mockState.inventory.segments = [segment(1, "Segment One")];
    mockState.inventory.resources = [
      device({ resourceId: 103, resourceName: "Zebra" }),
      device({ resourceId: 102, resourceName: "Alpha" }),
    ];
    renderSidebar();
    fireEvent.click(screen.getByRole("button", { name: /Segment One/ }));

    const alpha = screen.getByText("Alpha");
    const zebra = screen.getByText("Zebra");
    expect(alpha.compareDocumentPosition(zebra) & Node.DOCUMENT_POSITION_FOLLOWING).toBeTruthy();
  });

  test("filters the tree by the search input and opens matching ancestors", () => {
    mockState.inventory.segments = [segment(1, "Segment One"), segment(2, "Other Segment")];
    mockState.inventory.resources = [device(), device({ resourceId: 202, resourceName: "Other-Router", imSegmentInfo: { segmentId: 2 } })];
    renderSidebar();

    fireEvent.change(screen.getByLabelText("Search Here"), { target: { value: "Router-01" } });

    expect(screen.getByText("Segment One")).toBeInTheDocument();
    expect(screen.getByText("Router-01")).toBeInTheDocument();
    expect(screen.queryByText("Other Segment")).not.toBeInTheDocument();
    expect(screen.queryByText("Other-Router")).not.toBeInTheDocument();
  });

  test("clearing search restores the full tree", () => {
    mockState.inventory.segments = [segment(1, "Segment One"), segment(2, "Other Segment")];
    renderSidebar();
    const search = screen.getByLabelText("Search Here");
    fireEvent.change(search, { target: { value: "Segment One" } });
    expect(screen.queryByText("Other Segment")).not.toBeInTheDocument();
    fireEvent.change(search, { target: { value: "" } });
    expect(screen.getByText("Other Segment")).toBeInTheDocument();
  });

  test("selecting a device dispatches its resource id", () => {
    mockState.inventory.segments = [segment(1, "Segment One")];
    mockState.inventory.resources = [device()];
    renderSidebar();
    fireEvent.click(screen.getByRole("button", { name: /Segment One/ }));
    fireEvent.click(screen.getByRole("button", { name: /Router-01/ }));

    expect(mockDispatch).toHaveBeenCalledWith(expect.objectContaining({ payload: 101 }));
  });

  test("root click expands all tree levels and a subsequent click collapses them", async () => {
    mockState.inventory.segments = [segment(1, "Segment One")];
    mockState.inventory.resources = [device()];
    renderSidebar();
    const root = screen.getByRole("button", { name: /RNMS Root/ });

    fireEvent.click(root); // first click: keep root open
    fireEvent.click(root); // second click: expand all levels
    const router = screen.getByText("Router-01");
    expect(router).toBeInTheDocument();
    expect(router.closest(".MuiCollapse-root")).not.toHaveClass("MuiCollapse-hidden");

    fireEvent.click(root); // third click: collapse the tree
    await waitFor(() => {
      expect(router.closest(".MuiCollapse-root")).toHaveClass("MuiCollapse-hidden");
    });
  });
});

describe("TreeSidebar – CNMS tree", () => {
  const cnmsSite = (overrides = {}) => ({
    siteId: 51,
    siteName: "Alpha Site",
    remoteNumber: "R-51",
    isMaintainance: false,
    imTerminalType: { id: 4, terminalTypeName: "MCT-MK-I" },
    ...overrides,
  });

  test("groups CNMS sites by terminal type and sorts site nodes", () => {
    mockState.nodeDetails.isCnms = true;
    mockState.nodeDetails.siteDetails = { terminalTypeName: "CNMS Root" };
    mockState.remoteRepDetails.fetchSiteDetails = [
      cnmsSite({ siteId: 52, siteName: "Zulu Site", remoteNumber: "R-52" }),
      cnmsSite({ siteId: 51, siteName: "Alpha Site", remoteNumber: "R-51" }),
      cnmsSite({ siteId: 53, siteName: "Bravo Site", remoteNumber: "R-53", imTerminalType: { id: 5, terminalTypeName: "MCT-MK-II" } }),
    ];
    renderSidebar();

    expect(screen.getByText("CNMS Root")).toBeInTheDocument();
    expect(screen.getByText("MCT-MK-I")).toBeInTheDocument();
    expect(screen.getByText("MCT-MK-II")).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "MCT-MK-I MCT-MK-I" }));
    expect(screen.getByText("Alpha Site - R-51")).toBeInTheDocument();
    expect(screen.getByText("Zulu Site - R-52")).toBeInTheDocument();
  });

  test("uses fallback terminal type and fallback site labels for incomplete CNMS data", () => {
    mockState.nodeDetails.isCnms = true;
    mockState.remoteRepDetails.fetchSiteDetails = [
      { siteId: 60, remoteNumber: "R-60", imTerminalType: {} },
    ];
    renderSidebar();
    expect(screen.getByText("Unknown")).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: /Unknown/ }));
    expect(screen.getByText("Unknown - R-60")).toBeInTheDocument();
  });

  test("filters CNMS maintenance context actions according to current maintenance state", () => {
    mockState.nodeDetails.isCnms = true;
    mockState.remoteRepDetails.fetchSiteDetails = [cnmsSite({ isMaintainance: true })];
    renderSidebar();
    fireEvent.click(screen.getByRole("button", { name: /MCT-MK-I/ }));
    const vehicle = screen.getByRole("button", { name: /Alpha Site - R-51/ });
    fireEvent.contextMenu(vehicle, { clientX: 100, clientY: 120 });

    expect(screen.queryByText("Move to Maintenance")).not.toBeInTheDocument();
    expect(screen.getByText("Add Site")).toBeInTheDocument();
  });

  test("uses the matching Redux maintenance update for a CNMS vehicle", () => {
    mockState.nodeDetails.isCnms = true;
    mockState.remoteRepDetails.fetchSiteDetails = [cnmsSite({ isMaintainance: false })];
    mockState.remoteRepDetails.CnmsDeleteAddSite = { siteId: 51, isMaintainance: true };
    renderSidebar();
    fireEvent.click(screen.getByRole("button", { name: /MCT-MK-I/ }));
    fireEvent.contextMenu(screen.getByRole("button", { name: /Alpha Site - R-51/ }), { clientX: 100, clientY: 120 });

    expect(screen.queryByText("Move to Maintenance")).not.toBeInTheDocument();
    expect(screen.getByText("Add Site")).toBeInTheDocument();
  });
});

describe("TreeSidebar – context menu and device authentication", () => {
  const setupDeviceTree = (deviceOverrides = {}, privileges = {}) => {
    mockState.inventory.segments = [segment(1, "Segment One")];
    mockState.inventory.resources = [device(deviceOverrides)];
    mockState.userSlice.devicePrivileges = { 7: { status: true, configured: true, inventory: true, fault: true, add_delete: true, configuration: true, view_on_map: true, cross_launch: true, ...privileges } };
    renderSidebar();
    fireEvent.click(screen.getByRole("button", { name: /Segment One/ }));
    return screen.getByRole("button", { name: /Router-01/ });
  };

  test("shows root context menu actions and dispatches the selected action", () => {
    renderSidebar();
    fireEvent.contextMenu(screen.getByRole("button", { name: /RNMS Root/ }), { clientX: 20, clientY: 30 });
    fireEvent.click(screen.getByText("View RNMS Details"));

    expect(mockDispatchContextAction).toHaveBeenCalledWith(expect.objectContaining({
      action: "rnms",
      source: "tree",
      node: expect.objectContaining({ nodeType: "root", treeNode: expect.objectContaining({ type: "root" }) }),
    }));
  });

  test("shows segment context menu actions", () => {
    mockState.inventory.segments = [segment(1, "Segment One")];
    renderSidebar();
    fireEvent.contextMenu(screen.getByRole("button", { name: /Segment One/ }), { clientX: 20, clientY: 30 });
    expect(screen.getByText("View Details")).toBeInTheDocument();
    expect(screen.getByText("View Active Alarms")).toBeInTheDocument();
  });

  test("filters device context actions by privilege and hardware capability", () => {
    const router = setupDeviceTree(
      { imResourceType: { resourceTypeId: 7, data: { inventory: true, status: false, configured: true } } },
      { status: true, configured: true, inventory: true }
    );
    fireEvent.contextMenu(router, { clientX: 20, clientY: 30 });

    expect(screen.getByText("Inventory")).toBeInTheDocument();
    expect(screen.getAllByText("Configuration").length).toBeGreaterThan(0);
    expect(screen.queryByText("Status")).not.toBeInTheDocument();
  });

  test("hides Add Device for an undiscovered device that is not in maintenance", () => {
    const router = setupDeviceTree({ isDiscovered: false, isMaintainance: false });
    fireEvent.contextMenu(router, { clientX: 20, clientY: 30 });
    expect(screen.queryByRole("menuitem", { name: "Add Device" })).not.toBeInTheDocument();
  });

  test("opens password prompt for protected status actions", () => {
    const router = setupDeviceTree({
      imResourceType: {
        resourceTypeId: 7,
        data: { status: true, authentication: true, authenticationPassword: "stored-hash" },
      },
    });
    fireEvent.contextMenu(router, { clientX: 20, clientY: 30 });
    fireEvent.click(screen.getByText("Status"));

    expect(getPasswordDialog()).not.toBeNull();
    expect(getPasswordDialog().textContent).toContain("Router-01");
    expect(mockDispatchContextAction).not.toHaveBeenCalled();
  });

  test("validates a password and dispatches the pending protected action on success", async () => {
    const router = setupDeviceTree({
      imResourceType: {
        resourceTypeId: 7,
        data: { status: true, authentication: true, authenticationPassword: "stored-hash" },
      },
    });
    mockInventoryAxios.mockResolvedValueOnce({ status: 200, data: { status: 1 } });
    fireEvent.contextMenu(router, { clientX: 20, clientY: 30 });
    fireEvent.click(screen.getByText("Status"));
    fireEvent.click(getPasswordDialogButton("Submit password"));

    await waitFor(() => expect(mockInventoryAxios).toHaveBeenCalledWith(
      VALIDATE_RESOURCE_PASSWORD,
      "post",
      {
        resourceId: 101,
        imResourceType: { data: { authenticationPassword: "encrypted-test-password" } },
      }
    ));
    await waitFor(() => expect(mockDispatchContextAction).toHaveBeenCalledWith(expect.objectContaining({
      action: "status",
      source: "tree",
      node: expect.objectContaining({ password: "encrypted-test-password", nodeType: "device" }),
    })));
    expect(getPasswordDialog()).toBeNull();
  });

  test("shows an authentication error when password validation is rejected", async () => {
    const router = setupDeviceTree({
      imResourceType: {
        resourceTypeId: 7,
        data: { status: true, authentication: true, authenticationPassword: "stored-hash" },
      },
    });
    mockInventoryAxios.mockResolvedValueOnce({ status: 200, data: { status: 0 } });
    fireEvent.contextMenu(router, { clientX: 20, clientY: 30 });
    fireEvent.click(screen.getByText("Status"));
    fireEvent.click(getPasswordDialogButton("Submit password"));

    await waitFor(() => {
      expect(getPasswordDialog()?.textContent).toContain(
        "Incorrect password. Please try again."
      );
    });
    expect(mockDispatchContextAction).not.toHaveBeenCalled();
  });

  test("shows an authentication error when password validation throws", async () => {
    const router = setupDeviceTree({
      imResourceType: {
        resourceTypeId: 7,
        data: { status: true, authentication: true, authenticationPassword: "stored-hash" },
      },
    });
    mockInventoryAxios.mockRejectedValueOnce(new Error("validation unavailable"));
    fireEvent.contextMenu(router, { clientX: 20, clientY: 30 });
    fireEvent.click(screen.getByText("Status"));
    fireEvent.click(getPasswordDialogButton("Submit password"));

    await waitFor(() => {
      expect(getPasswordDialog()?.textContent).toContain(
        "Incorrect password. Please try again."
      );
    });
    expect(mockDispatchContextAction).not.toHaveBeenCalled();
  });

  test("closes the password prompt and clears the pending action", () => {
    const router = setupDeviceTree({
      imResourceType: {
        resourceTypeId: 7,
        data: { status: true, authentication: true, authenticationPassword: "stored-hash" },
      },
    });
    fireEvent.contextMenu(router, { clientX: 20, clientY: 30 });
    fireEvent.click(screen.getByText("Status"));
    fireEvent.click(getPasswordDialogButton("Cancel password"));

    expect(getPasswordDialog()).toBeNull();
  });

  test("executes an unprotected device action immediately", () => {
    const router = setupDeviceTree({
      imResourceType: { resourceTypeId: 7, data: { inventory: true, authentication: false } },
    });
    fireEvent.contextMenu(router, { clientX: 20, clientY: 30 });
    fireEvent.click(screen.getByText("Inventory"));

    expect(mockDispatchContextAction).toHaveBeenCalledWith(expect.objectContaining({
      action: "inventory",
      source: "tree",
      node: expect.objectContaining({ nodeType: "device" }),
    }));
  });
});
