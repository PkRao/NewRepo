import React from "react";
import { jest } from "@jest/globals";
import { render, screen, act } from "@testing-library/react";
import "@testing-library/jest-dom";

const mockUseMap = jest.fn();

jest.unstable_mockModule("react-leaflet", () => ({
  useMap: mockUseMap,
}));

const { LiveCordinates } = await import(
  "@/Pages/CnmsDashboard/CnmsMap/components/LiveCoordinates"
);

describe("LiveCordinates", () => {
  let mapMock;
  let mouseMoveHandler;

  beforeEach(() => {
    jest.clearAllMocks();

    mouseMoveHandler = null;

    mapMock = {
      addEventListener: jest.fn((event, handler) => {
        if (event === "mousemove") {
          mouseMoveHandler = handler;
        }
      }),
    };
  });

  test("renders default coordinates", () => {
    mockUseMap.mockReturnValue(mapMock);

    render(<LiveCordinates />);

    expect(screen.getByTestId("live-coordinates")).toHaveTextContent(
"Latitude: | Longitude:"
    );
  });

  test("registers mousemove event on map", () => {
    mockUseMap.mockReturnValue(mapMock);

    render(<LiveCordinates />);

    expect(mapMock.addEventListener).toHaveBeenCalledWith(
      "mousemove",
      expect.any(Function)
    );
  });

  test("updates coordinates when mouse moves", () => {
    mockUseMap.mockReturnValue(mapMock);

    render(<LiveCordinates />);

    act(() => {
      mouseMoveHandler({
        latlng: {
          lat: 24.531456,
          lng: 72.733345,
        },
      });
    });

    expect(screen.getByTestId("live-coordinates")).toHaveTextContent(
      "Latitude: 24.5315 | Longitude:72.7333"
    );
  });

  test("handles negative coordinates", () => {
    mockUseMap.mockReturnValue(mapMock);

    render(<LiveCordinates />);

    act(() => {
      mouseMoveHandler({
        latlng: {
          lat: -12.34567,
          lng: -45.67891,
        },
      });
    });

    expect(screen.getByTestId("live-coordinates")).toHaveTextContent(
      "Latitude: -12.3457 | Longitude:-45.6789"
    );
  });

  test("does not register listener when map is unavailable", () => {
    mockUseMap.mockReturnValue(null);

    render(<LiveCordinates />);

    expect(screen.getByTestId("live-coordinates")).toBeInTheDocument();
    expect(mapMock.addEventListener).not.toHaveBeenCalled();
  });

  test("registers listener again after coordinates change", () => {
    mockUseMap.mockReturnValue(mapMock);

    render(<LiveCordinates />);

    act(() => {
      mouseMoveHandler({
        latlng: { lat: 10, lng: 20 },
      });
    });

    expect(mapMock.addEventListener).toHaveBeenCalledTimes(2);
  });
});
