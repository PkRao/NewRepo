import reducer, { setTerminalTypesData, clearTerminalTypes } from '../../src/store/features/Cnms/remoteRepDetails/terminalTypeSlice';

describe('terminal type slice', () => {
  test('stores formatted terminal types', () => {
    const log = jest.spyOn(console, 'log').mockImplementation(() => {});
    const values = [{ label: 'MCT MK-I', value: 3, raw: { id: 3 } }];
    expect(reducer(undefined, setTerminalTypesData(values)).terminalTypes).toEqual(values);
    expect(log).toHaveBeenCalled();
    log.mockRestore();
  });
  test('clears terminal types', () => {
    expect(reducer({ terminalTypes: [{ value: 1 }] }, clearTerminalTypes())).toEqual({ terminalTypes: [] });
  });
});
