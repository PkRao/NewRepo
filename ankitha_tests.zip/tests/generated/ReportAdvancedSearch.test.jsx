import React from "react";
import { jest } from "@jest/globals";
import {
  render,
  screen,
  fireEvent,
  waitFor,
} from "@testing-library/react";
import "@testing-library/jest-dom";

// ======================================================
// ESM MOCKS
// ======================================================

jest.unstable_mockModule("@mui/material", () => {
  const actual = jest.requireActual("@mui/material");

  return {
    ...actual,
    useTheme: jest.fn(() => ({
      palette: {
        text: { TitleTextcolor: "#111111" },
        custom: { icon: { iconFilter: "none" } },
      },
    })),
  };
});

jest.unstable_mockModule(
  "@/assets/SVGIcons/Help_Desk_AdvanceSearch.svg",
  () => ({
    default: "adv-search.svg",
  })
);

jest.unstable_mockModule("@/RestAPI/url/endpoint", () => ({
  FETCH_CNMS_ADDRESS_DETAILS: "/api/cnms/address",
  FETCH_UNIQUE_USER_LIST: "/api/users/unique",
  GET_ALL_STATUS: "/api/status/all",
  GET_SEVERITY_KEY_VALUE_PAIR: "/api/severity/kv",
}));

jest.unstable_mockModule("@/RestAPI/api/axiosApicall", () => ({
  FaultAxios: jest.fn(),
  HelpDeskAxios: jest.fn(),
  InventAxios: jest.fn(),
}));

jest.unstable_mockModule(
  "@/components/Reusable/Input/MInput",
  () => ({
    default: ({ type = "text", value, onChange }) =>
      React.createElement("input", {
        type,
        "data-testid": `input-${type}`,
        value: value ?? "",
        onChange,
      }),
  })
);

jest.unstable_mockModule(
  "@/components/Reusable/Select/MSelect",
  () => ({
    default: ({ placeholder, options = [], value, onChange }) =>
      React.createElement(
        "select",
        {
          "aria-label": placeholder,
          value: value?.value ?? "",
          onChange: (e) => {
            const opt = options.find(
              (o) => String(o.value) === e.target.value
            );
            onChange(opt || null);
          },
        },
        React.createElement(
          "option",
          { value: "" },
          placeholder
        ),
        ...options.map((opt) =>
          React.createElement(
            "option",
            {
              key: String(opt.value),
              value: String(opt.value),
            },
            opt.label
          )
        )
      ),
  })
);

jest.unstable_mockModule(
  "@/components/Reusable/Button/MButtonPrimary",
  () => ({
    default: ({ children, onClick }) =>
      React.createElement(
        "button",
        {
          type: "button",
          onClick,
        },
        children
      ),
  })
);

// ======================================================
// DYNAMIC IMPORTS AFTER MOCK REGISTRATION
// ======================================================

const { useTheme } = await import("@mui/material");

const { default: ReportAdvancedSearch } = await import(
  "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/HelpDesk/ReportAdvancedSearch"
);

const {
  FaultAxios,
  HelpDeskAxios,
  InventAxios,
} = await import("@/RestAPI/api/axiosApicall");

// ======================================================
// TEST SUITE
// ======================================================

describe("ReportAdvancedSearch", () => {
  const setFilteredData = jest.fn();

  const sampleRows = [
    {
      id: 1,
      priority: "Major",
      status: "Open",
      hdTicketSubDetails: [
        {
          searchUser: "alice",
          date: "2025-05-10T10:00:00",
        },
      ],
    },
    {
      id: 2,
      priority: "Minor",
      status: "Closed",
      hdTicketSubDetails: [
        {
          searchUser: "bob",
          date: "2025-05-20T14:00:00",
        },
      ],
    },
    {
      id: 3,
      priority: "Major",
      status: "Open",
      hdTicketSubDetails: [
        {
          searchUser: "alice",
          date: "invalid-date",
        },
      ],
    },
    {
      id: 4,
      priority: "Warning",
      status: "Pending",
      hdTicketSubDetails: [],
    },
  ];

  // ======================================================
  // SETUP
  // ======================================================

  beforeEach(() => {
    jest.clearAllMocks();

    useTheme.mockReturnValue({
      palette: {
        text: { TitleTextcolor: "#111111" },
        custom: { icon: { iconFilter: "none" } },
      },
    });

    InventAxios.mockResolvedValue({
      data: {
        address: "10.1.1.5:8786",
      },
    });

    FaultAxios.mockResolvedValue({
      data: {
        1: "Major",
        2: "Minor",
        3: "Warning",
      },
    });

    HelpDeskAxios.mockImplementation((url) => {
      if (url === "/api/status/all") {
        return Promise.resolve({
          data: [
            { id: 1, statusName: "Open" },
            { id: 2, statusName: "Closed" },
            { id: 3, statusName: "Pending" },
          ],
        });
      }

      if (url === "/api/users/unique") {
        return Promise.resolve({
          data: ["alice", "bob"],
        });
      }

      return Promise.resolve({
        data: [],
      });
    });
  });

  // ======================================================
  // INITIAL API FETCH AND ACCORDION
  // ======================================================

  test("fetches host, priorities, statuses, and users on mount and expands accordion", async () => {
    render(
      <ReportAdvancedSearch
        data={sampleRows}
        setFilteredData={setFilteredData}
      />
    );

    await waitFor(() => {
      expect(InventAxios).toHaveBeenCalledWith(
        "/api/cnms/address",
        "get"
      );

      expect(FaultAxios).toHaveBeenCalledWith(
        "/api/severity/kv",
        "get"
      );

      expect(HelpDeskAxios).toHaveBeenCalledWith(
        "/api/status/all",
        "get",
        null,
        null,
        "10.1.1.5:8786"
      );

      expect(HelpDeskAxios).toHaveBeenCalledWith(
        "/api/users/unique",
        "get",
        null,
        null,
        "10.1.1.5:8786"
      );
    });

    fireEvent.click(
      screen.getByText("Advanced Search")
    );

    expect(
      await screen.findByRole("option", {
        name: "Major",
      })
    ).toBeInTheDocument();

    expect(
      screen.getByRole("option", {
        name: "Open",
      })
    ).toBeInTheDocument();

    expect(
      screen.getByRole("option", {
        name: "alice",
      })
    ).toBeInTheDocument();
  });

  // ======================================================
  // FILTERING AND ACTIVE CHIPS
  // ======================================================

  test("applies priority, status, user, and date range filters and manages active chips", async () => {
    render(
      <ReportAdvancedSearch
        data={sampleRows}
        setFilteredData={setFilteredData}
      />
    );

    fireEvent.click(
      screen.getByText("Advanced Search")
    );

    await waitFor(() => {
      expect(
        screen.getByRole("option", {
          name: "Major",
        })
      ).toBeInTheDocument();

      expect(
        screen.getByRole("option", {
          name: "Open",
        })
      ).toBeInTheDocument();

      expect(
        screen.getByRole("option", {
          name: "alice",
        })
      ).toBeInTheDocument();
    });

    const [fromInput, toInput] =
      screen.getAllByTestId("input-date");

    fireEvent.change(fromInput, {
      target: {
        value: "2025-05-01",
      },
    });

    fireEvent.change(toInput, {
      target: {
        value: "2025-05-15",
      },
    });

    fireEvent.change(
      screen.getByLabelText("Priority"),
      {
        target: {
          value: "Major",
        },
      }
    );

    fireEvent.change(
      screen.getByLabelText("Status"),
      {
        target: {
          value: "Open",
        },
      }
    );

    fireEvent.change(
      screen.getByLabelText("User"),
      {
        target: {
          value: "alice",
        },
      }
    );

    expect(
      screen.getByText("Priority: Major")
    ).toBeInTheDocument();

    expect(
      screen.getByText("Status: Open")
    ).toBeInTheDocument();

    expect(
      screen.getByText("User: alice")
    ).toBeInTheDocument();

    expect(
      screen.getByText("From: 2025-05-01")
    ).toBeInTheDocument();

    expect(
      screen.getByText("To: 2025-05-15")
    ).toBeInTheDocument();

    fireEvent.click(
      screen.getByRole("button", {
        name: "Filter",
      })
    );

    expect(setFilteredData).toHaveBeenCalledWith([
      sampleRows[0],
    ]);

    fireEvent.click(
      screen.getByText("Clear All")
    );

    expect(setFilteredData).toHaveBeenLastCalledWith(
      sampleRows
    );

    expect(
      screen.queryByText("Priority: Major")
    ).not.toBeInTheDocument();
  });

  // ======================================================
  // DATE FILTERING
  // ======================================================

  test("handles missing dates and out-of-range dates when filtering by date only", async () => {
    render(
      <ReportAdvancedSearch
        data={sampleRows}
        setFilteredData={setFilteredData}
      />
    );

    fireEvent.click(
      screen.getByText("Advanced Search")
    );

    const [fromInput, toInput] =
      screen.getAllByTestId("input-date");

    fireEvent.change(fromInput, {
      target: {
        value: "2025-05-12",
      },
    });

    fireEvent.change(toInput, {
      target: {
        value: "2025-05-25",
      },
    });

    fireEvent.click(
      screen.getByRole("button", {
        name: "Filter",
      })
    );

    expect(setFilteredData).toHaveBeenCalledWith([
      sampleRows[1],
    ]);
  });

  // ======================================================
  // API OBJECT RESPONSES AND ERROR HANDLING
  // ======================================================

  test("handles object responses for status/user lists and logs errors on API rejection", async () => {
    const logSpy = jest
      .spyOn(console, "log")
      .mockImplementation(() => {});

    InventAxios.mockResolvedValueOnce({
      data: {
        address: "host.local:9090",
      },
    });

    FaultAxios.mockRejectedValueOnce(
      new Error("Priority error")
    );

    HelpDeskAxios.mockImplementation((url) => {
      if (url === "/api/status/all") {
        return Promise.resolve({
          data: {
            a: {
              id: 10,
              statusName: "Resolved",
            },
          },
        });
      }

      if (url === "/api/users/unique") {
        return Promise.resolve({
          data: {
            u1: "charlie",
          },
        });
      }

      return Promise.resolve({
        data: [],
      });
    });

    render(
      <ReportAdvancedSearch
        data={sampleRows}
        setFilteredData={setFilteredData}
      />
    );

    fireEvent.click(
      screen.getByText("Advanced Search")
    );

    await waitFor(() => {
      expect(
        screen.getByRole("option", {
          name: "Resolved",
        })
      ).toBeInTheDocument();

      expect(
        screen.getByRole("option", {
          name: "charlie",
        })
      ).toBeInTheDocument();
    });

    logSpy.mockRestore();
  });
});
