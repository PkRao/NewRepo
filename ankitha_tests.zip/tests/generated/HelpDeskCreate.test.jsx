import React from "react";
import {
  render,
  screen,
  fireEvent,
  waitFor,
  createEvent,
} from "@testing-library/react";
import "@testing-library/jest-dom";

// --------------------------------------------------
// ESM MOCKS
// --------------------------------------------------

jest.unstable_mockModule("react-redux", () => ({
  useSelector: jest.fn(),
}));

jest.unstable_mockModule("@/RestAPI/api/axiosApicall", () => ({
  FaultAxios: jest.fn(),
  HelpDeskAxios: jest.fn(),
  InventAxios: jest.fn(),
  InventoryAxios: jest.fn(),
}));

jest.unstable_mockModule("@/RestAPI/url/endpoint", () => ({
  CREATE_TICKET: "/api/ticket/create",
  FETCH_CNMS_ADDRESS_DETAILS: "/api/cnms/address",
  GET_SEVERITY_KEY_VALUE_PAIR: "/api/severity/kv",
}));

jest.unstable_mockModule("@/RestAPI/url/cnmsEndPoint", () => ({
  FETCH_ALL_SITE_RESOURCE_INFO_BY_SITEID: "/api/cnms/site-resources",
}));

jest.unstable_mockModule("@/components/Reusable/Toast/Toast", () => ({
  default: jest.fn(),
}));

jest.unstable_mockModule("@/assets/SVGIcons/question_mark.svg", () => ({
  default: "confirm-icon.svg",
}));

jest.unstable_mockModule(
  "@/components/Reusable/Button/MButtonPrimary",
  () => ({
    default: function MockMButtonPrimary({
      children,
      onClick,
      disabled,
      ...props
    }) {
      return (
        <button
          type="button"
          onClick={onClick}
          disabled={disabled}
          {...props}
        >
          {children}
        </button>
      );
    },
  })
);

jest.unstable_mockModule("@/components/Reusable/Input/MInput", () => ({
  default: function MockMInput({
    value,
    onChange,
    onKeyDown,
    placeholder,
    disabled,
    ...props
  }) {
    return (
      <input
        value={value ?? ""}
        placeholder={placeholder}
        disabled={disabled}
        onChange={onChange}
        onKeyDown={onKeyDown}
        {...props}
      />
    );
  },
}));

jest.unstable_mockModule("@/components/Reusable/Select/MSelect", () => ({
  default: function MockMSelect({
    placeholder,
    options = [],
    value,
    onChange,
    disabled,
    ...props
  }) {
    return (
      <select
        aria-label={placeholder}
        disabled={disabled}
        value={value?.value ?? ""}
        onChange={(e) => {
          const selected = options.find(
            (opt) => String(opt.value) === e.target.value
          );
          onChange(selected || null);
        }}
        {...props}
      >
        <option value="">{placeholder}</option>

        {options.map((opt) => (
          <option key={String(opt.value)} value={String(opt.value)}>
            {opt.label}
          </option>
        ))}
      </select>
    );
  },
}));

jest.unstable_mockModule("@/components/Reusable/Dialog/MDialog", () => ({
  default: function MockMDialog({
    open,
    title,
    message,
    onConfirm,
    onClose,
    isGrandchildFullScreen,
  }) {
    if (!open) return null;

    return (
      <div
        role="dialog"
        aria-label={title}
        data-fullscreen={String(Boolean(isGrandchildFullScreen))}
      >
        <p>{message}</p>

        <button type="button" onClick={onConfirm}>
          Confirm Create
        </button>

        <button type="button" onClick={onClose}>
          Cancel Create
        </button>
      </div>
    );
  },
}));

// --------------------------------------------------
// DYNAMIC IMPORTS
// --------------------------------------------------

const { useSelector } = await import("react-redux");

const {
  FaultAxios,
  HelpDeskAxios,
  InventAxios,
  InventoryAxios,
} = await import("@/RestAPI/api/axiosApicall");

const { default: Toast } = await import(
  "@/components/Reusable/Toast/Toast"
);

const { default: HelpDeskCreate } = await import(
  "../../src/Pages/Rnmsdashboard/RightUtilityDrawer/components/HelpDesk/HelpDeskCreate"
);

// --------------------------------------------------
// TESTS
// --------------------------------------------------

describe("HelpDeskCreate", () => {
  const onSuccess = jest.fn();
  const onClose = jest.fn();
  const onRefresh = jest.fn();

  const makeState = (overrides = {}) => ({
    nodeDetails: {
      isCnms: false,
      repDetails: {
        id: "REP-1",
        remoteNumber: 5,
        siteName: "CoreSite",
        imTerminalType: {
          id: 2,
          terminalTypeName: "Router",
        },
      },
      ...(overrides.nodeDetails || {}),
    },

    remoteRepDetails: {
      fetchSiteDetails: [
        { siteId: "SITE-101" },
        { siteId: "SITE-202" },
      ],
      ...(overrides.remoteRepDetails || {}),
    },

    topologySlice: {
      allResourceInfo: [
        { resourceId: "RES-1", resourceName: "Switch-A" },
        { resourceId: "RES-2", resourceName: "Firewall-B" },
      ],
      ...(overrides.topologySlice || {}),
    },

    userSlice: {
      userDetails: {
        data: { userName: "ops.user" },
      },
      ...(overrides.userSlice || {}),
    },
  });

  beforeEach(() => {
    jest.clearAllMocks();

    useSelector.mockImplementation((fn) => fn(makeState()));

    FaultAxios.mockResolvedValue({
      data: {
        1: "Minor",
        2: "Major",
      },
    });

    InventAxios.mockResolvedValue({
      data: {
        address: "10.10.10.10",
      },
    });

    InventoryAxios.mockResolvedValue({
      data: [
        {
          resourceId: "CNMS-RES-1",
          resourceName: "CNMS-Node-1",
        },
      ],
    });

    HelpDeskAxios.mockResolvedValue({
      status: 201,
    });
  });

  test("renders non-CNMS defaults, loads severity options, and keeps Create disabled initially", async () => {
    render(
      <HelpDeskCreate
        onSuccess={onSuccess}
        onClose={onClose}
        onRefresh={onRefresh}
      />
    );

    const inputs = screen.getAllByRole("textbox");

    expect(inputs[0]).toHaveValue("Router #005: CoreSite");
    expect(inputs[0]).toBeDisabled();

    expect(inputs[1]).toHaveValue("ops.user");
    expect(inputs[1]).toBeDisabled();

    expect(
      screen.getByText("255 characters remaining")
    ).toBeInTheDocument();

    expect(
      screen.getByRole("button", { name: "Create" })
    ).toBeDisabled();

    await waitFor(() => {
      expect(FaultAxios).toHaveBeenCalledWith(
        "/api/severity/kv",
        "get"
      );

      expect(
        screen.getByRole("option", { name: "Major" })
      ).toBeInTheDocument();
    });
  });

  test("validates alarm details and comment inputs, blocks leading digit on empty input, and enforces limits", async () => {
    render(<HelpDeskCreate onSuccess={onSuccess} />);

    const alarmInput = screen.getByPlaceholderText(
      "Enter alarm configurations..."
    );

    const commentInput = screen.getByPlaceholderText(
      "Enter description comments..."
    );

    // Block first character number on keyDown.
    // Let the actual input become the event target.
    const digitEvent = createEvent.keyDown(alarmInput, {
      key: "5",
      code: "Digit5",
      bubbles: true,
      cancelable: true,
    });

    fireEvent(alarmInput, digitEvent);

    expect(digitEvent.defaultPrevented).toBe(true);

    // Alarm validation: starts with number
    fireEvent.change(alarmInput, {
      target: { value: "1bad" },
    });

    expect(
      screen.getByText("Description cannot start with a number")
    ).toBeInTheDocument();

    // Alarm validation: minimum length
    fireEvent.change(alarmInput, {
      target: { value: "ab" },
    });

    expect(
      screen.getByText("Min 3 Characters required")
    ).toBeInTheDocument();

    // Alarm validation: maximum length
    fireEvent.change(alarmInput, {
      target: { value: "A" + "x".repeat(105) },
    });

    expect(
      screen.getByText("Exceeded Maximum Limit")
    ).toBeInTheDocument();

    // Valid alarm
    fireEvent.change(alarmInput, {
      target: { value: "CPU High" },
    });

    expect(
      screen.queryByText("Exceeded Maximum Limit")
    ).not.toBeInTheDocument();

    // Comment validation: starts with number
    fireEvent.change(commentInput, {
      target: { value: "9start" },
    });

    expect(
      screen.getByText("Description cannot start with a number")
    ).toBeInTheDocument();

    // Comment validation: minimum length
    fireEvent.change(commentInput, {
      target: { value: "ok" },
    });

    expect(
      screen.getByText("Need more than 2 Characters")
    ).toBeInTheDocument();

    // Comment validation: maximum length
    fireEvent.change(commentInput, {
      target: { value: "C" + "y".repeat(260) },
    });

    expect(
      screen.getByText("Exceeded Maximum Limit")
    ).toBeInTheDocument();

    // Valid comment
    fireEvent.change(commentInput, {
      target: { value: "Investigating spike" },
    });

    expect(
      screen.getByText(/characters remaining/)
    ).toBeInTheDocument();
  });

  test("submits non-CNMS ticket successfully and handles dialog cancel/confirm", async () => {
    render(
      <HelpDeskCreate
        onSuccess={onSuccess}
        onClose={onClose}
      />
    );

    await waitFor(() => {
      expect(
        screen.getByRole("option", { name: "Major" })
      ).toBeInTheDocument();
    });

    fireEvent.change(
      screen.getByLabelText("Select Device Name"),
      {
        target: { value: "RES-1" },
      }
    );

    fireEvent.change(
      screen.getByPlaceholderText("Enter alarm configurations..."),
      {
        target: { value: "Interface down" },
      }
    );

    fireEvent.change(
      screen.getByLabelText("Select Severity"),
      {
        target: { value: "2" },
      }
    );

    fireEvent.change(
      screen.getByPlaceholderText("Enter description comments..."),
      {
        target: { value: "Port link flap on eth0/1" },
      }
    );

    const createBtn = screen.getByRole("button", {
      name: "Create",
    });

    expect(createBtn).toBeEnabled();

    fireEvent.click(createBtn);

    expect(
      screen.getByRole("dialog", { name: "Confirm Action" })
    ).toBeInTheDocument();

    fireEvent.click(
      screen.getByRole("button", { name: "Cancel Create" })
    );

    expect(
      screen.queryByRole("dialog")
    ).not.toBeInTheDocument();

    fireEvent.click(createBtn);

    fireEvent.click(
      screen.getByRole("button", { name: "Confirm Create" })
    );

    await waitFor(() => {
      expect(HelpDeskAxios).toHaveBeenCalledWith(
        "/api/ticket/create",
        "post",
        {
          remoteId: "REP-1",
          remoteName: "REP-1",
          nmsType: "2",
          ticketAlarmDetail: "Interface down",
          ticketedDevice: "Switch-A",
          hdTicketPriority: { id: 2 },
          hdTicketSubDetails: [
            {
              loggedinUser: "ops.user",
              statement: "Port link flap on eth0/1",
            },
          ],
        },
        null,
        expect.stringMatching(/^10\.10\.10\.10:(9012|8786)$/)
      );
    });

    expect(Toast).toHaveBeenCalledWith(
      "Success!",
      "Ticket created successfully!",
      "success"
    );

    expect(onSuccess).toHaveBeenCalledTimes(1);
  });

  test("handles CNMS mode: fetches site resources, uses siteId & empty nmsType, and skips InventAxios", async () => {
    useSelector.mockImplementation((fn) =>
      fn(
        makeState({
          nodeDetails: {
            isCnms: true,
            repDetails: null,
          },
        })
      )
    );

    render(
      <HelpDeskCreate
        onSuccess={onSuccess}
        isGrandchildFullScreen={true}
      />
    );

    await waitFor(() => {
      expect(
        screen.getByRole("option", { name: "Major" })
      ).toBeInTheDocument();
    });

    fireEvent.change(
      screen.getByLabelText("Select Site"),
      {
        target: { value: "SITE-101" },
      }
    );

    await waitFor(() => {
      expect(InventoryAxios).toHaveBeenCalledWith(
        "/api/cnms/site-resources/SITE-101",
        "get"
      );

      expect(
        screen.getByRole("option", { name: "CNMS-Node-1" })
      ).toBeInTheDocument();
    });

    fireEvent.change(
      screen.getByLabelText("Select Device Name"),
      {
        target: { value: "CNMS-RES-1" },
      }
    );

    fireEvent.change(
      screen.getByPlaceholderText("Enter alarm configurations..."),
      {
        target: { value: "High latency" },
      }
    );

    fireEvent.change(
      screen.getByLabelText("Select Severity"),
      {
        target: { value: "1" },
      }
    );

    fireEvent.change(
      screen.getByPlaceholderText("Enter description comments..."),
      {
        target: { value: "Checking site link" },
      }
    );

    fireEvent.click(
      screen.getByRole("button", { name: "Create" })
    );

    const dialog = screen.getByRole("dialog", {
      name: "Confirm Action",
    });

    expect(dialog).toHaveAttribute("data-fullscreen", "true");

    fireEvent.click(
      screen.getByRole("button", { name: "Confirm Create" })
    );

    await waitFor(() => {
      expect(InventAxios).not.toHaveBeenCalled();

      expect(HelpDeskAxios).toHaveBeenCalledWith(
        "/api/ticket/create",
        "post",
        {
          remoteId: "SITE-101",
          remoteName: "SITE-101",
          nmsType: "",
          ticketAlarmDetail: "High latency",
          ticketedDevice: "CNMS-Node-1",
          hdTicketPriority: { id: 1 },
          hdTicketSubDetails: [
            {
              loggedinUser: "ops.user",
              statement: "Checking site link",
            },
          ],
        },
        null,
        null
      );
    });
  });

  test("handles non-200/201 response and API failure toasts", async () => {
    const errSpy = jest
      .spyOn(console, "error")
      .mockImplementation(() => {});

    InventAxios.mockResolvedValue({
      data: {
        address: "host.local:9999",
      },
    });

    HelpDeskAxios.mockResolvedValueOnce({
      status: 500,
    });

    render(<HelpDeskCreate onSuccess={onSuccess} />);

    await waitFor(() => {
      expect(
        screen.getByRole("option", { name: "Major" })
      ).toBeInTheDocument();
    });

    fireEvent.change(
      screen.getByLabelText("Select Device Name"),
      {
        target: { value: "RES-1" },
      }
    );

    fireEvent.change(
      screen.getByPlaceholderText("Enter alarm configurations..."),
      {
        target: { value: "Alarm text" },
      }
    );

    fireEvent.change(
      screen.getByLabelText("Select Severity"),
      {
        target: { value: "1" },
      }
    );

    fireEvent.change(
      screen.getByPlaceholderText("Enter description comments..."),
      {
        target: { value: "Comment text" },
      }
    );

    fireEvent.click(
      screen.getByRole("button", { name: "Create" })
    );

    fireEvent.click(
      screen.getByRole("button", { name: "Confirm Create" })
    );

    await waitFor(() => {
      expect(Toast).toHaveBeenCalledWith(
        "Error!",
        "Failed to save",
        "error"
      );
    });

    // Thrown error branch
    HelpDeskAxios.mockRejectedValueOnce(
      new Error("Network down")
    );

    fireEvent.click(
      screen.getByRole("button", { name: "Create" })
    );

    fireEvent.click(
      screen.getByRole("button", { name: "Confirm Create" })
    );

    await waitFor(() => {
      expect(Toast).toHaveBeenCalledWith(
        "Error!",
        "Failed to save details",
        "error"
      );
    });

    expect(onSuccess).not.toHaveBeenCalled();

    errSpy.mockRestore();
  });
});
