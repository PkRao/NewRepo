import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import "@testing-library/jest-dom";
import { InfoTable } from "../../src/Pages/CnmsDashboard/CnmsMap/components/InfoTable";

describe("InfoTable", () => {
  const onClose = jest.fn();

  const availableParams = [
    { key: "id", label: "ID", checked: true },
    { key: "name", label: "Name", checked: true },
    { key: "unitName", label: "Unit Name", checked: true },
    { key: "longitude", label: "Longitude", checked: true },
    { key: "latitude", label: "Latitude", checked: true },
    { key: "status", label: "Status", checked: true },
    { key: "unknown", label: "Unknown", checked: true },
    { key: "hidden", label: "Hidden", checked: false },
  ];

  beforeEach(() => {
    jest.clearAllMocks();
    jest.spyOn(console, "log").mockImplementation(() => {});
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  test("renders nothing when selectedEntity is null", () => {
    const { container } = render(
      <InfoTable
        selectedEntity={null}
        availableParams={availableParams}
        onClose={onClose}
      />
    );

    expect(container.firstChild).toBeNull();
  });

  test("renders CNMS details correctly", () => {
    const selectedEntity = {
      type: "CNMS",
      data: {
        id: "CNMS_001",
        siteName: "Mount Abu",
        longitude: 72.7333,
        latitude: 24.5314,
        isActive: true,
        isMaintainance: false,
        resRepDetails: [{ unit: "805SU" }],
      },
    };

    render(
      <InfoTable
        selectedEntity={selectedEntity}
        availableParams={availableParams}
        onClose={onClose}
      />
    );

    expect(screen.getByText("CNMS Details")).toBeInTheDocument();
    expect(screen.getByText("CNMS_001")).toBeInTheDocument();
    expect(screen.getByText("Mount Abu")).toBeInTheDocument();
    expect(screen.getByText("805SU")).toBeInTheDocument();
    expect(screen.getByText("72.7333")).toBeInTheDocument();
    expect(screen.getByText("24.5314")).toBeInTheDocument();
    expect(screen.getByText("OPERATIONAL")).toBeInTheDocument();

    expect(screen.queryByText("Hidden:")).not.toBeInTheDocument();
  });

  test("renders Site details correctly", () => {
    const selectedEntity = {
      type: "Site",
      data: {
        siteId: "MCT_001",
        siteName: "Bangalore",
        siteNickName: "BNG",
        longitude: 80.678,
        latitude: 12.678,
        healthStatus: { id: 1, value: "UP" },
        isMaintainance: false,
      },
    };

    render(
      <InfoTable
        selectedEntity={selectedEntity}
        availableParams={availableParams}
        onClose={onClose}
      />
    );

    expect(screen.getByText("Site Details")).toBeInTheDocument();
    expect(screen.getByText("MCT_001")).toBeInTheDocument();
    expect(screen.getByText("Bangalore")).toBeInTheDocument();
    expect(screen.getByText("BNG")).toBeInTheDocument();
    expect(screen.getByText("80.678")).toBeInTheDocument();
    expect(screen.getByText("12.678")).toBeInTheDocument();
    expect(screen.getByText("OPERATIONAL")).toBeInTheDocument();
  });

  test("uses siteId when id is unavailable", () => {
    const selectedEntity = {
      type: "Site",
      data: { siteId: "SITE_123" },
    };

    render(
      <InfoTable
        selectedEntity={selectedEntity}
        availableParams={availableParams}
        onClose={onClose}
      />
    );

    expect(screen.getByText("SITE_123")).toBeInTheDocument();
  });

  test("uses N/A for missing values", () => {
    const selectedEntity = {
      type: "Site",
      data: {},
    };

    render(
      <InfoTable
        selectedEntity={selectedEntity}
        availableParams={availableParams}
        onClose={onClose}
      />
    );

    expect(screen.getAllByText("N/A").length).toBeGreaterThanOrEqual(5);
  });

  test("handles missing CNMS representative details", () => {
    const selectedEntity = {
      type: "CNMS",
      data: {
        id: "CNMS_002",
        resRepDetails: [],
      },
    };

    render(
      <InfoTable
        selectedEntity={selectedEntity}
        availableParams={availableParams}
        onClose={onClose}
      />
    );

    const missingValues = screen.getAllByText("N/A");

    expect(missingValues.length).toBe(5);
    expect(screen.getByText("CNMS_002")).toBeInTheDocument();
  });

  test("handles missing CNMS representative array", () => {
    const selectedEntity = {
      type: "CNMS",
      data: {},
    };

    render(
      <InfoTable
        selectedEntity={selectedEntity}
        availableParams={availableParams}
        onClose={onClose}
      />
    );

    expect(screen.getAllByText("N/A").length).toBeGreaterThan(0);
  });

  test("shows NON-OPERATIONAL for inactive CNMS", () => {
    const selectedEntity = {
      type: "CNMS",
      data: {
        id: "CNMS_003",
        isActive: false,
      },
    };

    render(
      <InfoTable
        selectedEntity={selectedEntity}
        availableParams={availableParams}
        onClose={onClose}
      />
    );

    expect(screen.getByText("NON-OPERATIONAL")).toBeInTheDocument();
  });

  test("shows NON-OPERATIONAL for Site with health status other than 1", () => {
    const selectedEntity = {
      type: "Site",
      data: {
        siteId: "SITE_002",
        healthStatus: { id: 0 },
      },
    };

    render(
      <InfoTable
        selectedEntity={selectedEntity}
        availableParams={availableParams}
        onClose={onClose}
      />
    );

    expect(screen.getByText("NON-OPERATIONAL")).toBeInTheDocument();
  });

  test("shows Maintenance when isMaintainance is true", () => {
    const selectedEntity = {
      type: "Site",
      data: {
        siteId: "SITE_003",
        isMaintainance: true,
        healthStatus: { id: 1 },
      },
    };

    render(
      <InfoTable
        selectedEntity={selectedEntity}
        availableParams={availableParams}
        onClose={onClose}
      />
    );

    expect(screen.getByText("Maintenance")).toBeInTheDocument();
  });

  test("handles missing healthStatus for Site", () => {
    const selectedEntity = {
      type: "Site",
      data: { siteId: "SITE_004" },
    };

    render(
      <InfoTable
        selectedEntity={selectedEntity}
        availableParams={availableParams}
        onClose={onClose}
      />
    );

    expect(screen.getByText("NON-OPERATIONAL")).toBeInTheDocument();
  });

  test("renders N/A for unsupported parameter keys", () => {
    const selectedEntity = {
      type: "Site",
      data: {},
    };

    render(
      <InfoTable
        selectedEntity={selectedEntity}
        availableParams={[
          { key: "invalid", label: "Invalid", checked: true },
        ]}
        onClose={onClose}
      />
    );

    expect(screen.getByText("N/A")).toBeInTheDocument();
  });

  test("renders zero coordinates instead of N/A", () => {
    const selectedEntity = {
      type: "Site",
      data: {
        longitude: 0,
        latitude: 0,
      },
    };

    render(
      <InfoTable
        selectedEntity={selectedEntity}
        availableParams={[
          { key: "longitude", label: "Longitude", checked: true },
          { key: "latitude", label: "Latitude", checked: true },
        ]}
        onClose={onClose}
      />
    );

    expect(screen.getAllByText("0").length).toBe(2);
  });

  test("calls onClose when close button is clicked", () => {
    render(
      <InfoTable
        selectedEntity={{ type: "Site", data: {} }}
        availableParams={availableParams}
        onClose={onClose}
      />
    );

    fireEvent.click(screen.getByRole("button"));

    expect(onClose).toHaveBeenCalledTimes(1);
  });

  test("handles empty availableParams", () => {
    render(
      <InfoTable
        selectedEntity={{ type: "Site", data: {} }}
        availableParams={[]}
        onClose={onClose}
      />
    );

    expect(screen.getByText("Site Details")).toBeInTheDocument();
  });
});
