import { formatIPMask, isValidIpV4 } from "../../src/components/Dialogs/deviceMaintenance/utils";

describe("formatIPMask", () => {
  test("formats digits into four padded octets", () => {
    expect(formatIPMask("19216811")).toBe("192.168.11_.___");
    expect(formatIPMask("192.168.1.10")).toBe("192.168.110.___");
  });
  test("strips non-digits and limits to twelve digits", () => {
    expect(formatIPMask("abc192.168.1.10xyz")).toBe("192.168.110.___");
    expect(formatIPMask("123456789012345")).toBe("123.456.789.012");
  });
  test("handles empty and missing values", () => {
    expect(formatIPMask("")).toBe("___.___.___.___");
    expect(formatIPMask()).toBe("___.___.___.___");
  });
});

describe("isValidIpV4", () => {
  test.each(["192.168.1.1", "10.0.0.1", "255.255.255.255", "0.0.0.0"])(
    "accepts valid IPv4 address %s", (ip) => expect(isValidIpV4(ip)).toBe(true)
  );
  test.each(["256.1.1.1", "192.168.1", "abc", "1.2.3.999"])(
    "rejects invalid IPv4 address %s", (ip) => expect(isValidIpV4(ip)).toBe(false)
  );
  test("accepts underscore placeholders after removing them", () => {
    expect(isValidIpV4("192.168.1.1___")).toBe(true);
  });
});
