import React from "react";
import { jest } from "@jest/globals";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import "@testing-library/jest-dom";



// ---------------- MOCKS ----------------

jest.unstable_mockModule("@/RestAPI/api/axiosApicall", () => ({
  ConfigurationAxios: jest.fn(),
}));

jest.unstable_mockModule(
  "@/assets/SVGIcons/Confirmation_icon.svg",
  () => ({
    __esModule: true,
    default: "Confirmation_icon.svg",
  })
);

jest.unstable_mockModule("@/components/Reusable/Toast/Toast", () => ({
  __esModule: true,
  default: jest.fn(),
}));

jest.unstable_mockModule("@/components/Reusable/Form/MForm", () => ({
  __esModule: true,
  default: ({ title, children }) => (
    <div>
      <h2>{title}</h2>
      {children}
    </div>
  ),
}));

jest.unstable_mockModule("@/components/Reusable/Input/MInput", () => ({
  __esModule: true,
  default: ({
    value,
    onChange,
    disabled,
    placeholder,
    type = "text",
    error,
    helperText,
  }) => (
    <div>
      <input
        type={type}
        value={value}
        onChange={onChange}
        disabled={disabled}
        placeholder={placeholder}
        aria-invalid={error || false}
      />
      {helperText && <span>{helperText}</span>}
    </div>
  ),
}));

jest.unstable_mockModule("@/components/Reusable/Checkbox/MCheckbox", () => ({
  __esModule: true,
  default: ({ label, checked, onChange }) => (
    <label>
      <input type="checkbox" checked={checked} onChange={onChange} />
      {label}
    </label>
  ),
}));

jest.unstable_mockModule("@/components/Switch/CustomSwitch", () => ({
  __esModule: true,
  default: ({ checked, onChange }) => (
    <input
      type="checkbox"
      aria-label="Modify"
      checked={checked}
      onChange={onChange}
    />
  ),
}));

jest.unstable_mockModule("@/components/Reusable/Button/MButtonPrimary", () => ({
  __esModule: true,
  default: ({ children, onClick, disabled, ...props }) => (
    <button onClick={onClick} disabled={disabled} type="button" {...props}>
      {children}
    </button>
  ),
}));

jest.unstable_mockModule("@/components/Reusable/Dialog/MDialog", () => ({
  __esModule: true,
  default: ({ open, onClose, onConfirm, title, message }) =>
    open ? (
      <div data-testid="confirmation-dialog">
        <h3>{title}</h3>
        <p>{message}</p>
        <button onClick={onClose}>Cancel</button>
        <button onClick={onConfirm}>Confirm</button>
      </div>
    ) : null,
}));

// Import mocked modules only after registering the ESM mocks above.
const { default: LdapConfiguration } = await import(
  "@/Pages/CnmsDashboard/CnmsrightutilityDrawer/CnmsConfiguration/LdapConfiguration/LdapConfiguration"
);
const { ConfigurationAxios } = await import("@/RestAPI/api/axiosApicall");
const { default: Toast } = await import("@/components/Reusable/Toast/Toast");
const { GET_LDAP_CONFIG, SAVE_LDAP_CONFIG } = await import(
  "@/RestAPI/url/cnmsEndPoint"
);

// ---------------- TEST DATA ----------------

const mockLdapResponse = {
  connection_url: "ldaps://iaf.ldap:636",
  user_domain: ",ou=users,dc=bel,dc=com",
  ca_file_path: "/etc/cafiles/cafile.pem",
  bindUserName: "admin_user",
  bindPassword: "Admin1234",
  bind_credentials_enabled: true,
};

const renderComponent = () => {
  return render(<LdapConfiguration isChildFullScreen={false} />);
};

const enableModifyMode = () => {
  fireEvent.click(screen.getByLabelText("Modify"));
};

const fillRequiredFields = async () => {
  // Wait for the asynchronous GET request to populate controlled form state.
  // Otherwise the GET response can overwrite edits made immediately after render.
  await waitFor(() => {
    expect(screen.getByPlaceholderText("ldaps://iaf.ldap")).toHaveValue(
      "ldaps://iaf.ldap"
    );
    expect(screen.getByPlaceholderText("636")).toHaveValue(636);
  });

  fireEvent.change(screen.getByPlaceholderText("ldaps://iaf.ldap"), {
    target: { value: "ldaps://new.ldap" },
  });

  fireEvent.change(screen.getByPlaceholderText("636"), {
    target: { value: "636" },
  });

  fireEvent.change(screen.getByPlaceholderText("ou=users,dc=bel,dc=com"), {
    target: { value: "ou=users,dc=example,dc=com" },
  });

  fireEvent.change(screen.getByPlaceholderText("/etc/cafiles/cafile.pem"), {
    target: { value: "/etc/new/cafile.pem" },
  });
};

// ---------------- TESTS ----------------

describe("LdapConfiguration Component", () => {
  beforeEach(() => {
    jest.clearAllMocks();

    ConfigurationAxios.mockResolvedValue({
      data: mockLdapResponse,
    });
  });

  // 1. INITIAL RENDERING

  describe("Initial Rendering", () => {
    test("renders LDAP Configuration heading", async () => {
      renderComponent();

      expect(screen.getByText("LDAP Configuration")).toBeInTheDocument();

      await waitFor(() => {
        expect(ConfigurationAxios).toHaveBeenCalledWith(GET_LDAP_CONFIG, "get");
      });
    });

    test("renders View and Modify controls", async () => {
      renderComponent();

      expect(screen.getByText("View")).toBeInTheDocument();
      expect(screen.getByText("Modify")).toBeInTheDocument();

      await waitFor(() => {
        expect(ConfigurationAxios).toHaveBeenCalled();
      });
    });

    test("fields are readonly by default", async () => {
      renderComponent();

      await waitFor(() => {
        expect(screen.getByPlaceholderText("ldaps://iaf.ldap")).toBeDisabled();
      });

      expect(screen.getByPlaceholderText("636")).toBeDisabled();

      expect(screen.queryByText("Save")).not.toBeInTheDocument();
    });
  });

  // 2. GET LDAP CONFIGURATION

  describe("GET LDAP Configuration", () => {
    test("fetches LDAP configuration successfully", async () => {
      renderComponent();

      await waitFor(() => {
        expect(ConfigurationAxios).toHaveBeenCalledWith(GET_LDAP_CONFIG, "get");
      });
    });

    test("extracts URL, port and domain correctly", async () => {
      renderComponent();

      await waitFor(() => {
        expect(screen.getByPlaceholderText("ldaps://iaf.ldap")).toHaveValue(
          "ldaps://iaf.ldap"
        );

        expect(screen.getByPlaceholderText("636")).toHaveValue(636);

        expect(
          screen.getByPlaceholderText("ou=users,dc=bel,dc=com")
        ).toHaveValue("ou=users,dc=bel,dc=com");
      });
    });

    test("loads CA file path correctly", async () => {
      renderComponent();

      await waitFor(() => {
        expect(
          screen.getByPlaceholderText("/etc/cafiles/cafile.pem")
        ).toHaveValue("/etc/cafiles/cafile.pem");
      });
    });

    test("loads custom credentials when enabled", async () => {
      renderComponent();

      await waitFor(() => {
        expect(screen.getByDisplayValue("admin_user")).toBeInTheDocument();

        expect(screen.getByDisplayValue("Admin1234")).toBeInTheDocument();
      });
    });

    test("handles missing LDAP configuration values", async () => {
      ConfigurationAxios.mockResolvedValue({
        data: {
          connection_url: "",
          user_domain: "",
          ca_file_path: null,
          bindUserName: null,
          bindPassword: null,
          bind_credentials_enabled: false,
        },
      });

      renderComponent();

      await waitFor(() => {
        expect(screen.getByPlaceholderText("ldaps://iaf.ldap")).toHaveValue(
          "INVALID URL"
        );

        // HTML number inputs cannot expose a non-numeric controlled value.
        // The component computes "INVALID PORT", but the browser presents it as empty.
        expect(screen.getByPlaceholderText("636")).toHaveValue(null);

        expect(
          screen.getByPlaceholderText("ou=users,dc=bel,dc=com")
        ).toHaveValue("INVALID DOMAIN NAME");
      });

      expect(screen.queryByDisplayValue("admin_user")).not.toBeInTheDocument();
    });

    test("shows error toast when GET API fails", async () => {
      ConfigurationAxios.mockRejectedValue(new Error("Network error"));

      renderComponent();

      await waitFor(() => {
        expect(Toast).toHaveBeenCalledWith(
          "",
          "Error in getting LDAP config",
          "error"
        );
      });
    });

    test("handles response without data", async () => {
      ConfigurationAxios.mockResolvedValue({
        data: null,
      });

      renderComponent();

      await waitFor(() => {
        expect(ConfigurationAxios).toHaveBeenCalledWith(GET_LDAP_CONFIG, "get");
      });

      expect(screen.getByPlaceholderText("ldaps://iaf.ldap")).toHaveValue("");
    });
  });

  // 3. MODIFY MODE

  describe("Modify Mode", () => {
    test("enables fields when Modify switch is selected", async () => {
      renderComponent();

      enableModifyMode();

      expect(screen.getByPlaceholderText("ldaps://iaf.ldap")).toBeEnabled();

      expect(screen.getByPlaceholderText("636")).toBeEnabled();

      expect(screen.getByText("Save")).toBeInTheDocument();
    });

    test("disables fields when Modify switch is turned off", async () => {
      renderComponent();

      enableModifyMode();

      fireEvent.click(screen.getByLabelText("Modify"));

      expect(screen.getByPlaceholderText("ldaps://iaf.ldap")).toBeDisabled();

      expect(screen.queryByText("Save")).not.toBeInTheDocument();
    });
  });

  // 4. CUSTOM CREDENTIALS

  describe("Custom Credentials", () => {
    test("shows username and password fields when enabled", async () => {
      renderComponent();

      await waitFor(() => {
        expect(screen.getByDisplayValue("admin_user")).toBeInTheDocument();
      });

      expect(screen.getByDisplayValue("Admin1234")).toBeInTheDocument();
    });

    test("hides username and password fields when disabled", async () => {
      renderComponent();

      await waitFor(() => {
        expect(screen.getByDisplayValue("admin_user")).toBeInTheDocument();
      });

      fireEvent.click(
        screen.getByLabelText("Custom Credentials for LDAP Bind")
      );

      expect(screen.queryByDisplayValue("admin_user")).not.toBeInTheDocument();

      expect(screen.queryByDisplayValue("Admin1234")).not.toBeInTheDocument();
    });

    test("shows username and password fields when checkbox is enabled", async () => {
      ConfigurationAxios.mockResolvedValue({
        data: {
          ...mockLdapResponse,
          bind_credentials_enabled: false,
        },
      });

      renderComponent();

      const checkbox = screen.getByLabelText(
        "Custom Credentials for LDAP Bind"
      );

      expect(checkbox).not.toBeChecked();

      fireEvent.click(checkbox);

      expect(checkbox).toBeChecked();

      expect(screen.getByText("Bind Username")).toBeInTheDocument();

      expect(screen.getByText("Bind Password")).toBeInTheDocument();
    });
  });

  // 5. USERNAME VALIDATION

  describe("Username Validation", () => {
    test("accepts valid username", async () => {
      renderComponent();

      enableModifyMode();

      const username = await screen.findByDisplayValue("admin_user");

      fireEvent.change(username, {
        target: { value: "valid_user123" },
      });

      expect(username).toHaveValue("valid_user123");

      expect(screen.queryByText(/UserName should be/)).not.toBeInTheDocument();
    });

    test("rejects username shorter than 4 characters", async () => {
      renderComponent();

      enableModifyMode();

      const username = await screen.findByDisplayValue("admin_user");

      fireEvent.change(username, {
        target: { value: "abc" },
      });

      expect(screen.getByText(/UserName should be/)).toBeInTheDocument();
    });

    test("rejects username containing special characters", async () => {
      renderComponent();

      enableModifyMode();

      const username = await screen.findByDisplayValue("admin_user");

      fireEvent.change(username, {
        target: { value: "admin@123" },
      });

      expect(screen.getByText(/UserName should be/)).toBeInTheDocument();
    });

    test("rejects username longer than 24 characters", async () => {
      renderComponent();

      enableModifyMode();

      const username = await screen.findByDisplayValue("admin_user");

      fireEvent.change(username, {
        target: { value: "abcdefghijklmnopqrstuvwxy" },
      });

      expect(screen.getByText(/UserName should be/)).toBeInTheDocument();
    });
  });

  // 6. PASSWORD VALIDATION

  describe("Password Validation", () => {
    test("accepts valid password", async () => {
      renderComponent();

      enableModifyMode();

      const password = await screen.findByDisplayValue("Admin1234");

      fireEvent.change(password, {
        target: { value: "ValidPass123" },
      });

      expect(password).toHaveValue("ValidPass123");

      expect(screen.queryByText(/Password should be/)).not.toBeInTheDocument();
    });

    test("rejects password without uppercase character", async () => {
      renderComponent();

      enableModifyMode();

      const password = await screen.findByDisplayValue("Admin1234");

      fireEvent.change(password, {
        target: { value: "invalid123" },
      });

      expect(screen.getByText(/Password should be/)).toBeInTheDocument();
    });

    test("rejects password without lowercase character", async () => {
      renderComponent();

      enableModifyMode();

      const password = await screen.findByDisplayValue("Admin1234");

      fireEvent.change(password, {
        target: { value: "INVALID123" },
      });

      expect(screen.getByText(/Password should be/)).toBeInTheDocument();
    });

    test("rejects password without number", async () => {
      renderComponent();

      enableModifyMode();

      const password = await screen.findByDisplayValue("Admin1234");

      fireEvent.change(password, {
        target: { value: "InvalidPass" },
      });

      expect(screen.getByText(/Password should be/)).toBeInTheDocument();
    });

    test("rejects password shorter than 8 characters", async () => {
      renderComponent();

      enableModifyMode();

      const password = await screen.findByDisplayValue("Admin1234");

      fireEvent.change(password, {
        target: { value: "Abc123" },
      });

      expect(screen.getByText(/Password should be/)).toBeInTheDocument();
    });

    test("rejects password longer than 16 characters", async () => {
      renderComponent();

      enableModifyMode();

      const password = await screen.findByDisplayValue("Admin1234");

      fireEvent.change(password, {
        target: { value: "ValidPassword123456" },
      });

      expect(screen.getByText(/Password should be/)).toBeInTheDocument();
    });
  });

  // 7. SAVE BUTTON

  describe("Save Button", () => {
    test("Save button is disabled initially", async () => {
      renderComponent();

      enableModifyMode();

      expect(screen.getByText("Save")).toBeDisabled();
    });

    test("Save button is enabled after valid field changes", async () => {
      renderComponent();

      enableModifyMode();

      await fillRequiredFields();

      await waitFor(() => {
        expect(screen.getByText("Save")).toBeEnabled();
      });
    });

    test("Save button is disabled when username is invalid", async () => {
      renderComponent();

      enableModifyMode();

      await fillRequiredFields();

      const username = await screen.findByDisplayValue("admin_user");

      fireEvent.change(username, {
        target: { value: "ab@" },
      });

      expect(screen.getByText("Save")).toBeDisabled();
    });

    test("Save button is disabled when password is invalid", async () => {
      renderComponent();

      enableModifyMode();

      await fillRequiredFields();

      const password = await screen.findByDisplayValue("Admin1234");

      fireEvent.change(password, {
        target: { value: "invalid" },
      });

      expect(screen.getByText("Save")).toBeDisabled();
    });
  });

  // 8. SAVE VALIDATION

  describe("Save Validation", () => {
    test("shows error when custom credentials are enabled but username and password are empty", async () => {
      renderComponent();

      enableModifyMode();

      await fillRequiredFields();

      const username = await screen.findByDisplayValue("admin_user");

      fireEvent.change(username, {
        target: { value: "" },
      });

      const password = screen.getByDisplayValue("Admin1234");

      fireEvent.change(password, {
        target: { value: "" },
      });

      fireEvent.click(screen.getByText("Save"));

      expect(Toast).toHaveBeenCalledWith(
        "",
        "Username and Password are required when custom credentials are enabled.",
        "error"
      );

      expect(
        screen.queryByTestId("confirmation-dialog")
      ).not.toBeInTheDocument();
    });

    test("shows username error when saving invalid username", async () => {
      renderComponent();

      enableModifyMode();

      await fillRequiredFields();

      const username = await screen.findByDisplayValue("admin_user");

      fireEvent.change(username, {
        target: { value: "ab@" },
      });

      expect(screen.getByText("Save")).toBeDisabled();
    });

    test("shows password error when saving invalid password", async () => {
      renderComponent();

      enableModifyMode();

      await fillRequiredFields();

      const password = await screen.findByDisplayValue("Admin1234");

      fireEvent.change(password, {
        target: { value: "invalid" },
      });

      expect(screen.getByText("Save")).toBeDisabled();
    });
  });

  // 9. CONFIRMATION DIALOG

  describe("Confirmation Dialog", () => {
    test("opens confirmation dialog on Save click", async () => {
      renderComponent();

      enableModifyMode();

      await fillRequiredFields();

      await waitFor(() => {
        expect(screen.getByText("Save")).toBeEnabled();
      });

      fireEvent.click(screen.getByText("Save"));

      expect(screen.getByTestId("confirmation-dialog")).toBeInTheDocument();

      expect(
        screen.getByText("Are you sure want to save configuration")
      ).toBeInTheDocument();
    });

    test("closes confirmation dialog on Cancel", async () => {
      renderComponent();

      enableModifyMode();

      await fillRequiredFields();

      await waitFor(() => {
        expect(screen.getByText("Save")).toBeEnabled();
      });

      fireEvent.click(screen.getByText("Save"));

      fireEvent.click(screen.getByText("Cancel"));

      expect(
        screen.queryByTestId("confirmation-dialog")
      ).not.toBeInTheDocument();
    });
  });

  // 10. SAVE API

  describe("SAVE LDAP Configuration", () => {
    test("saves LDAP configuration successfully", async () => {
      ConfigurationAxios.mockResolvedValueOnce({
        data: mockLdapResponse,
      }).mockResolvedValueOnce({
        data: { status: true },
      });

      renderComponent();

      enableModifyMode();

      await fillRequiredFields();

      await waitFor(() => {
        expect(screen.getByText("Save")).toBeEnabled();
      });

      fireEvent.click(screen.getByText("Save"));

      fireEvent.click(await screen.findByText("Confirm"));

      await waitFor(() => {
        expect(ConfigurationAxios).toHaveBeenLastCalledWith(
          SAVE_LDAP_CONFIG,
          "post",
          expect.objectContaining({
            id: "1",
            connection_url: "ldaps://new.ldap:636",
            ca_file_path: "/etc/new/cafile.pem",
            user_domain: ",ou=users,dc=example,dc=com",
            bindUserName: "admin_user",
            bindPassword: "Admin1234",
            useServiceAccount: true,
          })
        );
      });

      await waitFor(() => {
        expect(Toast).toHaveBeenCalledWith(
          "",
          "Ldap configuration saved successfully",
          "success"
        );
      });
    });

    test("shows error toast when save API returns failure", async () => {
      ConfigurationAxios.mockResolvedValueOnce({
        data: mockLdapResponse,
      }).mockResolvedValueOnce({
        data: { status: false },
      });

      renderComponent();

      enableModifyMode();

      await fillRequiredFields();

      await waitFor(() => {
        expect(screen.getByText("Save")).toBeEnabled();
      });

      fireEvent.click(screen.getByText("Save"));

      fireEvent.click(await screen.findByText("Confirm"));

      await waitFor(() => {
        expect(Toast).toHaveBeenCalledWith("", "Error in uploading", "error");
      });
    });

    test("closes confirmation dialog after successful save", async () => {
      ConfigurationAxios.mockResolvedValueOnce({
        data: mockLdapResponse,
      }).mockResolvedValueOnce({
        data: { status: true },
      });

      renderComponent();

      enableModifyMode();

      await fillRequiredFields();

      await waitFor(() => {
        expect(screen.getByText("Save")).toBeEnabled();
      });

      fireEvent.click(screen.getByText("Save"));

      fireEvent.click(await screen.findByText("Confirm"));

      await waitFor(() => {
        expect(
          screen.queryByTestId("confirmation-dialog")
        ).not.toBeInTheDocument();
      });
    });
  });
});
