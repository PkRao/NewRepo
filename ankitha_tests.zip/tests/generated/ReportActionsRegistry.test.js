const mockFaultAxios = jest.fn();
const mockInventoryAxios = jest.fn();
const mockTopologyAxios = jest.fn();
const mockAuditAxios = jest.fn();
const mockSecurityAxios = jest.fn();

jest.mock('@/RestAPI/api/axiosApicall', () => ({
  FaultAxios: (...args) => mockFaultAxios(...args),
  InventoryAxios: (...args) => mockInventoryAxios(...args),
  TopologyAxios: (...args) => mockTopologyAxios(...args),
  DbAxios: jest.fn(),
  PerformanceAxios: jest.fn(),
  AuditManagementAxios: (...args) => mockAuditAxios(...args),
  SecurityAxios: (...args) => mockSecurityAxios(...args),
}));

import { executeReportFetch } from '../../src/Pages/Rnmsdashboard/RightUtilityDrawer/components/Reports/ReportActionsRegistry';

describe('executeReportFetch', () => {
  beforeEach(() => {
    mockFaultAxios.mockReset();
    mockInventoryAxios.mockReset();
    mockTopologyAxios.mockReset();
    mockAuditAxios.mockReset();
    mockSecurityAxios.mockReset();
  });

  test('rejects report keys that are not registered', async () => {
    await expect(executeReportFetch('not-a-report', {})).rejects.toThrow('No API configuration registered');
  });

  test('posts the transformed alarm-log payload', async () => {
    mockFaultAxios.mockResolvedValue({ data: [{ alarmName: 'Link Down' }] });
    const result = await executeReportFetch('AlarmLog', {
      deviceName: [10], alarmName: ['Link Down'], severities: ['Critical'],
    }, 4);
    expect(mockFaultAxios).toHaveBeenCalledWith(expect.any(String), 'post', expect.objectContaining({
      resourceIdList: [10], alarmNameList: ['Link Down'], severityList: ['Critical'],
    }));
    expect(result.data[0].alarmName).toBe('Link Down');
  });

  test('requires a selected device for path-variable reports', async () => {
    await expect(executeReportFetch('DeviceAvailability', {})).rejects.toThrow('Please select a value for deviceName');
  });

  test('builds and encodes a path-variable device id', async () => {
    mockFaultAxios.mockResolvedValue({ data: [] });
    await executeReportFetch('DeviceAvailability', { deviceName: { siteId: 'router 7' } });
    expect(mockFaultAxios).toHaveBeenCalledWith(expect.stringContaining('/router%207'), 'post', expect.any(Object));
  });

  test('requires at least one site for multi-site reports', async () => {
    await expect(executeReportFetch('SiteRepDetails', {})).rejects.toThrow('Please select at least one site');
  });

  test('uses a GET request with comma-separated site ids', async () => {
    mockInventoryAxios.mockResolvedValue({ data: [] });
    await executeReportFetch('SiteRepDetails', { siteName: [10, ' 20 '] });
    expect(mockInventoryAxios).toHaveBeenCalledWith(expect.stringContaining('/10,20'), 'get');
  });

  test('transforms link-summary rows and supplies safe defaults', async () => {
    mockTopologyAxios.mockResolvedValue({ data: [{ linkId: 1, uptimePercent: '98.5' }] });
    const result = await executeReportFetch('LinkSummary', { siteName: 'site-1', selectedSiteDisplayName: 'Site One' });
    expect(mockTopologyAxios).toHaveBeenCalledWith(expect.any(String), 'get');
    expect(result.data[0]).toEqual(expect.objectContaining({
      sno: 1, siteName: 'Site One', linkTypeName: 'Unknown Link', uptimePercent: 98.5,
    }));
  });
});
