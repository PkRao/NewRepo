import React from "react";
import { jest } from "@jest/globals";
import { render, screen, waitFor } from "@testing-library/react";

// Register ESM mocks before importing the component.
jest.unstable_mockModule("@/RestAPI/api/axiosApicall", () => ({
  HelpDeskAxios: jest.fn(),
  InventAxios: jest.fn(),
}));

jest.unstable_mockModule("@/RestAPI/url/endpoint", () => ({
  FETCH_CNMS_ADDRESS_DETAILS: "/api/cnms/address",
  GET_TICKET_HISTORY_FOR_GIVEN_ID: "/api/ticket/history",
}));

jest.unstable_mockModule("@/assets/SVGIcons/right.svg", () => ({
  default: "right-arrow.svg",
}));

jest.unstable_mockModule(
  "@/components/Reusable/Scrollbar/ScrollContainer",
  () => ({
    default: function MockScrollContainer({ children, className }) {
      return React.createElement(
        "div",
        { "data-testid": "scroll-container", className },
        children
      );
    },
  })
);

jest.unstable_mockModule(
  "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/HelpDesk/ShowMoreText",
  () => ({
    default: function MockShowMoreText({
      element,
      ticketStatusIdMapping,
    }) {
      return React.createElement(
        "div",
        { "data-testid": "history-item" },
        React.createElement("span", null, element.id ?? "no-id"),
        React.createElement("span", null, element.action ?? "item"),
        React.createElement(
          "span",
          null,
          JSON.stringify(ticketStatusIdMapping)
        )
      );
    },
  })
);

// Import mocked Axios functions and component after registering mocks.
const { HelpDeskAxios, InventAxios } = await import(
  "@/RestAPI/api/axiosApicall"
);

const { default: HandleHistoryAction } = await import(
  "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/HelpDesk/HandleHistoryAction"
);

describe("HandleHistoryAction", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  test("shows error state when ticket id is missing", async () => {
    const warnSpy = jest
      .spyOn(console, "warn")
      .mockImplementation(() => {});

    render(<HandleHistoryAction data={{}} />);

    await waitFor(() => {
      expect(
        screen.getByText("No valid Ticket ID found.")
      ).toBeInTheDocument();
    });

    expect(InventAxios).not.toHaveBeenCalled();
    expect(HelpDeskAxios).not.toHaveBeenCalled();

    warnSpy.mockRestore();
  });

  test("shows loading indicator while fetching history", () => {
    InventAxios.mockImplementation(() => new Promise(() => {}));

    render(<HandleHistoryAction data={{ id: "101" }} />);

    expect(screen.getByText("Loading history...")).toBeInTheDocument();
  });

  test("handles missing CNMS address and displays error message", async () => {
    const errSpy = jest
      .spyOn(console, "error")
      .mockImplementation(() => {});

    InventAxios.mockResolvedValueOnce({ data: {} });

    render(<HandleHistoryAction data={{ id: "101" }} />);

    await waitFor(() => {
      expect(
        screen.getByText(
          "CNMS Address not found. Cannot determine server location."
        )
      ).toBeInTheDocument();
    });

    expect(HelpDeskAxios).not.toHaveBeenCalled();

    errSpy.mockRestore();
  });

  test("handles API rejection and displays error message", async () => {
    const errSpy = jest
      .spyOn(console, "error")
      .mockImplementation(() => {});

    InventAxios.mockResolvedValueOnce({
      data: { address: "192.168.1.10:8080" },
    });

    HelpDeskAxios.mockRejectedValueOnce(
      new Error("History service down")
    );

    render(<HandleHistoryAction data={{ id: "202" }} />);

    await waitFor(() => {
      expect(
        screen.getByText("History service down")
      ).toBeInTheDocument();
    });

    errSpy.mockRestore();
  });

  test("renders empty state when history array is empty", async () => {
    InventAxios.mockResolvedValueOnce({
      data: { address: "192.168.1.10:8080" },
    });

    HelpDeskAxios.mockResolvedValueOnce({ data: [] });

    render(<HandleHistoryAction data={{ id: "303" }} />);

    await waitFor(() => {
      expect(
        screen.getByText("No history available for this ticket.")
      ).toBeInTheDocument();
    });

    expect(HelpDeskAxios).toHaveBeenCalledWith(
      "/api/ticket/history/303",
      "get",
      null,
      null,
      "192.168.1.10:8080"
    );
  });

  test("renders timeline items with default statusMap when no custom mapping is passed", async () => {
    InventAxios.mockResolvedValueOnce({
      data: { address: "10.1.2.3:9000" },
    });

    HelpDeskAxios.mockResolvedValueOnce({
      data: [
        { id: "h1", action: "Created" },
        { action: "Updated without id" },
      ],
    });

    render(<HandleHistoryAction data={{ id: "404" }} />);

    await waitFor(() => {
      expect(screen.getAllByTestId("history-item")).toHaveLength(2);
    });

    expect(screen.getByTestId("scroll-container")).toHaveClass("h-full");
    expect(screen.getByText("h1")).toBeInTheDocument();
    expect(screen.getByText("Updated without id")).toBeInTheDocument();

    expect(HelpDeskAxios).toHaveBeenCalledWith(
      "/api/ticket/history/404",
      "get",
      null,
      null,
      "10.1.2.3:9000"
    );
  });

  test("passes custom ticketStatusIdMapping to ShowMoreText when provided", async () => {
    InventAxios.mockResolvedValueOnce({
      data: { address: "10.1.2.3:9000" },
    });

    HelpDeskAxios.mockResolvedValueOnce({
      data: [{ id: "h9", action: "Closed" }],
    });

    const customMap = { 5: "Done", 6: "Reopened" };

    render(
      <HandleHistoryAction
        data={{ id: "505" }}
        ticketStatusIdMapping={customMap}
      />
    );

    await waitFor(() => {
      expect(
        screen.getByText(JSON.stringify(customMap))
      ).toBeInTheDocument();
    });
  });
});
