import React from "react";
import { jest } from "@jest/globals";
import {
  render,
  screen,
  fireEvent,
  waitFor,
} from "@testing-library/react";
import "@testing-library/jest-dom";

// ======================================================
// ESM MOCKS
// ======================================================

jest.unstable_mockModule("react-redux", () => ({
  useSelector: jest.fn(),
}));

jest.unstable_mockModule("@mui/material", () => {
  const actual = jest.requireActual("@mui/material");

  return {
    ...actual,
    useTheme: jest.fn(() => ({
      palette: {
        mode: "light",
      },
    })),
  };
});

jest.unstable_mockModule("antd/es/input/TextArea", () => ({
  default: function MockTextArea({
    value,
    onChange,
    placeholder,
    rows,
    className,
    style,
  }) {
    return React.createElement("textarea", {
      "data-testid": "reopen-textarea",
      rows,
      value,
      placeholder,
      className,
      style,
      onChange,
    });
  },
}));

jest.unstable_mockModule("@/RestAPI/api/axiosApicall", () => ({
  HelpDeskAxios: jest.fn(),
  InventAxios: jest.fn(),
}));

jest.unstable_mockModule("@/RestAPI/url/endpoint", () => ({
  FETCH_CNMS_ADDRESS_DETAILS: "/api/cnms/address",
  UPDATE_TICKET: "/api/ticket/update",
}));

jest.unstable_mockModule(
  "@/components/Reusable/Toast/Toast",
  () => ({
    default: jest.fn(),
  })
);

jest.unstable_mockModule(
  "@/assets/SVGIcons/question_mark.svg",
  () => ({
    default: "confirm-icon.svg",
  })
);

jest.unstable_mockModule(
  "@/components/Reusable/Button/MButtonPrimary",
  () => ({
    default: function MockMButtonPrimary({
      children,
      onClick,
      disabled,
    }) {
      return React.createElement(
        "button",
        {
          type: "button",
          onClick,
          disabled,
        },
        children
      );
    },
  })
);

jest.unstable_mockModule(
  "@/components/Reusable/Dialog/MDialog",
  () => ({
    default: function MockMDialog({
      open,
      title,
      message,
      onConfirm,
      onClose,
      isChildFullScreen,
    }) {
      if (!open) return null;

      return React.createElement(
        "div",
        {
          role: "dialog",
          "aria-label": title,
          "data-fullscreen": String(
            Boolean(isChildFullScreen)
          ),
        },
        React.createElement("p", null, message),
        React.createElement(
          "button",
          {
            type: "button",
            onClick: onConfirm,
          },
          "Confirm Action"
        ),
        React.createElement(
          "button",
          {
            type: "button",
            onClick: onClose,
          },
          "Close Dialog"
        )
      );
    },
  })
);

// ======================================================
// DYNAMIC IMPORTS AFTER MOCK REGISTRATION
// ======================================================

const { useSelector } = await import("react-redux");

const { useTheme } = await import("@mui/material");

const { default: HandleReopenAction } = await import(
  "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/HelpDesk/HandleReopenAction"
);

const {
  HelpDeskAxios,
  InventAxios,
} = await import("@/RestAPI/api/axiosApicall");

const { default: Toast } = await import(
  "@/components/Reusable/Toast/Toast"
);

// ======================================================
// TEST SUITE
// ======================================================

describe("HandleReopenAction", () => {
  const onClose = jest.fn();
  const onSuccess = jest.fn();
  const onRefresh = jest.fn();

  const defaultState = {
    userSlice: {
      userDetails: {
        data: {
          userName: "jane.smith",
        },
      },
    },
  };

  // ======================================================
  // SETUP
  // ======================================================

  beforeEach(() => {
    jest.clearAllMocks();

    useSelector.mockImplementation((selectorFn) =>
      selectorFn(defaultState)
    );

    useTheme.mockReturnValue({
      palette: {
        mode: "light",
      },
    });

    InventAxios.mockResolvedValue({
      data: {},
    });

    HelpDeskAxios.mockResolvedValue({
      status: 200,
    });
  });

  // ======================================================
  // INITIAL RENDERING
  // ======================================================

  test("renders initial state with Confirm disabled and counter at 0/255", () => {
    render(
      <HandleReopenAction
        id="10"
        onClose={onClose}
      />
    );

    expect(
      screen.getByText("Ticket Reopen Statement *")
    ).toBeInTheDocument();

    expect(
      screen.getByText("0/255")
    ).toBeInTheDocument();

    const textarea = screen.getByTestId("reopen-textarea");

    expect(textarea).toHaveValue("");

    expect(textarea).toHaveAttribute(
      "placeholder",
      "Enter comments..."
    );

    expect(
      screen.getByRole("button", {
        name: "Confirm",
      })
    ).toBeDisabled();
  });

  // ======================================================
  // DESCRIPTION VALIDATION
  // ======================================================

  test("validates description length, shows minimum error under 2 chars, caps at 255, and clears on empty", () => {
    render(
      <HandleReopenAction id="10" />
    );

    const textarea = screen.getByTestId("reopen-textarea");

    fireEvent.change(textarea, {
      target: {
        value: "a",
      },
    });

    expect(textarea).toHaveValue("a");

    expect(
      screen.getByText("Miimum 2 charcters needed")
    ).toBeInTheDocument();

    expect(
      screen.getByRole("button", {
        name: "Confirm",
      })
    ).toBeDisabled();

    fireEvent.change(textarea, {
      target: {
        value: "ab",
      },
    });

    expect(textarea).toHaveValue("ab");

    expect(
      screen.queryByText("Miimum 2 charcters needed")
    ).not.toBeInTheDocument();

    expect(
      screen.getByText("2/255")
    ).toBeInTheDocument();

    expect(
      screen.getByRole("button", {
        name: "Confirm",
      })
    ).toBeEnabled();

    const longText = "z".repeat(270);

    fireEvent.change(textarea, {
      target: {
        value: longText,
      },
    });

    expect(textarea.value).toHaveLength(255);

    expect(
      screen.getByText("255/255")
    ).toBeInTheDocument();

    fireEvent.change(textarea, {
      target: {
        value: "",
      },
    });

    expect(textarea).toHaveValue("");

    expect(
      screen.getByText("0/255")
    ).toBeInTheDocument();
  });

  // ======================================================
  // THEME AND CONFIRMATION DIALOG
  // ======================================================

  test("applies dark theme styles, opens/closes confirmation dialog, and respects isChildFullScreen", () => {
    useTheme.mockReturnValue({
      palette: {
        mode: "dark",
      },
    });

    render(
      <HandleReopenAction
        id="10"
        isChildFullScreen={true}
        actionType="REOPEN"
      />
    );

    const textarea = screen.getByTestId("reopen-textarea");

    expect(textarea).toHaveClass("dark-ant-textarea");

    expect(textarea.style.background).toBe(
      "rgb(51, 51, 51)"
    );

    expect(textarea.style.color).toBe(
      "rgb(255, 255, 255)"
    );

    fireEvent.change(textarea, {
      target: {
        value: "Reopen reason",
      },
    });

    fireEvent.click(
      screen.getByRole("button", {
        name: "Confirm",
      })
    );

    const dialog = screen.getByRole("dialog", {
      name: "Confirm Action",
    });

    expect(dialog).toHaveAttribute(
      "data-fullscreen",
      "true"
    );

    expect(
      screen.getByText(
        "Are you sure you want to proceed with reopen?"
      )
    ).toBeInTheDocument();

    fireEvent.click(
      screen.getByRole("button", {
        name: "Close Dialog",
      })
    );

    expect(
      screen.queryByRole("dialog")
    ).not.toBeInTheDocument();
  });

  // ======================================================
  // REOPEN ACTION
  // ======================================================

  test("submits REOPEN with subDetail sequenceNum/loggedinUser and host address", async () => {
    InventAxios.mockResolvedValueOnce({
      data: {
        address: "10.20.30.40:8786",
      },
    });

    HelpDeskAxios.mockResolvedValueOnce({
      status: 201,
    });

    const ticketData = {
      hdTicketSubDetails: [
        {
          sequenceNum: 1,
          loggedinUser: "agent.one",
        },
        {
          sequenceNum: 3,
          loggedinUser: "agent.three",
        },
      ],
    };

    render(
      <HandleReopenAction
        id="55"
        ticketData={ticketData}
        onClose={onClose}
        onSuccess={onSuccess}
        onRefresh={onRefresh}
      />
    );

    fireEvent.change(
      screen.getByTestId("reopen-textarea"),
      {
        target: {
          value: "Need further investigation",
        },
      }
    );

    fireEvent.click(
      screen.getByRole("button", {
        name: "Confirm",
      })
    );

    fireEvent.click(
      screen.getByRole("button", {
        name: "Confirm Action",
      })
    );

    await waitFor(() => {
      expect(HelpDeskAxios).toHaveBeenCalledWith(
        "/api/ticket/update",
        "post",
        {
          hdTicketStatus: {
            id: "6",
          },
          hdTicketDetail: {
            id: "55",
          },
          sequenceNum: 3,
          statement: "Need further investigation",
          loggedinUser: "agent.three",
        },
        null,
        "10.20.30.40:8786"
      );
    });

    expect(Toast).toHaveBeenCalledWith(
      "Success!",
      "Ticket status reopened successfully!",
      "success"
    );

    expect(onRefresh).toHaveBeenCalledTimes(1);
    expect(onSuccess).toHaveBeenCalledTimes(1);
    expect(onClose).toHaveBeenCalledTimes(1);
  });

  // ======================================================
  // NON-REOPEN ACTION
  // ======================================================

  test("submits non-REOPEN actionType with status id 5, existing port, and Redux userName", async () => {
    InventAxios.mockResolvedValueOnce({
      data: {
        address: "host.local:8081",
      },
    });

    HelpDeskAxios.mockResolvedValueOnce({
      status: 200,
    });

    render(
      <HandleReopenAction
        id="66"
        actionType="CLOSE"
        ticketData={{
          hdTicketSubDetails: [],
        }}
        onClose={onClose}
        onSuccess={onSuccess}
      />
    );

    fireEvent.change(
      screen.getByTestId("reopen-textarea"),
      {
        target: {
          value: "Closing via non-reopen branch",
        },
      }
    );

    fireEvent.click(
      screen.getByRole("button", {
        name: "Confirm",
      })
    );

    fireEvent.click(
      screen.getByRole("button", {
        name: "Confirm Action",
      })
    );

    await waitFor(() => {
      expect(HelpDeskAxios).toHaveBeenCalledWith(
        "/api/ticket/update",
        "post",
        {
          hdTicketStatus: {
            id: "5",
          },
          hdTicketDetail: {
            id: "66",
          },
          sequenceNum: 1,
          statement: "Closing via non-reopen branch",
          loggedinUser: "jane.smith",
        },
        null,
        "host.local:8081"
      );
    });

    expect(Toast).toHaveBeenCalledWith(
      "Success!",
      "Ticket status reopened successfully!",
      "success"
    );

    expect(onSuccess).toHaveBeenCalledTimes(1);
    expect(onClose).toHaveBeenCalledTimes(1);
  });

  // ======================================================
  // ERROR HANDLING
  // ======================================================

  test("falls back to 'system' loggedinUser when userName is empty and shows error toast on non-200/201", async () => {
    useSelector.mockImplementation((selectorFn) =>
      selectorFn({
        userSlice: {
          userDetails: {
            data: {
              userName: "",
            },
          },
        },
      })
    );

    HelpDeskAxios.mockResolvedValueOnce({
      status: 400,
    });

    render(
      <HandleReopenAction
        id="77"
        onClose={onClose}
        onSuccess={onSuccess}
      />
    );

    fireEvent.change(
      screen.getByTestId("reopen-textarea"),
      {
        target: {
          value: "Fallback user test",
        },
      }
    );

    fireEvent.click(
      screen.getByRole("button", {
        name: "Confirm",
      })
    );

    fireEvent.click(
      screen.getByRole("button", {
        name: "Confirm Action",
      })
    );

    await waitFor(() => {
      expect(HelpDeskAxios).toHaveBeenCalledWith(
        "/api/ticket/update",
        "post",
        expect.objectContaining({
          loggedinUser: "system",
        }),
        null,
        null
      );

      expect(Toast).toHaveBeenCalledWith(
        "Error!",
        "Failed to update",
        "error"
      );
    });

    expect(onSuccess).not.toHaveBeenCalled();
    expect(onClose).not.toHaveBeenCalled();
  });

  test("handles API error rejection and missing id alert", async () => {
    const errSpy = jest
      .spyOn(console, "error")
      .mockImplementation(() => {});

    const alertSpy = jest
      .spyOn(window, "alert")
      .mockImplementation(() => {});

    InventAxios.mockRejectedValueOnce(
      new Error("Network failure")
    );

    // First component: API rejection
    const { unmount } = render(
      <HandleReopenAction
        id="88"
        onClose={onClose}
        onSuccess={onSuccess}
      />
    );

    fireEvent.change(
      screen.getByTestId("reopen-textarea"),
      {
        target: {
          value: "Error test",
        },
      }
    );

    fireEvent.click(
      screen.getByRole("button", {
        name: "Confirm",
      })
    );

    fireEvent.click(
      screen.getByRole("button", {
        name: "Confirm Action",
      })
    );

    await waitFor(() => {
      expect(errSpy).toHaveBeenCalledWith(
        "API Error:",
        "Network failure"
      );
    });

    // Remove the first component and its open dialog.
    unmount();

    // Second component: missing ticket ID
    render(
      <HandleReopenAction onClose={onClose} />
    );

    const textarea = screen.getByTestId(
      "reopen-textarea"
    );

    fireEvent.change(textarea, {
      target: {
        value: "Missing id test",
      },
    });

    fireEvent.click(
      screen.getByRole("button", {
        name: "Confirm",
      })
    );

    fireEvent.click(
      screen.getByRole("button", {
        name: "Confirm Action",
      })
    );

    expect(alertSpy).toHaveBeenCalledWith(
      "Error: Missing Ticket ID"
    );

    errSpy.mockRestore();
    alertSpy.mockRestore();
  });
});
