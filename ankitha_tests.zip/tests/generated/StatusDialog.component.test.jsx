import React from "react";
import { jest } from "@jest/globals";
import { render, screen } from "@testing-library/react";

const baseDialogLayoutMock = jest.fn();
const dynamicStatusLayoutMock = jest.fn();

jest.unstable_mockModule("../../src/components/Dialogs/DynamicStatusLayout", () => ({
  default: (props) => {
    dynamicStatusLayoutMock(props);
    return <div data-testid="dynamic-status-layout">Dynamic status content</div>;
  },
}));

jest.unstable_mockModule("../../src/components/Dialogs/BaseDialogLayout", () => ({
  default: ({ title, onClose, children }) => {
    baseDialogLayoutMock({ title, onClose });
    return (
      <section>
        <h2>{title}</h2>
        <button type="button" onClick={onClose}>
          Close dialog
        </button>
        {children}
      </section>
    );
  },
}));

const { default: StatusDialog } = await import(
  "../../src/components/Dialogs/StatusDialog"
);

describe("StatusDialog", () => {
  let consoleLogSpy;

  beforeEach(() => {
    jest.clearAllMocks();
    consoleLogSpy = jest.spyOn(console, "log").mockImplementation(() => {});
  });

  afterEach(() => {
    consoleLogSpy.mockRestore();
  });

  test("renders the device status title and passes node and source to DynamicStatusLayout", () => {
    const node = {
      id: "node-101",
      resourceName: "Router-01",
      status: "active",
    };
    const source = "RNMS";
    const onClose = jest.fn();

    render(
      <StatusDialog node={node} source={source} onClose={onClose} />
    );

    expect(
      screen.getByRole("heading", {
        name: "Router-01 - Device Status",
      })
    ).toBeInTheDocument();
    expect(screen.getByTestId("dynamic-status-layout")).toBeInTheDocument();

    expect(baseDialogLayoutMock).toHaveBeenCalledWith({
      title: "Router-01 - Device Status",
      onClose,
    });
    expect(dynamicStatusLayoutMock).toHaveBeenCalledWith({
      node,
      source,
    });
    expect(consoleLogSpy).toHaveBeenCalledWith("nodenodecnms1", node);
  });

  test("uses the literal undefined resource name when node is omitted", () => {
    const source = "CNMS";
    const onClose = jest.fn();

    render(<StatusDialog source={source} onClose={onClose} />);

    expect(
      screen.getByRole("heading", { name: "undefined - Device Status" })
    ).toBeInTheDocument();

    expect(baseDialogLayoutMock).toHaveBeenCalledWith({
      title: "undefined - Device Status",
      onClose,
    });
    expect(dynamicStatusLayoutMock).toHaveBeenCalledWith({
      node: undefined,
      source,
    });
    expect(consoleLogSpy).toHaveBeenCalledWith(
      "nodenodecnms1",
      undefined
    );
  });

  test("forwards the close callback to the dialog layout", () => {
    const onClose = jest.fn();

    render(
      <StatusDialog
        node={{ resourceName: "Switch-02" }}
        source="CNMS"
        onClose={onClose}
      />
    );

    screen.getByRole("button", { name: "Close dialog" }).click();

    expect(onClose).toHaveBeenCalledTimes(1);
  });
});
