import React from "react";
import { jest } from "@jest/globals";
import { render, screen } from "@testing-library/react";
import "@testing-library/jest-dom";

// Mock child component before importing the component under test.
jest.unstable_mockModule(
  "@/Pages/Rnmsdashboard/PortStatus/PortStatusSwitch",
  () => ({
    PortStatusSwitch: jest.fn(({ device }) =>
      React.createElement(
        "div",
        { "data-testid": "port-status-switch" },
        device.name
      )
    ),
  })
);

// Import actual MUI theme utilities.
const { ThemeProvider, createTheme } = await import("@mui/material");

// Import mocked child component.
const { PortStatusSwitch } = await import(
  "@/Pages/Rnmsdashboard/PortStatus/PortStatusSwitch"
);

// Import component after registering mocks.
const { PortStatusBoard } = await import(
  "@/Pages/Rnmsdashboard/PortStatus/PortStatusBoard"
);

describe("PortStatusBoard Component", () => {
  const mockDevices = [
    { id: 1, name: "Device 1" },
    { id: 2, name: "Device 2" },
    { id: 3, name: "Device 3" },
  ];

  const lightTheme = createTheme({
    palette: { mode: "light" },
  });

  const darkTheme = createTheme({
    palette: { mode: "dark" },
  });

  const renderBoard = (devices = mockDevices, theme = lightTheme) => {
    return render(
      <ThemeProvider theme={theme}>
        <PortStatusBoard devices={devices} />
      </ThemeProvider>
    );
  };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  test("should render PortStatusBoard successfully", () => {
    const { container } = renderBoard();

    expect(container.querySelector(".board-shell")).toBeInTheDocument();
  });

  test("should apply white background in light theme", () => {
    const { container } = renderBoard(mockDevices, lightTheme);

    expect(container.querySelector(".board-shell")).toHaveStyle({
      backgroundColor: "#ffffff",
    });
  });

  test("should apply dark background in dark theme", () => {
    const { container } = renderBoard(mockDevices, darkTheme);

    expect(container.querySelector(".board-shell")).toHaveStyle({
      backgroundColor: "rgb(84, 84, 84)",
    });
  });

  test("should apply background color transition", () => {
    const { container } = renderBoard();

    expect(container.querySelector(".board-shell")).toHaveStyle({
      transition: "background-color 0.3s ease",
    });
  });

  test("should render all device rows", () => {
    const { container } = renderBoard();

    expect(container.querySelectorAll(".device-row")).toHaveLength(3);
  });

  test("should display all device names", () => {
    renderBoard();

    expect(screen.getByText("Device 1")).toBeInTheDocument();
    expect(screen.getByText("Device 2")).toBeInTheDocument();
    expect(screen.getByText("Device 3")).toBeInTheDocument();
  });

 test("should pass correct device props to PortStatusSwitch", () => {
  renderBoard();

  expect(PortStatusSwitch).toHaveBeenCalledTimes(3);

  expect(PortStatusSwitch).toHaveBeenNthCalledWith(
    1,
    { device: mockDevices[0] },
    undefined
  );

  expect(PortStatusSwitch).toHaveBeenNthCalledWith(
    2,
    { device: mockDevices[1] },
    undefined
  );

  expect(PortStatusSwitch).toHaveBeenNthCalledWith(
    3,
    { device: mockDevices[2] },
    undefined
  );
});

  test("should render without device rows when devices array is empty", () => {
    const { container } = renderBoard([]);

    expect(container.querySelectorAll(".device-row")).toHaveLength(0);
  });

  test("should render correct device stack structure", () => {
    const { container } = renderBoard();

    expect(
      container.querySelector(".device-stack-wrapper")
    ).toBeInTheDocument();

    expect(
      container.querySelector(".device-stack")
    ).toBeInTheDocument();
  });

  test("should render board shell as a section element", () => {
    const { container } = renderBoard();

    expect(
      container.querySelector("section.board-shell")
    ).toBeInTheDocument();
  });
});
