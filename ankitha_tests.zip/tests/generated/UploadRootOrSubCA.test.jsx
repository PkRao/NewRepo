import React from "react";
import { jest } from "@jest/globals";
import {
  render,
  screen,
  fireEvent,
  waitFor,
  act,
} from "@testing-library/react";
import "@testing-library/jest-dom";
import { createTheme, ThemeProvider } from "@mui/material/styles";

let UploadRootOrSubCA;
let CertAxios;
let Toast;
let GET_ROOT_OR_SUB_CA_URL;
let UPLOAD_CERT_ROOT_OR_SUB;
let latestTableProps;

// Register native ESM mocks before importing the component under test.
// MTable is mocked here, so its internal ViewAugmentation dependency is
// never loaded and no virtual alias mock is needed.
await jest.unstable_mockModule("@/RestAPI/api/axiosApicall", () => ({
  CertAxios: jest.fn(),
}));

await jest.unstable_mockModule("@/RestAPI/url/endpoint", () => ({
  GET_ROOT_OR_SUB_CA_URL: "/get-root-or-sub-ca",
  UPLOAD_CERT_ROOT_OR_SUB: "/upload-cert-root-or-sub",
}));

await jest.unstable_mockModule("@/components/Reusable/Toast/Toast", () => ({
  __esModule: true,
  default: jest.fn(),
}));

await jest.unstable_mockModule("@/components/Reusable/Button/MButtonPrimary", () => ({
  __esModule: true,
  default: ({ children, onClick, disabled }) => (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      data-testid={`btn-${children}`}
    >
      {children}
    </button>
  ),
}));

await jest.unstable_mockModule("@/components/Reusable/Table/MTable", () => ({
  __esModule: true,
  default: (props) => {
    latestTableProps = props;
    const validityCol = props.columns.find(
      (c) => c.uid === "validityStatus"
    );

    return (
      <div data-testid="mtable">
        <span data-testid="table-title">{props.tableTitle}</span>
        <span data-testid="table-row-count">{props.tableData.length}</span>
        {props.tableData.map((row, idx) => (
          <div key={`${row.sno}-${idx}`} data-testid={`ca-row-${idx}`}>
            <span data-testid={`ca-type-${idx}`}>{row.caType}</span>
            <span data-testid={`ca-file-${idx}`}>{row.CaFilename1}</span>
            <span data-testid={`ca-validity-${idx}`}>{row.validity}</span>
            <span data-testid={`ca-icon-${idx}`}>
              {validityCol?.render ? validityCol.render(row.validity, row) : null}
            </span>
          </div>
        ))}
        <span data-testid="null-row-validity">
          {validityCol?.render ? validityCol.render(null, null) : null}
        </span>
      </div>
    );
  },
}));

// Import mocked bindings and the component only after ESM mocks are registered.
({ CertAxios } = await import("@/RestAPI/api/axiosApicall"));
({
  GET_ROOT_OR_SUB_CA_URL,
  UPLOAD_CERT_ROOT_OR_SUB,
} = await import("@/RestAPI/url/endpoint"));
({ default: Toast } = await import("@/components/Reusable/Toast/Toast"));
({ default: UploadRootOrSubCA } = await import(
  "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/XCertificate/UploadRootOrSubCA"
));

/* -------------------------------------------------------
   HELPERS & SAMPLE DATA
------------------------------------------------------- */

const sampleCerts = [
  {
    caType: 1,
    caFilename1: "modem_root.cer",
    caFilename2: "nms_root.cer",
    caIssuedate: "2024-01-01T00:00:00Z",
    caExpiredate: "2029-01-01T00:00:00Z",
  },
  {
    caType: 2,
    CaFilename1: "modem_sub.der",
    CaFilename2: "nms_sub.der",
    caIssuedate: "2020-01-01T00:00:00Z",
    caExpiredate: "2021-01-01T00:00:00Z",
  },
];

const createFile = (name, sizeBytes, type = "application/x-x509-ca-cert") => {
  const file = new File(["cert-content"], name, { type });
  Object.defineProperty(file, "size", {
    value: sizeBytes,
    configurable: true,
  });
  return file;
};

const renderComponent = (props = {}, mode = "light") => {
  const theme = createTheme({ palette: { mode } });
  return render(
    <ThemeProvider theme={theme}>
      <UploadRootOrSubCA
        refreshTrigger={0}
        privilegeKey="CERT_MGMT"
        {...props}
      />
    </ThemeProvider>
  );
};

/* -------------------------------------------------------
   TEST SUITE
------------------------------------------------------- */

describe("UploadRootOrSubCA Component", () => {
  beforeEach(() => {
    jest.clearAllMocks();
    latestTableProps = undefined;

    CertAxios.mockImplementation((url) => {
      if (url === GET_ROOT_OR_SUB_CA_URL) {
        return Promise.resolve({ data: sampleCerts });
      }
      if (url === UPLOAD_CERT_ROOT_OR_SUB) {
        return Promise.resolve({ data: { status: true } });
      }
      return Promise.resolve({ data: [] });
    });

    jest.spyOn(console, "error").mockImplementation(() => {});
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  /* -------------------------------------------------------
     INITIAL RENDER & DATA FETCHING
  ------------------------------------------------------- */

  describe("Initial rendering and certificate data fetch", () => {
    it("renders Root and Sub CA upload cards and expands rows in table", async () => {
      renderComponent({}, "dark");

      expect(screen.getByTestId("btn-UPLOAD ROOT CA")).toBeInTheDocument();
      expect(screen.getByTestId("btn-UPLOAD SUB CA")).toBeInTheDocument();
      expect(screen.getByTestId("table-title")).toHaveTextContent(
        "Root and Sub CA"
      );

      await waitFor(() => {
        expect(screen.getByTestId("table-row-count")).toHaveTextContent("4");
      });

      expect(CertAxios).toHaveBeenCalledWith(GET_ROOT_OR_SUB_CA_URL, "get");
      expect(latestTableProps.privilegeKey).toBe("CERT_MGMT");

      // Root CA main + shadow rows (Valid)
      expect(screen.getByTestId("ca-type-0")).toHaveTextContent("Modem_Root_CA");
      expect(screen.getByTestId("ca-file-0")).toHaveTextContent(
        "modem_root.cer"
      );
      expect(screen.getByTestId("ca-validity-0")).toHaveTextContent("Valid");

      expect(screen.getByTestId("ca-type-1")).toHaveTextContent(
        "TotalNMS_Root_CA"
      );
      expect(screen.getByTestId("ca-file-1")).toHaveTextContent("nms_root.cer");

      // Sub CA main + shadow rows (Expired)
      expect(screen.getByTestId("ca-type-2")).toHaveTextContent("Modem_Sub_CA");
      expect(screen.getByTestId("ca-file-2")).toHaveTextContent("modem_sub.der");
      expect(screen.getByTestId("ca-validity-2")).toHaveTextContent("Expired");

      expect(screen.getByTestId("ca-type-3")).toHaveTextContent(
        "TotalNMS_Sub_CA"
      );
      expect(screen.getByTestId("ca-file-3")).toHaveTextContent("nms_sub.der");

      expect(screen.getByTestId("null-row-validity")).toBeEmptyDOMElement();
    });

    it("re-fetches data when refreshTrigger changes", async () => {
      const { rerender } = renderComponent({ refreshTrigger: 1 });

      await waitFor(() => {
        expect(screen.getByTestId("table-row-count")).toHaveTextContent("4");
      });

      rerender(<UploadRootOrSubCA refreshTrigger={2} />);

      await waitFor(() => {
        const getCalls = CertAxios.mock.calls.filter(
          ([url]) => url === GET_ROOT_OR_SUB_CA_URL
        );
        expect(getCalls).toHaveLength(2);
      });
    });

    it("handles non-array response data and fetch errors", async () => {
      CertAxios.mockResolvedValueOnce({ data: null });

      const { unmount } = renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("table-row-count")).toHaveTextContent("0");
      });
      unmount();

      CertAxios.mockRejectedValueOnce(new Error("Fetch error"));

      renderComponent();

      await waitFor(() => {
        expect(Toast).toHaveBeenCalledWith(
          "Error!",
          "Failed to fetch details",
          "error"
        );
      });
      expect(screen.getByTestId("table-row-count")).toHaveTextContent("0");
    });
  });

  /* -------------------------------------------------------
     FILE SELECTION & VALIDATION
  ------------------------------------------------------- */

  describe("File selection and validation", () => {
    it("warns when selected file exceeds 20KB limit", async () => {
      const { container } = renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("table-row-count")).toHaveTextContent("4");
      });

      const fileInputs = container.querySelectorAll('input[type="file"]');
      const largeFile = createFile("large.cer", 25000);

      fireEvent.change(fileInputs[0], { target: { files: [largeFile] } });

      expect(Toast).toHaveBeenCalledWith(
        "Warning",
        "File size should not be more than 20 kB",
        "info"
      );
      expect(CertAxios).not.toHaveBeenCalledWith(
        UPLOAD_CERT_ROOT_OR_SUB,
        expect.anything(),
        expect.anything()
      );
    });

    it("triggers file input click when Upload button is clicked", async () => {
      const clickSpy = jest
        .spyOn(HTMLInputElement.prototype, "click")
        .mockImplementation(() => {});

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("table-row-count")).toHaveTextContent("4");
      });

      fireEvent.click(screen.getByTestId("btn-UPLOAD ROOT CA"));
      expect(clickSpy).toHaveBeenCalledTimes(1);

      clickSpy.mockRestore();
    });
  });

  /* -------------------------------------------------------
     UPLOAD SUBMISSION & RESPONSES
  ------------------------------------------------------- */

  describe("Certificate upload flow", () => {
    it("uploads Root CA file, shows success toast, and refreshes table", async () => {
      const { container } = renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("table-row-count")).toHaveTextContent("4");
      });

      const fileInputs = container.querySelectorAll('input[type="file"]');
      const validFile = createFile("root.cer", 1024);

      fireEvent.change(fileInputs[0], { target: { files: [validFile] } });

      await waitFor(() => {
        expect(CertAxios).toHaveBeenCalledWith(
          UPLOAD_CERT_ROOT_OR_SUB,
          "post",
          expect.any(FormData)
        );
      });

      const uploadCall = CertAxios.mock.calls.find(
        ([url]) => url === UPLOAD_CERT_ROOT_OR_SUB
      );
      const formData = uploadCall[2];
      expect(formData.get("id")).toBe("1");
      expect(formData.get("caType")).toBe("1");
      expect(formData.get("certFile")).toBe(validFile);

      expect(Toast).toHaveBeenCalledWith(
        "Success",
        "Certificate File Uploaded",
        "success"
      );
    });

    it("uploads Sub CA file and shows custom or default error message when upload fails", async () => {
      CertAxios.mockImplementation((url) => {
        if (url === GET_ROOT_OR_SUB_CA_URL) {
          return Promise.resolve({ data: sampleCerts });
        }
        if (url === UPLOAD_CERT_ROOT_OR_SUB) {
          return Promise.resolve({
            data: { status: false, errorMessage: "Invalid DER format" },
          });
        }
        return Promise.resolve({ data: [] });
      });

      const { container } = renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("table-row-count")).toHaveTextContent("4");
      });

      const fileInputs = container.querySelectorAll('input[type="file"]');
      fireEvent.change(fileInputs[1], {
        target: { files: [createFile("sub.der", 500)] },
      });

      await waitFor(() => {
        expect(Toast).toHaveBeenCalledWith(
          "Error",
          "Invalid DER format",
          "error"
        );
      });

      // Fallback error message branch
      CertAxios.mockResolvedValueOnce({ data: {} });
      fireEvent.change(fileInputs[1], {
        target: { files: [createFile("sub2.der", 500)] },
      });

      await waitFor(() => {
        expect(Toast).toHaveBeenCalledWith(
          "Error",
          "Upload failed",
          "error"
        );
      });
    });

    it("shows server error toast and disables upload buttons while uploading", async () => {
      let resolveUpload;

      CertAxios.mockImplementation((url) => {
        if (url === GET_ROOT_OR_SUB_CA_URL) {
          return Promise.resolve({ data: sampleCerts });
        }
        if (url === UPLOAD_CERT_ROOT_OR_SUB) {
          return new Promise((resolve) => {
            resolveUpload = resolve;
          });
        }
        return Promise.resolve({ data: [] });
      });

      const { container } = renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("table-row-count")).toHaveTextContent("4");
      });

      const fileInputs = container.querySelectorAll('input[type="file"]');
      fireEvent.change(fileInputs[0], {
        target: { files: [createFile("pending.cer", 800)] },
      });

      await waitFor(() => {
        expect(screen.getByTestId("btn-UPLOAD ROOT CA")).toBeDisabled();
        expect(screen.getByTestId("btn-UPLOAD SUB CA")).toBeDisabled();
      });

      await act(async () => {
        resolveUpload({ data: { status: true } });
      });

      await waitFor(() => {
        expect(screen.getByTestId("btn-UPLOAD ROOT CA")).toBeEnabled();
      });

      // Rejected request branch
      CertAxios.mockRejectedValueOnce(new Error("500 Server Error"));
      fireEvent.change(fileInputs[0], {
        target: { files: [createFile("err.cer", 800)] },
      });

      await waitFor(() => {
        expect(Toast).toHaveBeenCalledWith(
          "Error",
          "Failed to upload Certificate File! Server Error",
          "error"
        );
      });
    });
  });
});
