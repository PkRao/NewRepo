import React from "react";
import { jest } from "@jest/globals";
import { render, screen, fireEvent } from "@testing-library/react";
import "@testing-library/jest-dom";

const { default: MapTopRightControls } = await import(
  "../../src/Pages/CnmsDashboard/CnmsMap/components/MapTopRightControls"
);

describe("MapTopRightControls", () => {
  let setFilterAnchorEl;
  let setConfigAnchorEl;
  let setIsMiniMapOpen;

  const renderComponent = (isMiniMapOpen = false) =>
    render(
      <MapTopRightControls
        setFilterAnchorEl={setFilterAnchorEl}
        setConfigAnchorEl={setConfigAnchorEl}
        setIsMiniMapOpen={setIsMiniMapOpen}
        isMiniMapOpen={isMiniMapOpen}
      />
    );

  beforeEach(() => {
    jest.clearAllMocks();

    setFilterAnchorEl = jest.fn();
    setConfigAnchorEl = jest.fn();
    setIsMiniMapOpen = jest.fn();
  });

  test("renders all three control buttons", () => {
    renderComponent();

    expect(screen.getByTitle("Filter")).toBeInTheDocument();
    expect(screen.getByTitle("Settings")).toBeInTheDocument();
    expect(screen.getByTitle("Min map")).toBeInTheDocument();
  });

  test("renders filter image", () => {
    renderComponent();

    expect(screen.getByAltText("filter")).toHaveAttribute(
      "src",
      "Filter Birdeye.svg"
    );
  });

  test("renders settings image", () => {
    renderComponent();

    expect(screen.getByAltText("settings")).toHaveAttribute(
      "src",
      "Filter site.svg"
    );
  });

  test("renders minimap image", () => {
    renderComponent();

    expect(screen.getByAltText("min map")).toHaveAttribute(
      "src",
      "ALL_Reports_View.svg"
    );
  });

  test("opens filter using currentTarget", () => {
    renderComponent();

    const button = screen.getByTitle("Filter");
    fireEvent.click(button);

    expect(setFilterAnchorEl).toHaveBeenCalledWith(button);
    expect(setFilterAnchorEl).toHaveBeenCalledTimes(1);
  });

  test("opens settings using currentTarget", () => {
    renderComponent();

    const button = screen.getByTitle("Settings");
    fireEvent.click(button);

    expect(setConfigAnchorEl).toHaveBeenCalledWith(button);
    expect(setConfigAnchorEl).toHaveBeenCalledTimes(1);
  });

  test("toggles minimap from closed to open", () => {
    renderComponent(false);

    fireEvent.click(screen.getByTitle("Min map"));

    expect(setIsMiniMapOpen).toHaveBeenCalledWith(true);
  });

  test("toggles minimap from open to closed", () => {
    renderComponent(true);

    fireEvent.click(screen.getByTitle("Min map"));

    expect(setIsMiniMapOpen).toHaveBeenCalledWith(false);
  });

  test("uses correct rotation when minimap is open", () => {
    renderComponent(true);

    expect(screen.getByAltText("min map")).toHaveStyle({
      transform: "rotate(90deg)",
    });
  });

  test("uses correct rotation when minimap is closed", () => {
    renderComponent(false);

    expect(screen.getByAltText("min map")).toHaveStyle({
      transform: "rotate(-90deg)",
    });
  });
});
