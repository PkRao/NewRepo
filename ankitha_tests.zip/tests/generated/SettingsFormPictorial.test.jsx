import React from "react";
import { jest } from "@jest/globals";
import {
  render,
  screen,
  fireEvent,
  waitFor,
  cleanup,
} from "@testing-library/react";
import "@testing-library/jest-dom";

// ======================================================
// ESM MOCKS
// ======================================================

jest.unstable_mockModule("react-redux", () => ({
  useDispatch: jest.fn(),
  useSelector: jest.fn(),
}));

jest.unstable_mockModule("@mui/material", () => {
  const actual = jest.requireActual("@mui/material");

  return {
    ...actual,
    useTheme: jest.fn(),
  };
});

jest.unstable_mockModule("@/RestAPI/api/axiosApicall", () => ({
  InventoryAxios: jest.fn(),
}));

jest.unstable_mockModule("@/store/features/Tooltip/toolTipSlice", () => ({
  setTopologyTooltipOptions: jest.fn((payload) => ({
    type: "toolTipOptions/setTopologyTooltipOptions",
    payload,
  })),
}));

jest.unstable_mockModule("@/components/Reusable/Toast/Toast", () => ({
  default: jest.fn(),
}));

jest.unstable_mockModule(
  "@/components/Reusable/Button/MButtonPrimary",
  () => ({
    default: ({ children, onClick, disabled }) =>
      React.createElement(
        "button",
        { onClick, disabled },
        children
      ),
  })
);

// ======================================================
// DYNAMIC IMPORTS AFTER MOCK REGISTRATION
// ======================================================

const { useDispatch, useSelector } = await import("react-redux");

const { useTheme } = await import("@mui/material");

const { default: SettingsFormPictorial } = await import(
  "@/Pages/CnmsDashboard/BirdEyeView/SettingsFormPictorial"
);

const { InventoryAxios } = await import(
  "@/RestAPI/api/axiosApicall"
);

const { SAVE_TOOLTIP_OPTIONS } = await import(
  "@/RestAPI/url/endpoint"
);

const { setTopologyTooltipOptions } = await import(
  "@/store/features/Tooltip/toolTipSlice"
);

const { default: Toast } = await import(
  "@/components/Reusable/Toast/Toast"
);

// ======================================================
// MOCK DATA
// ======================================================

const defaultOptions = {
  remoteType: true,
  vehNumber: true,
  longitude: true,
  latitude: true,
  status: true,
  activeLink: true,
  remoteId: true,
  maintainance: true,
  siteName: true,
  vehRunTime: true,
  selectAll: true,
};

const allDisabledOptions = {
  remoteType: false,
  vehNumber: false,
  longitude: false,
  latitude: false,
  status: false,
  activeLink: false,
  remoteId: false,
  maintainance: false,
  siteName: false,
  vehRunTime: false,
  selectAll: false,
};

let mockDispatch;
let mockSetShowSettingsModal;

// ======================================================
// SETUP
// ======================================================

const renderComponent = (savedOptions = null) => {
  useSelector.mockImplementation((selector) =>
    selector({
      toolTipOptionsSlice: {
        topologyToolTipOptions: savedOptions,
      },
    })
  );

  return render(
    <SettingsFormPictorial
      setShowSettingsModal={mockSetShowSettingsModal}
    />
  );
};

beforeEach(() => {
  jest.clearAllMocks();

  mockDispatch = jest.fn();
  mockSetShowSettingsModal = jest.fn();

  useDispatch.mockReturnValue(mockDispatch);

  useTheme.mockReturnValue({
    palette: {
      mode: "light",
    },
  });
});

afterEach(() => {
  cleanup();
});

// ======================================================
// INITIAL RENDERING
// ======================================================

describe("SettingsFormPictorial Component", () => {
  describe("Initial Rendering", () => {
    test("renders component successfully", () => {
      renderComponent();

      expect(
        screen.getByText("CONFIGURABLE PARAMETERS")
      ).toBeInTheDocument();
    });

    test("renders Select All checkbox", () => {
      renderComponent();

      expect(
        screen.getByLabelText("Select All")
      ).toBeInTheDocument();
    });

    test("renders all tooltip configuration options", () => {
      renderComponent();

      const labels = [
        "Remote Type",
        "Veh. Number",
        "Longitude",
        "Latitude",
        "Status",
        "Active Link",
        "Remote Id",
        "Maintainance",
        "Site Name",
        "Veh. Run Time",
      ];

      labels.forEach((label) => {
        expect(
          screen.getByLabelText(label)
        ).toBeInTheDocument();
      });
    });

    test("renders Save button", () => {
      renderComponent();

      expect(
        screen.getByRole("button", { name: "Save" })
      ).toBeInTheDocument();
    });

    test("all options are checked by default", () => {
      renderComponent();

      const labels = [
        "Remote Type",
        "Veh. Number",
        "Longitude",
        "Latitude",
        "Status",
        "Active Link",
        "Remote Id",
        "Maintainance",
        "Site Name",
        "Veh. Run Time",
      ];

      Object.keys(defaultOptions)
        .filter((key) => key !== "selectAll")
        .forEach((key, index) => {
          expect(
            screen.getByLabelText(labels[index])
          ).toBeChecked();
        });
    });

    test("Select All is checked by default", () => {
      renderComponent();

      expect(
        screen.getByLabelText("Select All")
      ).toBeChecked();
    });
  });

  // ======================================================
  // REDUX INTEGRATION
  // ======================================================

  describe("Redux Integration", () => {
    test("reads tooltip options from Redux", () => {
      renderComponent();

      expect(useSelector).toHaveBeenCalledWith(
        expect.any(Function)
      );
    });

    test("initializes saved preferences from Redux", () => {
      const savedOptions = {
        ...defaultOptions,
        remoteType: false,
        status: false,
      };

      renderComponent(savedOptions);

      expect(
        screen.getByLabelText("Remote Type")
      ).not.toBeChecked();

      expect(
        screen.getByLabelText("Status")
      ).not.toBeChecked();

      expect(
        screen.getByLabelText("Longitude")
      ).toBeChecked();
    });

    test("ignores legacy unsupported options", () => {
      const savedOptions = {
        remoteType: true,
        resourceName: false,
        resourceType: false,
      };

      renderComponent(savedOptions);

      expect(
        screen.getByLabelText("Remote Type")
      ).toBeChecked();

      expect(
        screen.getByLabelText("Veh. Number")
      ).toBeChecked();

      expect(
        screen.queryByLabelText("Resource Name")
      ).not.toBeInTheDocument();
    });

    test("defaults missing supported options to true", () => {
      renderComponent({
        remoteType: false,
      });

      expect(
        screen.getByLabelText("Remote Type")
      ).not.toBeChecked();

      expect(
        screen.getByLabelText("Longitude")
      ).toBeChecked();

      expect(
        screen.getByLabelText("Site Name")
      ).toBeChecked();
    });
  });

  // ======================================================
  // INDIVIDUAL CHECKBOX
  // ======================================================

  describe("Individual Checkbox Functionality", () => {
    test("unchecks an individual option", () => {
      renderComponent();

      const checkbox = screen.getByLabelText("Remote Type");

      fireEvent.click(checkbox);

      expect(checkbox).not.toBeChecked();
    });

    test("checks an unchecked individual option", () => {
      renderComponent(allDisabledOptions);

      const checkbox = screen.getByLabelText("Remote Type");

      fireEvent.click(checkbox);

      expect(checkbox).toBeChecked();
    });

    test("updates Select All when one option is unchecked", () => {
      renderComponent();

      fireEvent.click(
        screen.getByLabelText("Remote Type")
      );

      expect(
        screen.getByLabelText("Select All")
      ).not.toBeChecked();
    });

    test("updates Select All when all options are checked", () => {
      renderComponent(allDisabledOptions);

      const labels = [
        "Remote Type",
        "Veh. Number",
        "Longitude",
        "Latitude",
        "Status",
        "Active Link",
        "Remote Id",
        "Maintainance",
        "Site Name",
        "Veh. Run Time",
      ];

      labels.forEach((label) => {
        fireEvent.click(screen.getByLabelText(label));
      });

      expect(
        screen.getByLabelText("Select All")
      ).toBeChecked();
    });

    test("preserves other checkbox selections", () => {
      renderComponent();

      fireEvent.click(
        screen.getByLabelText("Remote Type")
      );

      expect(
        screen.getByLabelText("Veh. Number")
      ).toBeChecked();

      expect(
        screen.getByLabelText("Longitude")
      ).toBeChecked();
    });
  });

  // ======================================================
  // SELECT ALL
  // ======================================================

  describe("Select All Functionality", () => {
    test("unchecks all options when Select All is unchecked", () => {
      renderComponent();

      fireEvent.click(
        screen.getByLabelText("Select All")
      );

      const labels = [
        "Remote Type",
        "Veh. Number",
        "Longitude",
        "Latitude",
        "Status",
        "Active Link",
        "Remote Id",
        "Maintainance",
        "Site Name",
        "Veh. Run Time",
      ];

      labels.forEach((label) => {
        expect(
          screen.getByLabelText(label)
        ).not.toBeChecked();
      });
    });

    test("checks all options when Select All is checked", () => {
      renderComponent(allDisabledOptions);

      fireEvent.click(
        screen.getByLabelText("Select All")
      );

      const labels = [
        "Remote Type",
        "Veh. Number",
        "Longitude",
        "Latitude",
        "Status",
        "Active Link",
        "Remote Id",
        "Maintainance",
        "Site Name",
        "Veh. Run Time",
      ];

      labels.forEach((label) => {
        expect(
          screen.getByLabelText(label)
        ).toBeChecked();
      });
    });

    test("shows indeterminate state when some options are unchecked", () => {
      renderComponent();

      fireEvent.click(
        screen.getByLabelText("Remote Type")
      );

      const selectAll = screen.getByLabelText("Select All");

      expect(selectAll).not.toBeChecked();
      expect(selectAll).toBePartiallyChecked();
    });

    test("does not show indeterminate state when all options are unchecked", () => {
      renderComponent(allDisabledOptions);

      const selectAll = screen.getByLabelText("Select All");

      expect(selectAll).not.toBeChecked();
      expect(selectAll).not.toBePartiallyChecked();
    });
  });

  // ======================================================
  // SAVE SETTINGS
  // ======================================================

  describe("Save Settings Functionality", () => {
    test("calls InventoryAxios with correct API arguments", async () => {
      InventoryAxios.mockResolvedValue({
        status: 200,
      });

      renderComponent();

      fireEvent.click(
        screen.getByRole("button", { name: "Save" })
      );

      await waitFor(() => {
        expect(InventoryAxios).toHaveBeenCalledWith(
          SAVE_TOOLTIP_OPTIONS,
          "post",
          {
            id: 2,
            value: JSON.stringify(defaultOptions),
          }
        );
      });
    });

    test("dispatches Redux action after successful save", async () => {
      InventoryAxios.mockResolvedValue({
        status: 200,
      });

      renderComponent();

      fireEvent.click(
        screen.getByRole("button", { name: "Save" })
      );

      await waitFor(() => {
        expect(setTopologyTooltipOptions).toHaveBeenCalledWith(
          defaultOptions
        );

        expect(mockDispatch).toHaveBeenCalled();
      });
    });

    test("shows success toast after successful save", async () => {
      InventoryAxios.mockResolvedValue({
        status: 200,
      });

      renderComponent();

      fireEvent.click(
        screen.getByRole("button", { name: "Save" })
      );

      await waitFor(() => {
        expect(Toast).toHaveBeenCalledWith(
          "Success",
          "Settings saved successfully!",
          "success"
        );
      });
    });

    test("saves updated checkbox preferences", async () => {
      InventoryAxios.mockResolvedValue({
        status: 200,
      });

      renderComponent();

      fireEvent.click(
        screen.getByLabelText("Remote Type")
      );

      fireEvent.click(
        screen.getByRole("button", { name: "Save" })
      );

      const updatedOptions = {
        ...defaultOptions,
        remoteType: false,
        selectAll: false,
      };

      await waitFor(() => {
        expect(InventoryAxios).toHaveBeenCalledWith(
          SAVE_TOOLTIP_OPTIONS,
          "post",
          {
            id: 2,
            value: JSON.stringify(updatedOptions),
          }
        );
      });
    });

    test("closes settings modal after successful save", async () => {
      InventoryAxios.mockResolvedValue({
        status: 200,
      });

      renderComponent();

      fireEvent.click(
        screen.getByRole("button", { name: "Save" })
      );

      await waitFor(() => {
        expect(
          mockSetShowSettingsModal
        ).toHaveBeenCalledWith(null);
      });
    });
  });

  // ======================================================
  // API FAILURE
  // ======================================================

  describe("Save Failure Handling", () => {
    test("shows error toast when API returns non-200 status", async () => {
      InventoryAxios.mockResolvedValue({
        status: 500,
      });

      renderComponent();

      fireEvent.click(
        screen.getByRole("button", { name: "Save" })
      );

      await waitFor(() => {
        expect(Toast).toHaveBeenCalledWith(
          "Failed",
          "Failed to save settings",
          "error"
        );
      });
    });

    test("does not dispatch Redux action when API fails", async () => {
      InventoryAxios.mockResolvedValue({
        status: 500,
      });

      renderComponent();

      fireEvent.click(
        screen.getByRole("button", { name: "Save" })
      );

      await waitFor(() => {
        expect(Toast).toHaveBeenCalled();
      });

      expect(mockDispatch).not.toHaveBeenCalled();
    });

    test("shows error toast when API throws an exception", async () => {
      InventoryAxios.mockRejectedValue(
        new Error("Network Error")
      );

      const consoleSpy = jest
        .spyOn(console, "error")
        .mockImplementation(() => {});

      renderComponent();

      fireEvent.click(
        screen.getByRole("button", { name: "Save" })
      );

      await waitFor(() => {
        expect(Toast).toHaveBeenCalledWith(
          "Failed",
          "Failed to save settings",
          "error"
        );
      });

      consoleSpy.mockRestore();
    });

    test("closes settings modal even when API fails", async () => {
      InventoryAxios.mockRejectedValue(
        new Error("Network Error")
      );

      jest.spyOn(console, "error").mockImplementation(() => {});

      renderComponent();

      fireEvent.click(
        screen.getByRole("button", { name: "Save" })
      );

      await waitFor(() => {
        expect(
          mockSetShowSettingsModal
        ).toHaveBeenCalledWith(null);
      });

      jest.restoreAllMocks();
    });
  });

  // ======================================================
  // THEME
  // ======================================================

  describe("Theme Integration", () => {
    test("supports light theme", () => {
      useTheme.mockReturnValue({
        palette: {
          mode: "light",
        },
      });

      renderComponent();

      expect(
        screen.getByText("CONFIGURABLE PARAMETERS")
      ).toBeInTheDocument();
    });

    test("supports dark theme", () => {
      useTheme.mockReturnValue({
        palette: {
          mode: "dark",
        },
      });

      renderComponent();

      expect(
        screen.getByText("CONFIGURABLE PARAMETERS")
      ).toBeInTheDocument();
    });
  });
});
