import { getCachedLayout, setCachedLayout, clearLayoutCache } from '../../src/core/utils/layoutCache';

describe('layout cache', () => {
  beforeEach(() => clearLayoutCache());
  test('returns undefined for an uncached terminal type', () => expect(getCachedLayout('MK-I')).toBeUndefined());
  test('stores and retrieves layout by terminal type', () => {
    const layout = { status: [{ name: 'General' }] };
    expect(setCachedLayout('MK-I', layout)).toBeInstanceOf(Map);
    expect(getCachedLayout('MK-I')).toBe(layout);
  });
  test('overwrites existing cache entries', () => {
    setCachedLayout('MK-I', { version: 1 });
    setCachedLayout('MK-I', { version: 2 });
    expect(getCachedLayout('MK-I')).toEqual({ version: 2 });
  });
  test('clear removes all cached layouts', () => {
    setCachedLayout('MK-I', {});
    setCachedLayout('MK-II', {});
    clearLayoutCache();
    expect(getCachedLayout('MK-I')).toBeUndefined();
    expect(getCachedLayout('MK-II')).toBeUndefined();
  });
});
