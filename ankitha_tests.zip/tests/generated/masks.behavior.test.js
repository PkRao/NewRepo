import { formatIPv4, formatIPv6, formatLatitude, formatLongitude } from '../../src/utility/masks';

describe('IP and coordinate input formatters', () => {
  test.each([
    ['192.168.1.10', '192.168.1.10'],
    ['192.168.001.010', '192.168.1.10'],
    ['999.1.2.3', '255.1.2.3'],
    ['.10..20', '10.20'],
    ['10.20.30.40.50', '10.20.30.40'],
  ])('formatIPv4(%s)', (input, expected) => expect(formatIPv4(input)).toBe(expected));

  test('adds a separator after a complete octet while typing', () => {
    expect(formatIPv4('192')).toBe('192.');
    expect(formatIPv4('192.168.')).toBe('192.168.');
  });

  test('normalizes IPv6 characters, repeated colons and maximum length', () => {
    expect(formatIPv6('ABCD::::EF01')).toBe('abcd::ef01');
    expect(formatIPv6('xyz:12')).toBe(':12');
    expect(formatIPv6('a'.repeat(50))).toHaveLength(39);
  });

  test.each([
    ['91.123456', '90'],
    ['-91', '-90'],
    ['12.123456', '12.1234'],
    ['1.2.3', '1.2'],
    ['abc-12.34', '-12.34'],
  ])('formatLatitude(%s)', (input, expected) => expect(formatLatitude(input)).toBe(expected));

  test.each([
    ['181.12345', '180'],
    ['-181', '-180'],
    ['12.123456', '12.1234'],
    ['1.2.3', '1.2'],
  ])('formatLongitude(%s)', (input, expected) => expect(formatLongitude(input)).toBe(expected));
});
