import React from "react";
import { jest } from "@jest/globals";
import { render, screen, fireEvent, cleanup, act, waitFor } from "@testing-library/react";

const mockUseSelector = jest.fn();
const mockUseDispatch = jest.fn(() => jest.fn());
jest.unstable_mockModule("react-redux", () => ({
  useSelector: mockUseSelector,
  useDispatch: mockUseDispatch,
}));

// ESM mocks must be registered before importing BirdEyeView.
jest.unstable_mockModule("@/components/Reusable/Select/MSelect", () => ({
  __esModule: true,
  default: ({ label, options = [], value, onChange }) => (
    <label>
      {label}
      <select
        aria-label={label}
        value={value}
        onChange={(event) => onChange(event.target.value)}
      >
        {options.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
    </label>
  ),
}));

jest.unstable_mockModule("@/components/Dialogs/AlarmSuppression/MAlarmSelect", () => ({
  __esModule: true,
  default: ({ label, options = [], value = [], onChange }) => (
    <fieldset>
      <legend>{label}</legend>
      {options.map((option) => (
        <label key={option.value}>
          <input
            type="checkbox"
            aria-label={option.label}
            checked={value.includes(option.value)}
            onChange={(event) => {
              const next = event.target.checked
                ? [...value, option.value]
                : value.filter((item) => item !== option.value);
              onChange(next);
            }}
          />
          {option.label}
        </label>
      ))}
    </fieldset>
  ),
}));

jest.unstable_mockModule("@/Pages/CnmsDashboard/BirdEyeView/PictorialView", () => ({
  __esModule: true,
  default: ({ sitesToDisplay = [] }) => (
    <div data-testid="pictorial-view">
      {sitesToDisplay.map((site) => (
        <span key={site.siteId}>{site.siteId}</span>
      ))}
    </div>
  ),
}));

jest.unstable_mockModule("@/Pages/CnmsDashboard/BirdEyeView/RightSidePanel", () => ({
  __esModule: true,
  default: ({ selectedPath, onClose }) => (
    <div data-testid="right-side-panel">
      <span>{selectedPath}</span>
      <button onClick={onClose}>Close Panel</button>
    </div>
  ),
}));

const { default: BirdEyeView } = await import(
  "@/Pages/CnmsDashboard/BirdEyeView/BirdEyeView"
);




// ======================================================
// MOCKS
// ======================================================

jest.mock("d3", () => {
  const actualD3 = jest.requireActual("d3");

  return {
    ...actualD3,
    partition: actualD3.partition,
    hierarchy: actualD3.hierarchy,
    arc: actualD3.arc,
    select: actualD3.select,
  };
});

jest.mock("geolib", () => ({
  getCompassDirection: jest.fn(() => "North"),
}));

jest.mock("@/Pages/CnmsDashboard/BirdEyeView/PictorialView", () => ({
  __esModule: true,
  default: ({ sitesToDisplay = [] }) => (
    <div data-testid="pictorial-view">
      {sitesToDisplay.map((site) => (
        <span key={site.siteId}>{site.siteId}</span>
      ))}
    </div>
  ),
}));

jest.mock("@/Pages/CnmsDashboard/BirdEyeView/RightSidePanel", () => ({
  __esModule: true,
  default: ({ selectedPath, onClose }) => (
    <div data-testid="right-side-panel">
      <span>{selectedPath}</span>
      <button onClick={onClose}>Close Panel</button>
    </div>
  ),
}));

jest.mock("@/components/Reusable/Select/MSelect", () => ({
  __esModule: true,
  default: ({ label, options = [], value, onChange }) => (
    <label>
      {label}
      <select
        aria-label={label}
        value={value}
        onChange={(e) => onChange(e.target.value)}
      >
        {options.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
    </label>
  ),
}));

jest.mock("@/components/Dialogs/AlarmSuppression/MAlarmSelect", () => ({
  __esModule: true,
  default: ({ label, options = [], value = [], onChange }) => (
    <fieldset>
      <legend>{label}</legend>
      {options.map((option) => (
        <label key={option.value}>
          <input
            type="checkbox"
            checked={value.includes(option.value)}
            onChange={(e) => {
              const nextValue = e.target.checked
                ? [...value, option.value]
                : value.filter((item) => item !== option.value);

              onChange(nextValue);
            }}
          />
          {option.label}
        </label>
      ))}
    </fieldset>
  ),
}));

jest.mock("@/components/Reusable/Button/MButtonPrimary", () => ({
  __esModule: true,
  default: ({ children, onClick, disabled }) => (
    <button onClick={onClick} disabled={disabled}>
      {children}
    </button>
  ),
}));

// ======================================================
// BROWSER API MOCKS
// ======================================================

beforeAll(() => {
  global.ResizeObserver = class ResizeObserver {
    observe() {}
    unobserve() {}
    disconnect() {}
  };

  global.requestAnimationFrame = jest.fn(() => 1);
  global.cancelAnimationFrame = jest.fn();
});

afterEach(() => {
  cleanup();
  jest.clearAllMocks();
});


beforeEach(() => {
  jest.clearAllMocks();

  global.ResizeObserver = jest.fn().mockImplementation((callback) => ({
    observe: jest.fn(() => callback?.()),
    unobserve: jest.fn(),
    disconnect: jest.fn(),
  }));

  global.requestAnimationFrame = jest.fn((callback) => {
    callback();
    return 1;
  });

  global.cancelAnimationFrame = jest.fn();

  global.URL.createObjectURL = jest.fn(() => "blob:test-url");
  global.URL.revokeObjectURL = jest.fn();

  global.Image = jest.fn().mockImplementation(() => {
    const image = {};

    Object.defineProperty(image, "src", {
      set() {
        Promise.resolve().then(() => image.onload?.());
      },
    });

    Object.defineProperty(HTMLElement.prototype, "clientWidth", {
      configurable: true,
      get: () => 800,
    });
    
    Object.defineProperty(HTMLElement.prototype, "clientHeight", {
      configurable: true,
      get: () => 600,
    });

    return image;
  });



  window.alert = jest.fn();

  window.open = jest.fn();
});
// ======================================================
// REDUX MOCK DATA
// ======================================================

const mockSites = [
  {
    siteId: "SITE001",
    siteName: "Chennai Site",
    latitude: 13.0827,
    longitude: 80.2707,
    imTerminalType: { terminalTypeName: "VSAT" },
    imTerminalMode: { name: "LOCAL" },
    healthStatus: { value: "Online" },
  },
  {
    siteId: "SITE002",
    siteName: "Mumbai Site",
    latitude: 19.076,
    longitude: 72.8777,
    imTerminalType: { terminalTypeName: "RADIO" },
    imTerminalMode: { name: "LOCAL" },
    healthStatus: { value: "Offline" },
  },
  {
    siteId: "SITE003",
    siteName: "Delhi Site",
    latitude: 28.6139,
    longitude: 77.209,
    imTerminalType: { terminalTypeName: "VSAT" },
    imTerminalMode: { name: "LOCAL" },
    healthStatus: { value: "Online" },
  },
];

const mockGroups = [
  {
    groupName: "South Group",
    sites: [{ siteId: "SITE001" }, { siteId: "SITE002" }],
  },
  {
    groupName: "North Group",
    sites: [{ siteId: "SITE003" }],
  },
];

const mockReduxState = {
  remoteRepDetails: {
    fetchSiteDetails: mockSites,
  },
  mapViewSlice: {
    allSiteGroups: mockGroups,
  },
  userSlice: {
    isReadOnlyMode: false,
    isUserLoggedIn: true,
  },
  toolTipOptionsSlice: {
    topologyToolTipOptions: {},
  },
};

const renderComponent = () => {
  mockUseSelector.mockImplementation((selector) => selector(mockReduxState));

  return render(<BirdEyeView />);
};

const openChartMenu = () => {
  fireEvent.click(
    screen.getByRole("button", {
      name: /Bird Eye View chart options/i,
    })
  );
};

// ======================================================
// TEST CASES
// ======================================================

describe("BirdEyeView Component", () => {
  describe("Initial Rendering", () => {
    test("renders BirdEyeView successfully", () => {
      renderComponent();

      expect(screen.getByLabelText("Filter Type")).toBeInTheDocument();

      expect(
        screen.getByRole("button", {
          name: "Toggle Bird's Eye View",
        })
      ).toBeInTheDocument();
    });

    test("renders Chart View and Pictorial View labels", () => {
      renderComponent();

      expect(screen.getByText("Chart View")).toBeInTheDocument();
      expect(screen.getByText("Pictorial View")).toBeInTheDocument();
    });

    test("defaults to All filter type", () => {
      renderComponent();

      expect(screen.getByLabelText("Filter Type")).toHaveValue("All");
    });

    test("renders CNMS breadcrumb", () => {
      renderComponent();

      expect(screen.getByRole("link", { name: "CNMS" })).toBeInTheDocument();
    });

    test("Filter button is enabled by default", () => {
      renderComponent();

      expect(screen.getByRole("button", { name: "Filter" })).toBeEnabled();
    });
  });

  describe("Redux Integration", () => {
    test("reads site and group data from Redux", () => {
      renderComponent();

      expect(mockUseSelector).toHaveBeenCalled();

      expect(mockUseSelector).toHaveBeenCalledWith(expect.any(Function));
    });

    test("handles empty site details", () => {
      mockUseSelector.mockImplementation((selector) =>
        selector({
          remoteRepDetails: { fetchSiteDetails: [] },
          mapViewSlice: { allSiteGroups: [] },
          userSlice: { isReadOnlyMode: false, isUserLoggedIn: true },
          toolTipOptionsSlice: { topologyToolTipOptions: {} },
        })
      );

      render(<BirdEyeView />);

      expect(screen.getByLabelText("Filter Type")).toBeInTheDocument();
    });

    test("handles missing site details", () => {
      mockUseSelector.mockImplementation((selector) =>
        selector({
          remoteRepDetails: {},
          mapViewSlice: { allSiteGroups: [] },
          userSlice: { isReadOnlyMode: false, isUserLoggedIn: true },
          toolTipOptionsSlice: { topologyToolTipOptions: {} },
        })
      );

      render(<BirdEyeView />);

      expect(
        screen.getByRole("button", { name: "Filter" })
      ).toBeInTheDocument();
    });
  });

  describe("Filter Type", () => {
    test("displays all filter types", () => {
      renderComponent();

      const filter = screen.getByLabelText("Filter Type");

      expect(filter).toContainHTML("All");
      expect(filter).toContainHTML("Terminal");
      expect(filter).toContainHTML("Remote Group");
    });

    test("shows Remote Group selection", () => {
      renderComponent();

      fireEvent.change(screen.getByLabelText("Filter Type"), {
        target: { value: "Remote Group" },
      });

      expect(
        screen.getByRole("group", { name: "Remote Group" })
      ).toBeInTheDocument();
    });

    test("shows Terminal selection", () => {
      renderComponent();

      fireEvent.change(screen.getByLabelText("Filter Type"), {
        target: { value: "Terminal" },
      });

      expect(
        screen.getByRole("group", { name: "Terminal" })
      ).toBeInTheDocument();
    });

    test("resets selected options when filter type changes", () => {
      renderComponent();

      fireEvent.change(screen.getByLabelText("Filter Type"), {
        target: { value: "Terminal" },
      });

      expect(screen.getByLabelText("VSAT")).not.toBeChecked();
    });

    test("resets applied filters when All is selected", () => {
      renderComponent();

      fireEvent.change(screen.getByLabelText("Filter Type"), {
        target: { value: "Terminal" },
      });

      fireEvent.click(screen.getByLabelText("VSAT"));
      fireEvent.click(screen.getByRole("button", { name: "Filter" }));

      fireEvent.change(screen.getByLabelText("Filter Type"), {
        target: { value: "All" },
      });

      fireEvent.click(
        screen.getByRole("button", {
          name: "Toggle Bird's Eye View",
        })
      );

      expect(screen.getByText("SITE001")).toBeInTheDocument();
      expect(screen.getByText("SITE002")).toBeInTheDocument();
      expect(screen.getByText("SITE003")).toBeInTheDocument();
    });
  });

  describe("Remote Group Filter", () => {
    const selectRemoteGroup = () => {
      fireEvent.change(screen.getByLabelText("Filter Type"), {
        target: { value: "Remote Group" },
      });
    };

    test("displays group options", () => {
      renderComponent();

      selectRemoteGroup();

      expect(screen.getByLabelText("South Group")).toBeInTheDocument();
      expect(screen.getByLabelText("North Group")).toBeInTheDocument();
    });

    test("displays site options after group selection", () => {
      renderComponent();

      selectRemoteGroup();
      fireEvent.click(screen.getByLabelText("South Group"));

      expect(screen.getByLabelText("SITE001")).toBeInTheDocument();
      expect(screen.getByLabelText("SITE002")).toBeInTheDocument();
    });

    test("does not display site options before group selection", () => {
      renderComponent();

      selectRemoteGroup();

      expect(screen.queryByLabelText("SITE001")).not.toBeInTheDocument();
    });

    test("disables Filter button without site selection", () => {
      renderComponent();

      selectRemoteGroup();

      expect(screen.getByRole("button", { name: "Filter" })).toBeDisabled();
    });

    test("enables Filter button after site selection", () => {
      renderComponent();

      selectRemoteGroup();
      fireEvent.click(screen.getByLabelText("South Group"));
      fireEvent.click(screen.getByLabelText("SITE001"));

      expect(screen.getByRole("button", { name: "Filter" })).toBeEnabled();
    });

    test("filters sites by selected site ID", () => {
      renderComponent();

      selectRemoteGroup();

      fireEvent.click(screen.getByLabelText("South Group"));
      fireEvent.click(screen.getByLabelText("SITE001"));

      fireEvent.click(screen.getByRole("button", { name: "Filter" }));

      fireEvent.click(
        screen.getByRole("button", {
          name: "Toggle Bird's Eye View",
        })
      );

      const pictorialView = screen.getByTestId("pictorial-view");

      expect(pictorialView).toHaveTextContent("SITE001");
      expect(pictorialView).not.toHaveTextContent("SITE002");
      expect(pictorialView).not.toHaveTextContent("SITE003");
    });
  });

  describe("Terminal Filter", () => {
    const selectTerminalFilter = () => {
      fireEvent.change(screen.getByLabelText("Filter Type"), {
        target: { value: "Terminal" },
      });
    };

    test("displays unique terminal options", () => {
      renderComponent();

      selectTerminalFilter();

      expect(screen.getByLabelText("VSAT")).toBeInTheDocument();
      expect(screen.getByLabelText("RADIO")).toBeInTheDocument();
    });

    test("disables Filter button without terminal selection", () => {
      renderComponent();

      selectTerminalFilter();

      expect(screen.getByRole("button", { name: "Filter" })).toBeDisabled();
    });

    test("enables Filter button after terminal selection", () => {
      renderComponent();

      selectTerminalFilter();
      fireEvent.click(screen.getByLabelText("VSAT"));

      expect(screen.getByRole("button", { name: "Filter" })).toBeEnabled();
    });

    test("filters sites by terminal type", () => {
      renderComponent();

      selectTerminalFilter();
      fireEvent.click(screen.getByLabelText("VSAT"));
      fireEvent.click(screen.getByRole("button", { name: "Filter" }));

      fireEvent.click(
        screen.getByRole("button", {
          name: "Toggle Bird's Eye View",
        })
      );

      expect(screen.getByText("SITE001")).toBeInTheDocument();
      expect(screen.getByText("SITE003")).toBeInTheDocument();
      expect(screen.queryByText("SITE002")).not.toBeInTheDocument();
    });
  });

  describe("View Toggle", () => {
    test("switches to Pictorial View", () => {
      renderComponent();

      fireEvent.click(
        screen.getByRole("button", {
          name: "Toggle Bird's Eye View",
        })
      );

      expect(screen.getByTestId("pictorial-view")).toBeVisible();
    });

    test("switches back to Chart View", () => {
      renderComponent();

      const toggle = screen.getByRole("button", {
        name: "Toggle Bird's Eye View",
      });

      fireEvent.click(toggle);
      fireEvent.click(toggle);

      expect(screen.getByTestId("pictorial-view")).not.toBeVisible();
    });

    test("passes site data to PictorialView", () => {
      renderComponent();

      fireEvent.click(
        screen.getByRole("button", {
          name: "Toggle Bird's Eye View",
        })
      );

      expect(screen.getByText("SITE001")).toBeInTheDocument();
      expect(screen.getByText("SITE002")).toBeInTheDocument();
      expect(screen.getByText("SITE003")).toBeInTheDocument();
    });
  });

  describe("Chart Options", () => {
    const openMenu = () => {
      fireEvent.click(
        screen.getByRole("button", {
          name: "Bird Eye View chart options",
        })
      );
    };

    test("opens chart options menu", async () => {
      renderComponent();

      openMenu();

      expect(
        await screen.findByRole("menuitem", { name: /Print Chart/i })
      ).toBeInTheDocument();
    });

    test.each([
      "Download PNG Image",
      "Download JPEG Image",
      "Download SVG Vector Image",
    ])("displays %s option", async (label) => {
      renderComponent();

      openMenu();

      expect(
        await screen.findByRole("menuitem", { name: new RegExp(label, "i") })
      ).toBeInTheDocument();
    });
  });

  describe("Breadcrumb", () => {
    test("renders CNMS breadcrumb link", () => {
      renderComponent();

      expect(screen.getByRole("link", { name: "CNMS" })).toBeInTheDocument();
    });

    test("prevents default navigation when clicked", () => {
      renderComponent();
    
      const breadcrumb = screen.getByRole("link", {
        name: "CNMS",
      });
    
      const event = new MouseEvent("click", {
        bubbles: true,
        cancelable: true,
      });
    
      act(() => {
        breadcrumb.dispatchEvent(event);
      });
    
      expect(event.defaultPrevented).toBe(true);
    });

  });
});

describe("Chart Export Functionality", () => {
  test("exports chart as SVG", async () => {
    renderComponent();

    const svg = document.querySelector("svg");

    expect(svg).toBeInTheDocument();

    const clickSpy = jest
      .spyOn(HTMLAnchorElement.prototype, "click")
      .mockImplementation(() => {});

    openChartMenu();

    fireEvent.click(
      screen.getByText("Download SVG Vector Image")
    );

    await waitFor(() => {
      expect(URL.createObjectURL).toHaveBeenCalled();
      expect(clickSpy).toHaveBeenCalled();
    });

    clickSpy.mockRestore();
  });

  test("exports chart as PNG", async () => {
    renderComponent();

    const canvasContext = {
      scale: jest.fn(),
      drawImage: jest.fn(),
      fillRect: jest.fn(),
      fillStyle: "",
    };

    jest.spyOn(
      HTMLCanvasElement.prototype,
      "getContext"
    ).mockReturnValue(canvasContext);

    jest.spyOn(
      HTMLCanvasElement.prototype,
      "toBlob"
    ).mockImplementation((callback) => {
      callback(new Blob(["test"], { type: "image/png" }));
    });

    jest
      .spyOn(HTMLAnchorElement.prototype, "click")
      .mockImplementation(() => {});

    openChartMenu();

    fireEvent.click(screen.getByText("Download PNG Image"));

    await waitFor(() => {
      expect(canvasContext.drawImage).toHaveBeenCalled();
      expect(HTMLCanvasElement.prototype.toBlob).toHaveBeenCalled();
    });
  });

  test("exports chart as JPEG with white background", async () => {
    renderComponent();

    const canvasContext = {
      scale: jest.fn(),
      drawImage: jest.fn(),
      fillRect: jest.fn(),
      fillStyle: "",
    };

    jest.spyOn(
      HTMLCanvasElement.prototype,
      "getContext"
    ).mockReturnValue(canvasContext);

    jest.spyOn(
      HTMLCanvasElement.prototype,
      "toBlob"
    ).mockImplementation((callback) => {
      callback(new Blob(["test"], { type: "image/jpeg" }));
    });

    jest
      .spyOn(HTMLAnchorElement.prototype, "click")
      .mockImplementation(() => {});

    openChartMenu();

    fireEvent.click(screen.getByText("Download JPEG Image"));

    await waitFor(() => {
      expect(canvasContext.fillRect).toHaveBeenCalled();
      expect(canvasContext.drawImage).toHaveBeenCalled();
    });
  });
});

describe("Print Chart Functionality", () => {
  test("prints chart successfully", async () => {
    const printWindow = {
      document: {
        open: jest.fn(),
        write: jest.fn(),
        close: jest.fn(),
      },
      focus: jest.fn(),
      print: jest.fn(),
      onload: null,
    };

    window.open.mockReturnValue(printWindow);

    renderComponent();

    openChartMenu();

    fireEvent.click(screen.getByText("Print Chart"));

    expect(window.open).toHaveBeenCalledWith("", "_blank");

    expect(printWindow.document.write).toHaveBeenCalled();

    act(() => {
      printWindow.onload();
    });

    expect(printWindow.focus).toHaveBeenCalled();
    expect(printWindow.print).toHaveBeenCalled();
  });

  test("shows alert when print popup is blocked", () => {
    window.open.mockReturnValue(null);

    renderComponent();

    openChartMenu();

    fireEvent.click(screen.getByText("Print Chart"));

    expect(window.alert).toHaveBeenCalledWith(
      "The print window was blocked. Please allow pop-ups and try again."
    );
  });
});

describe("Fullscreen Functionality", () => {
  test("enters fullscreen mode", async () => {
    const requestFullscreen = jest
      .fn()
      .mockResolvedValue(undefined);

    document.exitFullscreen = jest.fn();

    renderComponent();

    // containerRef is attached to the bordered chart container, not the SVG wrapper.
    const chartContainer = screen
      .getByTestId("FullscreenIcon")
      .closest('div[style*="border: 1px solid"]');

    expect(chartContainer).not.toBeNull();
    chartContainer.requestFullscreen = requestFullscreen;

    await act(async () => {
      fireEvent.click(screen.getByTestId("FullscreenIcon"));
    });

    expect(requestFullscreen).toHaveBeenCalledTimes(1);
  });

  test("exits fullscreen mode", async () => {
    const exitFullscreen = jest
      .fn()
      .mockResolvedValue(undefined);

    Object.defineProperty(document, "fullscreenElement", {
      configurable: true,
      value: document.createElement("div"),
    });

    document.exitFullscreen = exitFullscreen;

    renderComponent();

    await act(async () => {
      fireEvent.click(screen.getByTestId("FullscreenIcon"));
    });

    expect(exitFullscreen).toHaveBeenCalledTimes(1);
  });
});


describe("Chart Hierarchy and Interactions", () => {
  test("renders hierarchy for local sites", async () => {
    renderComponent();

    await waitFor(() => {
      expect(
        document.querySelectorAll("path.slice").length
      ).toBeGreaterThan(0);
    });
  });

  test("displays tooltip when hovering over a chart slice", async () => {
    renderComponent();

    let slice;

    await waitFor(() => {
      slice = document.querySelector("path.slice");
      expect(slice).toBeInTheDocument();
    });

    fireEvent.mouseEnter(slice, {
      clientX: 100,
      clientY: 100,
    });

    expect(await screen.findByText("1 terminal type"))
      .toBeInTheDocument();
  });

  test("clears tooltip when mouse leaves chart slice", async () => {
    renderComponent();

    let slice;

    await waitFor(() => {
      slice = document.querySelector("path.slice");
      expect(slice).toBeInTheDocument();
    });

    fireEvent.mouseEnter(slice, {
      clientX: 100,
      clientY: 100,
    });

    expect(screen.getByText("1 terminal type"))
      .toBeInTheDocument();

    fireEvent.mouseLeave(slice);

    await waitFor(() => {
      expect(
        screen.queryByText("1 terminal type")
      ).not.toBeInTheDocument();
    });
  });

  test("drills into chart hierarchy when a slice is clicked", async () => {
    renderComponent();

    let slice;

    await waitFor(() => {
      slice = document.querySelector("path.slice");
      expect(slice).toBeInTheDocument();
    });

    fireEvent.click(slice);

    await waitFor(() => {
      expect(screen.getByTestId("right-side-panel"))
        .toBeInTheDocument();

      expect(
        screen.getByText("CNMS/North")
      ).toBeInTheDocument();
    });
  });
});



describe("Effect Cleanup", () => {
  test("registers and removes fullscreen listener", () => {
    const addSpy = jest.spyOn(
      document,
      "addEventListener"
    );

    const removeSpy = jest.spyOn(
      document,
      "removeEventListener"
    );

    const { unmount } = renderComponent();

    expect(addSpy).toHaveBeenCalledWith(
      "fullscreenchange",
      expect.any(Function)
    );

    unmount();

    expect(removeSpy).toHaveBeenCalledWith(
      "fullscreenchange",
      expect.any(Function)
    );

    addSpy.mockRestore();
    removeSpy.mockRestore();
  });

  test("creates and disconnects ResizeObserver", () => {
    const { unmount } = renderComponent();

    expect(global.ResizeObserver).toHaveBeenCalled();

    unmount();

    const observer = global.ResizeObserver.mock.results[0].value;

    expect(observer.disconnect).toHaveBeenCalled();
  });
});
