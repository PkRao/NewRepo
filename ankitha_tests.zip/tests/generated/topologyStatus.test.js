jest.mock('../../src/store/features/Topology/topologyNodesslice', () => ({ normalizeReactFlowNode: (node) => node }));
import { determineStatus, mapNodeDetails, mapResourceType, mapSegmentInfo, mapSnmpProfile, mapPollingInfo } from '../../src/store/features/Topology/utils';

const managed = { imResourceType: { imResourceStateInfo: { resourceStateId: 1, resourceStateName: 'Managed' } } };

describe('topology status mapping', () => {
  test('returns maintenance status before discovered/reachability checks', () => {
    expect(determineStatus({ ...managed, isMaintainance: true, isDiscovered: true })).toEqual({ resourceStateName: 'maintainance', maxSeverity: null });
  });
  test('maps discovered reachable and unreachable devices', () => {
    expect(determineStatus({ ...managed, isDiscovered: true, nePollingInfo: { isReachable: true, maxSeverity: 2 } })).toEqual({ resourceStateName: 'up', maxSeverity: 2 });
    expect(determineStatus({ ...managed, isDiscovered: true, nePollingInfo: { isReachable: false } })).toEqual({ resourceStateName: 'down', maxSeverity: null });
  });
  test('treats empty polling info as up for discovered devices', () => {
    expect(determineStatus({ ...managed, isDiscovered: true, nePollingInfo: {} })).toEqual({ resourceStateName: 'up', maxSeverity: null });
    expect(determineStatus({ ...managed, isDiscovered: true, nePollingInfo: null })).toEqual({ resourceStateName: 'up', maxSeverity: null });
  });
  test('returns managed state name for undiscovered managed device', () => {
    expect(determineStatus({ ...managed, isDiscovered: false, maxSeverity: 1 })).toEqual({ resourceStateName: 'Managed', maxSeverity: 1 });
  });
  test('returns unmanaged and unknown status shapes', () => {
    expect(determineStatus({ imResourceType: { imResourceStateInfo: { resourceStateId: 2 } } })).toEqual({ resourceStateName: 'unmanaged', maxSeverity: null });
    expect(determineStatus({})).toEqual({});
  });
});

describe('topology data mappers', () => {
  test('maps resource type nested fields and supplies undefined-safe shapes', () => {
    const mapped = mapResourceType({ resourceTypeId: 1, imCommunicationType: { id: 2, protoTypeName: 'SNMP' }, nodeType: { id: 3, name: 'Router' }, data: { configured: true } });
    expect(mapped).toMatchObject({ resourceTypeId: 1, imCommunicationType: { id: 2, protoTypeName: 'SNMP' }, nodeType: { id: 3, name: 'Router' }, data: { configured: true } });
    expect(mapResourceType({}).imResourceStateInfo).toEqual({ resourceStateId: undefined });
  });
  test('maps segment, SNMP and polling details', () => {
    expect(mapSegmentInfo({ segmentId: 4, segmentName: 'North' })).toMatchObject({ segmentId: 4, segmentName: 'North' });
    expect(mapSnmpProfile({ snmpProfileId: 7, version: '3', port: 161 })).toMatchObject({ snmpProfileId: 7, version: '3', port: 161 });
    expect(mapPollingInfo({ id: 1, pollingInterval: 10 })).toMatchObject({ id: 1, pollingInterval: 10 });
  });
  test('maps node detail fields and renames id to ids', () => {
    const mapped = mapNodeDetails({ id: 9, resourceIp: '10.0.0.1', imResourceType: {}, imSegmentInfo: {}, tmSnmpProfile: {}, nePollingInfo: {} });
    expect(mapped).toMatchObject({ ids: 9, resourceIp: '10.0.0.1', imResourceType: {}, imSegmentInfo: {} });
    expect(mapped).toHaveProperty('tmSnmpProfile');
  });
});
