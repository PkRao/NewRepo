import React from "react";
import { render, screen, within } from "@testing-library/react";
import "@testing-library/jest-dom";
import MapStats from "../../src/Pages/CnmsDashboard/CnmsMap/components/MapStats";

describe("MapStats", () => {
  const makeSite = ({
    siteId,
    terminalType = "MCT-MK-III",
    statusId = 1,
    isMaintainance = false,
    maintenanceType = null,
  }) => ({
    siteId,
    imTerminalType: {
      terminalTypeName: terminalType,
    },
    healthStatus: statusId === null ? null : { id: statusId },
    isMaintainance,
    maintenanceType,
  });

  test("renders nothing when sitesToDisplay is empty", () => {
    const { container } = render(<MapStats sitesToDisplay={[]} />);

    expect(container.firstChild).toBeNull();
  });

  test("renders nothing when only CNMS sites are present", () => {
    const sites = [
      makeSite({
        siteId: "CNMS_001",
        terminalType: "CNMS",
      }),
    ];

    const { container } = render(<MapStats sitesToDisplay={sites} />);

    expect(container.firstChild).toBeNull();
  });

  test("renders terminal statistics", () => {
    const sites = [
      makeSite({ siteId: "SITE_001", statusId: 1 }),
      makeSite({ siteId: "SITE_002", statusId: 0 }),
      makeSite({ siteId: "SITE_003", statusId: 2 }),
    ];

    render(<MapStats sitesToDisplay={sites} />);

    expect(screen.getByText("MCT-MK-III")).toBeInTheDocument();
    expect(screen.getByText("Online")).toBeInTheDocument();
    expect(screen.getByText("Offline")).toBeInTheDocument();
    expect(screen.getByText("RNMS Down")).toBeInTheDocument();
  });

  test("counts Online sites correctly", () => {
    const sites = [
      makeSite({ siteId: "SITE_001", statusId: 1 }),
      makeSite({ siteId: "SITE_002", statusId: 1 }),
    ];

    render(<MapStats sitesToDisplay={sites} />);

    const rows = screen.getAllByRole("row");
    const terminalRow = within(rows[1]);

    expect(terminalRow.getAllByRole("cell")[1]).toHaveTextContent("2");
  });

  test("counts Offline sites correctly", () => {
    const sites = [
      makeSite({ siteId: "SITE_001", statusId: 0 }),
      makeSite({ siteId: "SITE_002", statusId: 0 }),
    ];

    render(<MapStats sitesToDisplay={sites} />);

    const rows = screen.getAllByRole("row");

    expect(within(rows[1]).getAllByRole("cell")[2]).toHaveTextContent("2");
  });

  test("counts RNMS Down sites correctly", () => {
    const sites = [makeSite({ siteId: "SITE_001", statusId: 2 })];

    render(<MapStats sitesToDisplay={sites} />);

    const rows = screen.getAllByRole("row");

    expect(within(rows[1]).getAllByRole("cell")[3]).toHaveTextContent("1");
  });

  test("counts Maintenance Non-OPS sites correctly", () => {
    const sites = [
      makeSite({
        siteId: "SITE_001",
        isMaintainance: true,
        maintenanceType: 1,
      }),
      makeSite({
        siteId: "SITE_002",
        isMaintainance: true,
        maintenanceType: 1,
      }),
    ];

    render(<MapStats sitesToDisplay={sites} />);

    const rows = screen.getAllByRole("row");

    expect(within(rows[1]).getAllByRole("cell")[4]).toHaveTextContent("2");
  });

  test("counts Maintenance R-OPS sites correctly", () => {
    const sites = [
      makeSite({
        siteId: "SITE_001",
        isMaintainance: true,
        maintenanceType: 2,
      }),
    ];

    render(<MapStats sitesToDisplay={sites} />);

    const rows = screen.getAllByRole("row");

    expect(within(rows[1]).getAllByRole("cell")[5]).toHaveTextContent("1");
  });

  test("counts maintenance with a non-1 type as R-OPS", () => {
    const sites = [
      makeSite({
        siteId: "SITE_001",
        isMaintainance: true,
        maintenanceType: null,
      }),
    ];

    render(<MapStats sitesToDisplay={sites} />);

    const rows = screen.getAllByRole("row");

    expect(within(rows[1]).getAllByRole("cell")[5]).toHaveTextContent("1");
  });

  test("handles missing healthStatus as Offline", () => {
    const sites = [
      makeSite({
        siteId: "SITE_001",
        statusId: null,
      }),
    ];

    render(<MapStats sitesToDisplay={sites} />);

    const rows = screen.getAllByRole("row");

    expect(within(rows[1]).getAllByRole("cell")[2]).toHaveTextContent("1");
  });

  test("ignores unknown status when incrementing counts", () => {
    const sites = [
      makeSite({
        siteId: "SITE_001",
        statusId: 99,
      }),
    ];

    render(<MapStats sitesToDisplay={sites} />);

    const rows = screen.getAllByRole("row");
    const terminalCells = within(rows[1]).getAllByRole("cell");

    expect(terminalCells[1]).toHaveTextContent("0");
    expect(terminalCells[2]).toHaveTextContent("0");
    expect(terminalCells[3]).toHaveTextContent("0");
    expect(terminalCells[6]).toHaveTextContent("0");
  });

  test("excludes CNMS from terminal and grand totals", () => {
    const sites = [
      makeSite({
        siteId: "CNMS_001",
        terminalType: "CNMS",
        statusId: 1,
      }),
      makeSite({
        siteId: "SITE_001",
        statusId: 1,
      }),
    ];

    render(<MapStats sitesToDisplay={sites} />);

    expect(screen.queryByText("CNMS")).not.toBeInTheDocument();

    const rows = screen.getAllByRole("row");
    const totalCells = within(rows[2]).getAllByRole("cell");

    expect(totalCells[1]).toHaveTextContent("1");
    expect(totalCells[6]).toHaveTextContent("1");
  });

  test("calculates terminal total correctly", () => {
    const sites = [
      makeSite({ siteId: "SITE_001", statusId: 1 }),
      makeSite({ siteId: "SITE_002", statusId: 0 }),
      makeSite({ siteId: "SITE_003", statusId: 2 }),
      makeSite({
        siteId: "SITE_004",
        isMaintainance: true,
        maintenanceType: 1,
      }),
      makeSite({
        siteId: "SITE_005",
        isMaintainance: true,
        maintenanceType: 2,
      }),
    ];

    render(<MapStats sitesToDisplay={sites} />);

    const rows = screen.getAllByRole("row");
    const terminalCells = within(rows[1]).getAllByRole("cell");

    expect(terminalCells[6]).toHaveTextContent("5");
  });

  test("calculates grand total correctly", () => {
    const sites = [
      makeSite({ siteId: "SITE_001", statusId: 1 }),
      makeSite({ siteId: "SITE_002", statusId: 1 }),
      makeSite({ siteId: "SITE_003", statusId: 0 }),
      makeSite({ siteId: "SITE_004", statusId: 2 }),
      makeSite({
        siteId: "SITE_005",
        isMaintainance: true,
        maintenanceType: 1,
      }),
      makeSite({
        siteId: "SITE_006",
        isMaintainance: true,
        maintenanceType: 2,
      }),
    ];

    render(<MapStats sitesToDisplay={sites} />);

    const rows = screen.getAllByRole("row");
    const totalCells = within(rows[2]).getAllByRole("cell");

    expect(totalCells[1]).toHaveTextContent("2");
    expect(totalCells[2]).toHaveTextContent("1");
    expect(totalCells[3]).toHaveTextContent("1");
    expect(totalCells[4]).toHaveTextContent("1");
    expect(totalCells[5]).toHaveTextContent("1");
    expect(totalCells[6]).toHaveTextContent("6");
  });

  test("creates separate rows for different terminal types", () => {
    const sites = [
      makeSite({
        siteId: "SITE_001",
        terminalType: "MCT-MK-III",
        statusId: 1,
      }),
      makeSite({
        siteId: "SITE_002",
        terminalType: "MCT-MK-II",
        statusId: 0,
      }),
    ];

    render(<MapStats sitesToDisplay={sites} />);

    expect(screen.getByText("MCT-MK-III")).toBeInTheDocument();
    expect(screen.getByText("MCT-MK-II")).toBeInTheDocument();
  });

  test("handles missing terminal type", () => {
    const sites = [
      {
        siteId: "SITE_001",
        healthStatus: { id: 1 },
        isMaintainance: false,
      },
    ];

    render(<MapStats sitesToDisplay={sites} />);

    expect(screen.getByRole("table")).toBeInTheDocument();
  });

  test("uses default props when props are omitted", () => {
    const { container } = render(<MapStats />);

    expect(container.firstChild).toBeNull();
  });

  test("uses fullscreen bottom positioning", () => {
    const sites = [makeSite({ siteId: "SITE_001", statusId: 1 })];

    const { container } = render(
      <MapStats sitesToDisplay={sites} fullScreen={true} />
    );

    expect(container.firstChild).toHaveStyle({
      bottom: "40px",
    });
  });

  test("uses normal bottom positioning when fullscreen is false", () => {
    const sites = [makeSite({ siteId: "SITE_001", statusId: 1 })];

    const { container } = render(
      <MapStats sitesToDisplay={sites} fullScreen={false} />
    );

    expect(container.firstChild).toHaveStyle({
      bottom: "20px",
    });
  });

  test("recalculates statistics when sites change", () => {
    const initialSites = [makeSite({ siteId: "SITE_001", statusId: 1 })];

    const updatedSites = [
      makeSite({ siteId: "SITE_002", statusId: 0 }),
      makeSite({ siteId: "SITE_003", statusId: 0 }),
    ];

    const { rerender } = render(<MapStats sitesToDisplay={initialSites} />);

    let rows = screen.getAllByRole("row");

    expect(within(rows[1]).getAllByRole("cell")[1]).toHaveTextContent("1");

    rerender(<MapStats sitesToDisplay={updatedSites} />);

    rows = screen.getAllByRole("row");

    expect(within(rows[1]).getAllByRole("cell")[1]).toHaveTextContent("0");

    expect(within(rows[1]).getAllByRole("cell")[2]).toHaveTextContent("2");
  });
});
