import React from "react";
import { jest } from "@jest/globals";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import { Provider } from "react-redux";
import { configureStore } from "@reduxjs/toolkit";
import { ThemeProvider, createTheme } from "@mui/material/styles";
import "@testing-library/jest-dom";

// --------------------------------------------------
// Mocks
// --------------------------------------------------

const mockInventoryAxios = jest.fn();
const mockToast = jest.fn();

const testTheme = createTheme({
  palette: {
    custom: {
      icon: {
        scrollcolor: "#888888",
      },
      table: {
        headerText: "#222222",
      },
    },
  },
});

jest.unstable_mockModule("@/RestAPI/api/axiosApicall", () => ({
  InventoryAxios: (...args) => mockInventoryAxios(...args),
}));

jest.unstable_mockModule("@/components/Reusable/Toast/Toast", () => ({
  __esModule: true,
  default: (...args) => mockToast(...args),
}));

jest.unstable_mockModule("@/lib/utils", () => ({
  formatDateTime: jest.fn((value) => `formatted-${value}`),
  convertSeconds: jest.fn((value) => `duration-${value}`),
}));

jest.unstable_mockModule("@/components/Reusable/Form/MForm", () => ({
  __esModule: true,
  default: ({ title, children }) => (
    <section data-testid="mform">
      <h2>{title}</h2>
      {children}
    </section>
  ),
}));

jest.unstable_mockModule("@/components/Reusable/Button/MButtonPrimary", () => ({
  __esModule: true,
  default: ({ children, onClick, disabled }) => (
    <button onClick={onClick} disabled={disabled}>
      {children}
    </button>
  ),
}));

jest.unstable_mockModule("@/components/Reusable/Select/MSelect", () => ({
  __esModule: true,
  default: ({ label, options = [], value, onChange, disabled, placeholder }) => (
    <label>
      {label}
      <select
        aria-label={label}
        disabled={disabled}
        value={
          value == null
            ? ""
            : typeof value === "object"
              ? String(value.value ?? "")
              : String(value)
        }
        onChange={(e) => {
          const selected = options.find(
            (option) => String(option.value) === e.target.value
          );
          if (selected) onChange(selected);
        }}
      >
        <option value="">{placeholder || "Select"}</option>
        {options.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
    </label>
  ),
}));

jest.unstable_mockModule("@/components/Reusable/Table/MTable", () => ({
  __esModule: true,
  default: ({ tableData, columns, showPagination }) => (
    <div data-testid="mtable">
      <span>{tableData.length}</span>
      <span>{columns.length}</span>
      <span>{String(showPagination)}</span>
    </div>
  ),
}));

jest.unstable_mockModule(
  "../../src/Pages/CnmsDashboard/CnmsrightutilityDrawer/SiteLocationHistory/LocationHistoryMap.jsx",
  () => ({
    __esModule: true,
    default: ({ finalTransformedData }) => (
      <div data-testid="location-history-map">
        {finalTransformedData.length}
      </div>
    ),
  })
);

jest.unstable_mockModule("@/RestAPI/url/cnmsEndPoint", () => ({
  SITE_LOCATION_UPDATE_LOG: "/site-location-update-log",
}));

// Register all ESM mocks before importing the component under test.
const { default: SiteLocationHistory } = await import(
  "../../src/Pages/CnmsDashboard/CnmsrightutilityDrawer/SiteLocationHistory/SiteLocationHistory"
);

// --------------------------------------------------
// Test Data
// --------------------------------------------------

const terminalTypes = [
  { terminalTypeName: "CNMS" },
  { terminalTypeName: "HUB-NMS" },
  { terminalTypeName: "RAN" },
  { terminalTypeName: "MW" },
];

const allSites = [
  {
    siteId: "SITE001",
    siteName: "Site One",
    imTerminalType: { terminalTypeName: "RAN" },
  },
  {
    siteId: "SITE002",
    siteName: "Site Two",
    imTerminalType: { terminalTypeName: "MW" },
  },
  {
    siteId: "SITE003",
    siteName: "Site Three",
    imTerminalType: { terminalTypeName: "RAN" },
  },
];

// --------------------------------------------------
// Helpers
// --------------------------------------------------

const defaultPreloadedState = {
  nodeDetails: {
    allTerminalTypeDetails: terminalTypes,
  },
  remoteRepDetails: {
    fetchSiteDetails: allSites,
  },
  userSlice: {
    isReadOnlyMode: false,
    isUserLoggedIn: true,
  },
};

const renderComponent = (preloadedState = {}) => {
  const mergedState = {
    ...defaultPreloadedState,
    ...preloadedState,
    userSlice: {
      ...defaultPreloadedState.userSlice,
      ...(preloadedState.userSlice || {}),
    },
  };

  const store = configureStore({
    reducer: (state = mergedState) => state,
  });

  return render(
    <ThemeProvider theme={testTheme}>
      <Provider store={store}>
        <SiteLocationHistory />
      </Provider>
    </ThemeProvider>
  );
};

const selectOption = (label, value) => {
  fireEvent.change(screen.getByLabelText(label), {
    target: { value: String(value) },
  });
};

const selectRequiredFields = () => {
  selectOption("Terminal", "RAN");
  selectOption("Site ID", "SITE001");
  selectOption("Recent logs", "5");
};

const sampleLogs = [
  {
    siteId: "SITE001",
    siteName: "Site One",
    lattitude: 20.5,
    longitude: 78.5,
    startDateTime: "2025-01-03T10:00:00",
    endDateTime: "2025-01-03T12:00:00",
    durationInHours: 7200,
  },
  {
    siteId: "SITE001",
    siteName: "Site One",
    lattitude: 20.6,
    longitude: 78.6,
    startDateTime: "2025-01-01T10:00:00",
    endDateTime: "2025-01-01T12:00:00",
    durationInHours: 3600,
  },
];

// --------------------------------------------------
// Setup
// --------------------------------------------------

beforeEach(() => {
  jest.clearAllMocks();
});

// --------------------------------------------------
// Rendering
// --------------------------------------------------

describe("SiteLocationHistory - Rendering", () => {
  test("renders Site Location History heading", () => {
    renderComponent();

    expect(screen.getByText("Site Location History")).toBeInTheDocument();
  });

  test("renders all three dropdowns", () => {
    renderComponent();

    expect(screen.getByLabelText("Terminal")).toBeInTheDocument();
    expect(screen.getByLabelText("Site ID")).toBeInTheDocument();
    expect(screen.getByLabelText("Recent logs")).toBeInTheDocument();
  });

  test("renders VIEW button", () => {
    renderComponent();

    expect(screen.getByRole("button", { name: "VIEW" })).toBeInTheDocument();
  });

  test("site dropdown is initially disabled", () => {
    renderComponent();

    expect(screen.getByLabelText("Site ID")).toBeDisabled();
  });

  test("VIEW button is initially disabled", () => {
    renderComponent();

    expect(screen.getByRole("button", { name: "VIEW" })).toBeDisabled();
  });

  test("excludes CNMS and HUB-NMS from terminal options", () => {
    renderComponent();

    const terminalDropdown = screen.getByLabelText("Terminal");

    expect(terminalDropdown).toHaveTextContent("RAN");
    expect(terminalDropdown).toHaveTextContent("MW");
    expect(terminalDropdown).not.toHaveTextContent("CNMS");
    expect(terminalDropdown).not.toHaveTextContent("HUB-NMS");
  });

  test("uses empty terminal options when terminal list is null", () => {
    renderComponent({
      nodeDetails: { allTerminalTypeDetails: null },
      remoteRepDetails: { fetchSiteDetails: allSites },
    });

    expect(screen.getByLabelText("Terminal").children).toHaveLength(1);
  });
});

// --------------------------------------------------
// Terminal and Site Selection
// --------------------------------------------------

describe("SiteLocationHistory - Dropdown Selection", () => {
  test("enables site dropdown after selecting terminal", () => {
    renderComponent();

    selectOption("Terminal", "RAN");

    expect(screen.getByLabelText("Site ID")).toBeEnabled();
  });

  test("filters sites based on selected terminal", async () => {
    renderComponent();

    selectOption("Terminal", "RAN");

    await waitFor(() => {
      expect(screen.getByLabelText("Site ID")).toHaveTextContent("SITE001");
      expect(screen.getByLabelText("Site ID")).toHaveTextContent("SITE003");
    });

    expect(screen.getByLabelText("Site ID")).not.toHaveTextContent("SITE002");
  });

  test("clears selected site when terminal changes", () => {
    renderComponent();

    selectOption("Terminal", "RAN");
    selectOption("Site ID", "SITE001");

    expect(screen.getByLabelText("Site ID")).toBeEnabled();

    selectOption("Terminal", "MW");

    expect(screen.getByLabelText("Site ID")).toBeEnabled();
  });

  test("uses empty sites when allSites is not an array", () => {
    renderComponent({
      nodeDetails: {
        allTerminalTypeDetails: terminalTypes,
      },
      remoteRepDetails: {
        fetchSiteDetails: null,
      },
    });

    selectOption("Terminal", "RAN");

    expect(screen.getByLabelText("Site ID").children).toHaveLength(1);
  });

  test("does not enable VIEW until all required values are selected", () => {
    renderComponent();

    const viewButton = screen.getByRole("button", {
      name: "VIEW",
    });

    selectOption("Terminal", "RAN");

    expect(viewButton).toBeDisabled();

    selectOption("Site ID", "SITE001");

    expect(viewButton).toBeDisabled();

    selectOption("Recent logs", "5");

    expect(viewButton).toBeEnabled();
  });

  test("supports selecting different log counts", () => {
    renderComponent();

    selectOption("Recent logs", "10");

    expect(screen.getByLabelText("Recent logs")).toHaveValue("10");
  });
});

// --------------------------------------------------
// View API
// --------------------------------------------------

describe("SiteLocationHistory - View Logs", () => {
  test("calls API with correct payload", async () => {
    mockInventoryAxios.mockResolvedValue({
      data: sampleLogs,
    });

    renderComponent();

    selectRequiredFields();

    fireEvent.click(screen.getByRole("button", { name: "VIEW" }));

    await waitFor(() => {
      expect(mockInventoryAxios).toHaveBeenCalledWith(
        "/site-location-update-log",
        "post",
        {
          count: 5,
          siteId: "SITE001",
        }
      );
    });
  });

  test("displays location history after successful API response", async () => {
    mockInventoryAxios.mockResolvedValue({
      data: sampleLogs,
    });

    renderComponent();

    selectRequiredFields();

    fireEvent.click(screen.getByRole("button", { name: "VIEW" }));

    expect(await screen.findByTestId("location-history-map")).toHaveTextContent(
      "2"
    );

    expect(screen.getByTestId("mtable")).toBeInTheDocument();
  });

  test("sorts logs by start date ascending and assigns serial numbers", async () => {
    mockInventoryAxios.mockResolvedValue({
      data: sampleLogs,
    });

    renderComponent();

    selectRequiredFields();

    fireEvent.click(screen.getByRole("button", { name: "VIEW" }));

    await screen.findByTestId("location-history-map");

    // The table mock displays the number of records.
    expect(screen.getByTestId("mtable")).toHaveTextContent("2");
  });

  test("handles missing site name and duration", async () => {
    mockInventoryAxios.mockResolvedValue({
      data: [
        {
          siteId: "SITE001",
          lattitude: 20.5,
          longitude: 78.5,
          startDateTime: "2025-01-01T10:00:00",
          endDateTime: "2025-01-01T12:00:00",
          durationInHours: 0,
        },
      ],
    });

    renderComponent();

    selectRequiredFields();

    fireEvent.click(screen.getByRole("button", { name: "VIEW" }));

    await screen.findByTestId("location-history-map");

    expect(screen.getByText(/Location History of Vehicle/)).toHaveTextContent(
      "Unknown"
    );
  });

  test("shows error toast when API returns empty logs", async () => {
    mockInventoryAxios.mockResolvedValue({
      data: [],
    });

    renderComponent();

    selectRequiredFields();

    fireEvent.click(screen.getByRole("button", { name: "VIEW" }));

    await waitFor(() => {
      expect(mockToast).toHaveBeenCalledWith(
        "",
        "No logs found for SITE001",
        "error"
      );
    });

    expect(
      screen.queryByTestId("location-history-map")
    ).not.toBeInTheDocument();
  });

  test("shows error toast when API fails", async () => {
    mockInventoryAxios.mockRejectedValue(new Error("Network error"));

    const consoleSpy = jest.spyOn(console, "log").mockImplementation(() => {});

    renderComponent();

    selectRequiredFields();

    fireEvent.click(screen.getByRole("button", { name: "VIEW" }));

    await waitFor(() => {
      expect(mockToast).toHaveBeenCalledWith("", "Error getting logs", "error");
    });

    consoleSpy.mockRestore();
  });

  test("uses the default logs count when duration is missing", async () => {
    mockInventoryAxios.mockResolvedValue({
      data: [
        {
          siteId: "SITE001",
          siteName: "Site One",
          lattitude: 20,
          longitude: 78,
          startDateTime: "2025-01-01",
          endDateTime: "2025-01-02",
          durationInHours: null,
        },
      ],
    });

    renderComponent();

    selectRequiredFields();

    fireEvent.click(screen.getByRole("button", { name: "VIEW" }));

    await screen.findByTestId("location-history-map");

    expect(screen.getByText(/Location History of Vehicle/)).toBeInTheDocument();
  });

  test("updates the displayed history on subsequent successful requests", async () => {
    mockInventoryAxios
      .mockResolvedValueOnce({ data: sampleLogs })
      .mockResolvedValueOnce({
        data: [sampleLogs[0]],
      });

    renderComponent();

    selectRequiredFields();

    fireEvent.click(screen.getByRole("button", { name: "VIEW" }));

    await waitFor(() => {
      expect(screen.getByTestId("mtable")).toHaveTextContent("2");
    });

    fireEvent.click(screen.getByRole("button", { name: "VIEW" }));

    await waitFor(() => {
      expect(screen.getByTestId("mtable")).toHaveTextContent("1");
    });

    expect(mockInventoryAxios).toHaveBeenCalledTimes(2);
  });
});
