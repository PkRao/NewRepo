import {
  validateLatitude, validateLongitude, sanitizeLatitude, sanitizeLongitude,
} from "../../src/utility/FormValidation/LatLongValidation";

describe("validateLatitude", () => {
  test.each(["0", "45.123456", "-90", "90"])("accepts valid latitude %s", (value) => {
    expect(validateLatitude(value)).toBe("");
  });
  test.each(["", null, undefined])("requires a latitude for %s", (value) => {
    expect(validateLatitude(value)).toBe("Latitude is required");
  });
  test("rejects values outside the latitude range", () => {
    expect(validateLatitude("90.1")).toBe("Latitude must be between -90 and 90");
    expect(validateLatitude("-90.1")).toBe("Latitude must be between -90 and 90");
  });
  test("rejects excessive decimal precision and malformed values", () => {
    expect(validateLatitude("12.1234567")).toContain("up to 6 digits");
    expect(validateLatitude("abc")).toContain("up to 6 digits");
  });
});

describe("validateLongitude", () => {
  test.each(["0", "180", "-180", "179.999999"])("accepts valid longitude %s", (value) => {
    expect(validateLongitude(value)).toBe("");
  });
  test("rejects values outside the longitude range", () => {
    expect(validateLongitude("180.1")).toBe("Longitude must be between -180 and 180");
    expect(validateLongitude("-180.1")).toBe("Longitude must be between -180 and 180");
  });
  test("rejects malformed longitude values", () => {
    expect(validateLongitude("1.1234567")).toContain("up to 6 digits");
  });
});

describe("coordinate sanitizers", () => {
  test("sanitizes latitude input and preserves allowed intermediate values", () => {
    expect(sanitizeLatitude("45a.12345678")).toBe("45.123456");
    expect(sanitizeLatitude("-")).toBe("-");
    expect(sanitizeLatitude("")).toBe("");
  });
  test("removes extra signs and decimal points", () => {
    expect(sanitizeLatitude("1-2.3.4")).toBe("12.34");
  });
  test("rejects out-of-range values", () => {
    expect(sanitizeLatitude("91")).toBeNull();
    expect(sanitizeLatitude("-91")).toBeNull();
    expect(sanitizeLongitude("181")).toBeNull();
  });
  test("allows longitude up to its wider boundary", () => {
    expect(sanitizeLongitude("179.1234567")).toBe("179.123456");
    expect(sanitizeLongitude("-180")).toBe("-180");
  });
});
