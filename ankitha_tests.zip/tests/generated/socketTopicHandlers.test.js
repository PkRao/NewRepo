jest.mock('@/utility/portFilterUtils', () => ({ filterSwitchPorts: (ports) => ports }));
jest.mock('@/Pages/Rnmsdashboard/Topology/utils', () => ({ getEdgeColor: jest.fn(), SEVERITY_COLOR: {} }));
jest.mock('@/utility/alarmService', () => ({ refreshAlarmData: jest.fn() }));
import {
  PERFORMANCE_DATA_UPDATE_TO_UI,
  SEND_NOTIFICATION_TO_UI_FOR_USER_LOGOUT,
} from '../../src/RestAPI/Socket/Endpoint';
import { getSocketTopicHandlers, normalizeDate } from '../../src/store/socket/socketTopicHandlers';
import { updatePerformanceData } from '../../src/store/features/Performance/performanceSlice';
import { setLogoutPending } from '../../src/store/features/Logout/authSlice';

describe('socket topic handler utilities', () => {
  test('normalizeDate returns empty for empty input and preserves invalid date text', () => {
    expect(normalizeDate('')).toBe('');
    expect(normalizeDate(null)).toBe('');
    expect(normalizeDate('not-a-date')).toBe('not-a-date');
  });
  test('normalizes valid dates to en-US date and time text', () => {
    expect(normalizeDate('2026-06-22T13:11:29.000Z')).toMatch(/^Jun 22, 2026,/);
  });
  test('dispatches parsed performance updates with numeric values', () => {
    const store = { dispatch: jest.fn() };
    const handlers = getSocketTopicHandlers(store);
    handlers[PERFORMANCE_DATA_UPDATE_TO_UI]({ body: JSON.stringify({
      resourceInfoBean: { resourceId: 'R1' }, perfParamInfoBean: { paramId: 1400 }, data: '78.5',
    }) });
    expect(store.dispatch).toHaveBeenCalledWith(updatePerformanceData({ resourceId: 'R1', paramId: 1400, value: 78.5 }));
  });
  test('does not dispatch performance event without parameter info', () => {
    const store = { dispatch: jest.fn() };
    getSocketTopicHandlers(store)[PERFORMANCE_DATA_UPDATE_TO_UI]({ body: JSON.stringify({ data: '10' }) });
    expect(store.dispatch).not.toHaveBeenCalled();
  });
  test('dispatches logout pending event with received target user', () => {
    const store = { dispatch: jest.fn() };
    getSocketTopicHandlers(store)[SEND_NOTIFICATION_TO_UI_FOR_USER_LOGOUT]({ body: 'operator-2' });
    expect(store.dispatch).toHaveBeenCalledWith(setLogoutPending({
      message: 'As new login request has come up for the user', targetUser: 'operator-2',
    }));
  });
});
