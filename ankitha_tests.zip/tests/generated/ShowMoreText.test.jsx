import React from "react";
import { jest } from "@jest/globals";
import { render, screen, fireEvent } from "@testing-library/react";
import "@testing-library/jest-dom";

// Register ESM mock before importing ShowMoreText.
jest.unstable_mockModule(
  "../../src/Pages/Rnmsdashboard/RightUtilityDrawer/components/HelpDesk/ChatBubble",
  () => ({
    ChatBubble: ({ side, children }) =>
      React.createElement(
        "div",
        {
          "data-testid": "chat-bubble",
          "data-side": side,
        },
        children
      ),
  })
);

// Import component after registering the mock.
const { default: ShowMoreText } = await import(
  "../../src/Pages/Rnmsdashboard/RightUtilityDrawer/components/HelpDesk/ShowMoreText"
);

describe("ShowMoreText", () => {
  const statusMap = {
    1: "Open",
    2: "In-Progress",
    3: "Pending",
    4: "Resolved",
    5: "Closed",
    6: "Reopen",
  };

  test("returns null when element or hdTicketStatus is missing", () => {
    const { container, rerender } = render(
      <ShowMoreText
        element={null}
        ticketStatusIdMapping={statusMap}
      />
    );

    expect(container.firstChild).toBeNull();

    rerender(
      <ShowMoreText
        element={{ statement: "No status" }}
        ticketStatusIdMapping={statusMap}
      />
    );

    expect(container.firstChild).toBeNull();
  });

  test("renders status label, short statement, and formatted date on left side", () => {
    render(
      <ShowMoreText
        element={{
          hdTicketStatus: { id: 2 },
          statement: "Investigating router port",
          date: "2025-03-05T09:15:30",
        }}
        ticketStatusIdMapping={statusMap}
      />
    );

    expect(screen.getByTestId("chat-bubble")).toHaveAttribute(
      "data-side",
      "left"
    );

    expect(screen.getByText("In-Progress")).toBeInTheDocument();

    expect(
      screen.getByText("Investigating router port")
    ).toBeInTheDocument();

    expect(screen.queryByText(/show more/i)).not.toBeInTheDocument();

    expect(
      screen.getByText(/05-mar-2025 09:15:30/i)
    ).toBeInTheDocument();
  });

  test("truncates long statement over 50 chars and toggles between show more and show less", () => {
    const longStatement =
      "This is a detailed troubleshooting statement that is definitely longer than fifty characters.";

    render(
      <ShowMoreText
        element={{
          hdTicketStatus: { id: "6" },
          statement: longStatement,
          date: "invalid-date",
        }}
        ticketStatusIdMapping={statusMap}
        side="right"
      />
    );

    expect(screen.getByTestId("chat-bubble")).toHaveAttribute(
      "data-side",
      "right"
    );

    expect(screen.getByText("Reopen")).toBeInTheDocument();

    expect(
      screen.getByText(longStatement.slice(0, 50) + "...")
    ).toBeInTheDocument();

    fireEvent.click(screen.getByText("show more"));

    expect(screen.getByText(longStatement)).toBeInTheDocument();

    expect(screen.getByText("show less")).toBeInTheDocument();

    fireEvent.click(screen.getByText("show less"));

    expect(
      screen.getByText(longStatement.slice(0, 50) + "...")
    ).toBeInTheDocument();
  });

  test("renders Unknown Status fallback when status id is not in mapping and handles missing date", () => {
    render(
      <ShowMoreText
        element={{
          hdTicketStatus: { id: 99 },
          statement: "Unmapped status test",
        }}
        ticketStatusIdMapping={statusMap}
      />
    );

    expect(screen.getByText("Unknown Status")).toBeInTheDocument();

    expect(
      screen.getByText("Unmapped status test")
    ).toBeInTheDocument();
  });
});
