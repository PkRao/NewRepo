import reducer, {
  setLoggedInUserDetails, setIsUserLoggedIn, setPrivilege, setPrivilegesKeysSet,
  setRequiresEmailUpdate, resetEmailUpdateRequirement, setReadOnlyMode, selectPrivilegesSet,
} from '../../src/store/features/LoggedInUser/userSlice';

const initial = { userDetails: null, isUserLoggedIn: false, privileges: [], devicePrivileges: null, privilegesKeysSet: null, isEmailUpdateRequired: false, isReadOnlyMode: false };

describe('logged-in user slice', () => {
  test('returns initial state', () => expect(reducer(undefined, { type: '@@INIT' })).toEqual(initial));
  test('sets user and device privilege data', () => {
    const user = { data: { group: { privileges: [{ privilegeName: 'View' }] } } };
    const next = reducer(undefined, setLoggedInUserDetails({ res: user, devicePrivileges: ['read'] }));
    expect(next.userDetails).toEqual(user);
    expect(next.devicePrivileges).toEqual(['read']);
  });
  test('does not append super-admin privilege when flag is false', () => {
    window.isSuperAdmin = false;
    const user = { data: { group: { privileges: [] } } };
    const next = reducer(undefined, setLoggedInUserDetails({ res: user, devicePrivileges: null }));
    expect(next.userDetails.data.group.privileges).toHaveLength(0);
  });
  test('updates login, privilege, email-update and read-only flags', () => {
    let state = reducer(undefined, setIsUserLoggedIn(true));
    state = reducer(state, setPrivilege(['inventory']));
    state = reducer(state, setPrivilegesKeysSet(['read', 'write']));
    state = reducer(state, setRequiresEmailUpdate(true));
    state = reducer(state, setReadOnlyMode(true));
    expect(state.isUserLoggedIn).toBe(true);
    expect(state.privilege).toEqual(['inventory']);
    expect(state.privilegesKeysSet).toEqual(['read', 'write']);
    expect(state.isEmailUpdateRequired).toBe(true);
    expect(state.isReadOnlyMode).toBe(true);
    state = reducer(state, resetEmailUpdateRequirement());
    expect(state.isEmailUpdateRequired).toBe(false);
  });
  test('memoized selector returns a Set of privilege keys', () => {
    const selected = selectPrivilegesSet({ userSlice: { privilegesKeysSet: ['a', 'b', 'a'] } });
    expect(selected).toBeInstanceOf(Set);
    expect([...selected]).toEqual(['a', 'b']);
  });
});
