import React from 'react';
import { renderHook } from '@testing-library/react';
import { ThemeContext, useCustomTheme } from '../../src/utility/DarkTheme/ThemeContext';

describe('useCustomTheme', () => {
  test('throws when used outside the theme provider', () => {
    expect(() => renderHook(() => useCustomTheme())).toThrow(
      'useCustomTheme must be used within a CustomThemeProvider'
    );
  });
  test('returns context value from provider', () => {
    const value = { isdarkmode: true, toggleTheme: jest.fn() };
    const wrapper = ({ children }) => <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
    const { result } = renderHook(() => useCustomTheme(), { wrapper });
    expect(result.current).toBe(value);
    result.current.toggleTheme();
    expect(value.toggleTheme).toHaveBeenCalledTimes(1);
  });
});
