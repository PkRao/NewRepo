import { searchTree } from "../../src/utility/treeSearch";

const tree = {
  label: "Root",
  children: [
    { label: "Alpha" },
    { label: "Beta", children: [{ label: "Beta Child" }] },
    { label: "Gamma" },
  ],
};

describe("searchTree", () => {
  test("returns original node when search text is empty", () => {
    expect(searchTree(tree, "")).toBe(tree);
    expect(searchTree(tree, null)).toBe(tree);
  });
  test("matches a node label case-insensitively", () => {
    expect(searchTree(tree, "root").label).toBe("Root");
  });
  test("retains only matching descendants and their ancestor path", () => {
    const result = searchTree(tree, "beta child");
    expect(result.label).toBe("Root");
    expect(result.children).toHaveLength(1);
    expect(result.children[0].label).toBe("Beta");
    expect(result.children[0].children[0].label).toBe("Beta Child");
  });
  test("supports custom search keys and child property names", () => {
    const data = { name: "parent", items: [{ name: "match" }, { name: "other" }] };
    expect(searchTree(data, "match", { keys: ["name"], childrenKey: "items" }).items)
      .toEqual([{ name: "match" }]);
  });
  test("returns null when neither the node nor descendants match", () => {
    expect(searchTree(tree, "not-found")).toBeNull();
  });
});
