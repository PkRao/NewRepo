import React from 'react';
import { fireEvent, render, screen, waitFor } from '@testing-library/react';

const mockDispatch = jest.fn();
const mockReduxState = {
  inventory: { resources: [{ resourceId: 7, resourceName: 'Router 7' }] },
  remoteRepDetails: {
    fetchAllTerminalTypeAlongWithSite: [],
    fetchSiteDetails: [],
  },
  nodeDetails: { isCnms: false, repDetails: { id: 99 } },
  userSlice: { isReadOnlyMode: false, isUserLoggedIn: false },
};
const mockInventoryAxios = jest.fn();
const mockFaultAxios = jest.fn();
const mockPerformanceAxios = jest.fn();
const mockTopologyAxios = jest.fn();

jest.mock('react-redux', () => ({
  useDispatch: () => mockDispatch,
  useSelector: (selector) => selector(mockReduxState),
}));
jest.mock('@/RestAPI/api/axiosApicall', () => ({
  get InventoryAxios() { return mockInventoryAxios; },
  get FaultAxios() { return mockFaultAxios; },
  get PerformanceAxios() { return mockPerformanceAxios; },
  get TopologyAxios() { return mockTopologyAxios; },
}));
jest.mock(
  '../../src/Pages/Rnmsdashboard/RightUtilityDrawer/components/Reports/FieldFactory',
  () => ({
    FieldFactory: ({ fieldName, onChange, fetchOptionsFn }) => (
      <div data-testid={`field-${fieldName}`}>
        <span>{fieldName}</span>
        <button
          onClick={() =>
            onChange(
              fieldName === 'segmentName'
                ? ['segment-1']
                : fieldName === 'deviceName'
                  ? [7]
                  : 'value'
            )
          }
        >
          Set {fieldName}
        </button>
        <button onClick={() => fetchOptionsFn?.()}>
          Load {fieldName}
        </button>
      </div>
    ),
  })
);
jest.mock(
  '@/components/Reusable/Button/MButtonPrimary',
  () => ({ children, startIcon, sx, ...props }) => (
    <button {...props}>{startIcon}{children}</button>
  )
);
jest.mock('@/components/Reusable/Table/MTable', () => () => <div data-testid="report-table" />);
jest.mock('@/components/Reusable/Pdf/downloadPdf', () => ({ exportToCSV: jest.fn(), exportToPDF: jest.fn() }));
jest.mock(
  '../../src/components/PieChart/MPiechart',
  () => () => <div data-testid="pie-chart" />,
  { virtual: true }
);
jest.mock('../../src/Pages/Rnmsdashboard/RightUtilityDrawer/components/Reports/ReusableRealTimeLineChart', () => () => <div />);
jest.mock('../../src/Pages/Rnmsdashboard/RightUtilityDrawer/components/Reports/performace/PerformanceRouter', () => () => <div data-testid="performance-router" />);
jest.mock('../../src/Pages/Rnmsdashboard/RightUtilityDrawer/components/Reports/SiteAvailabilitySummary', () => () => <div />);
jest.mock('../../src/Pages/Rnmsdashboard/RightUtilityDrawer/components/Reports/SiteAvailabilityChart', () => () => <div />);
jest.mock('@/components/Reusable/Toast/Toast', () => jest.fn());
jest.mock('../../src/Pages/Rnmsdashboard/RightUtilityDrawer/components/Reports/ReportActionsRegistry', () => ({
  ReportActionsRegistry: {
    AlarmLog: {
      initializers: {
        segmentName: jest.fn().mockResolvedValue([{ segmentId: 'segment-1' }]),
        severities: jest.fn().mockResolvedValue(['Critical']),
      },
    },
  },
  executeReportFetch: jest.fn().mockResolvedValue([]),
}));

import ReportWorkspace from '../../src/Pages/Rnmsdashboard/RightUtilityDrawer/components/Reports/ReportWorkspace';

describe('ReportWorkspace component', () => {
  beforeEach(() => {
    mockDispatch.mockClear();
    mockInventoryAxios.mockReset();
    mockFaultAxios.mockReset();
    mockPerformanceAxios.mockReset();
    mockTopologyAxios.mockReset();
    mockInventoryAxios.mockResolvedValue({ data: [{ resourceId: 7, resourceName: 'Router 7' }] });
    mockFaultAxios.mockResolvedValue({ data: [{ alarmName: 'Link Down' }, { alarmName: 'Link Down' }, { alarmName: 'Power' }] });
    mockPerformanceAxios.mockResolvedValue({ data: [] });
    mockTopologyAxios.mockResolvedValue({ data: [] });
  });

  test('renders fields for the selected report tab', () => {
    render(<ReportWorkspace activeTab={{ key: 'AlarmLog', label: 'Alarm Log', fields: ['segmentName', 'deviceName', 'severities'] }} />);
    expect(screen.getByTestId('field-segmentName')).toBeInTheDocument();
    expect(screen.getByTestId('field-deviceName')).toBeInTheDocument();
    expect(screen.getByTestId('field-severities')).toBeInTheDocument();
  });

  test('loads devices after a segment is selected', async () => {
    render(<ReportWorkspace activeTab={{ key: 'AlarmLog', label: 'Alarm Log', fields: ['segmentName', 'deviceName'] }} />);
    fireEvent.click(screen.getByRole('button', { name: 'Set segmentName' }));
    await waitFor(() => expect(mockInventoryAxios).toHaveBeenCalled());
  });

  test('loads alarm options after a device is selected and handles duplicate alarm names', async () => {
    render(<ReportWorkspace activeTab={{ key: 'AlarmLog', label: 'Alarm Log', fields: ['segmentName', 'deviceName', 'alarmName'] }} />);
    fireEvent.click(screen.getByRole('button', { name: 'Set segmentName' }));
    await waitFor(() => expect(mockInventoryAxios).toHaveBeenCalled());
    fireEvent.click(screen.getByRole('button', { name: 'Set deviceName' }));
    await waitFor(() => expect(mockFaultAxios).toHaveBeenCalled());
  });

  test('renders performance router for performance tabs', () => {
    render(<ReportWorkspace activeTab={{ key: 'Performance', mainParent: 'perfomance', fields: [] }} />);
    expect(screen.getByTestId('performance-router')).toBeInTheDocument();
  });

  test('renders safely when no tab is selected', () => {
    const { container } = render(<ReportWorkspace activeTab={null} />);
    expect(container.firstChild).toBeInTheDocument();
  });
});
