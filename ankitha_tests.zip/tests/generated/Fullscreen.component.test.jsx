import React from "react";
import { ThemeProvider, createTheme } from "@mui/material/styles";
import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { Fullscreen } from "../../src/components/Reusable/FullScreen/Fullscreen";
import { CustomeFullscreen } from "../../src/components/Reusable/FullScreen/CustomeFullscreen";

const renderWithDarkTheme = (ui) =>
  render(
    <ThemeProvider theme={createTheme({ palette: { mode: "dark" } })}>
      {ui}
    </ThemeProvider>
  );

describe("Fullscreen", () => {
  test("renders with the dark theme styles", () => {
    renderWithDarkTheme(<Fullscreen />);
    expect(screen.getByRole("button")).toBeInTheDocument();
  });

  test("renders the enter-fullscreen button by default", () => {
    render(<Fullscreen />);

    expect(screen.getByRole("button")).toBeInTheDocument();
    expect(screen.getByTestId("FullscreenIcon")).toBeInTheDocument();
    expect(screen.queryByTestId("FullscreenExitIcon")).not.toBeInTheDocument();
  });

  test("renders the exit-fullscreen icon when already fullscreen", () => {
    render(<Fullscreen isFullScreen />);

    expect(screen.getByTestId("FullscreenExitIcon")).toBeInTheDocument();
    expect(screen.queryByTestId("FullscreenIcon")).not.toBeInTheDocument();
  });

  test("calls onToggleFullScreen when the button is clicked", () => {
    const onToggleFullScreen = jest.fn();
    render(<Fullscreen onToggleFullScreen={onToggleFullScreen} />);

    fireEvent.click(screen.getByRole("button"));

    expect(onToggleFullScreen).toHaveBeenCalledTimes(1);
  });

  test("uses the default enter and exit tooltip titles", async () => {
    const { rerender } = render(<Fullscreen isFullScreen={false} />);

    fireEvent.mouseOver(screen.getByRole("button"));
    expect(await screen.findByRole("tooltip")).toHaveTextContent(
      "Enter Full Screen"
    );

    rerender(<Fullscreen isFullScreen />);
    fireEvent.mouseOver(screen.getByRole("button"));
    await waitFor(() => {
      expect(screen.getByRole("tooltip")).toHaveTextContent(
        "Exit Full Screen"
      );
    });
  });

  test("uses a supplied tooltip title", async () => {
    render(
      <Fullscreen
        isFullScreen
        fullscreenTooltipTitle="Expand workspace"
      />
    );

    fireEvent.mouseOver(screen.getByRole("button"));

    expect(await screen.findByRole("tooltip")).toHaveTextContent(
      "Expand workspace"
    );
  });

  test("renders only the fullscreen toggle button", () => {
    const onClose = jest.fn();
    render(<Fullscreen onClose={onClose} />);

    expect(screen.getAllByRole("button")).toHaveLength(1);
    expect(screen.queryByTestId("CloseIcon")).not.toBeInTheDocument();
    expect(onClose).not.toHaveBeenCalled();
  });
});

describe("CustomeFullscreen", () => {
  test("renders with the dark theme styles", () => {
    renderWithDarkTheme(<CustomeFullscreen />);
    expect(screen.getAllByRole("button")).toHaveLength(2);
  });

  test("renders fullscreen and close buttons by default", () => {
    render(<CustomeFullscreen />);

    expect(screen.getAllByRole("button")).toHaveLength(2);
    expect(screen.getByTestId("FullscreenIcon")).toBeInTheDocument();
    expect(screen.getByTestId("CloseIcon")).toBeInTheDocument();
  });

  test("renders the exit-fullscreen icon when already fullscreen", () => {
    render(<CustomeFullscreen isFullScreen />);

    expect(screen.getByTestId("FullscreenExitIcon")).toBeInTheDocument();
    expect(screen.queryByTestId("FullscreenIcon")).not.toBeInTheDocument();
  });

  test("calls the fullscreen callback when its button is clicked", () => {
    const onToggleFullScreen = jest.fn();
    render(<CustomeFullscreen onToggleFullScreen={onToggleFullScreen} />);

    fireEvent.click(screen.getByTestId("FullscreenIcon").closest("button"));

    expect(onToggleFullScreen).toHaveBeenCalledTimes(1);
  });

  test("calls the close callback when the close button is clicked", () => {
    const onClose = jest.fn();
    render(<CustomeFullscreen onClose={onClose} />);

    fireEvent.click(screen.getByTestId("CloseIcon").closest("button"));

    expect(onClose).toHaveBeenCalledTimes(1);
  });

  test("hides the fullscreen button when isFullScreenvisible is false", () => {
    render(<CustomeFullscreen isFullScreenvisible={false} />);

    expect(screen.getAllByRole("button")).toHaveLength(1);
    expect(screen.getByTestId("CloseIcon")).toBeInTheDocument();
    expect(screen.queryByTestId("FullscreenIcon")).not.toBeInTheDocument();
  });

  test("hides the close button when closeIconvisible is false", () => {
    render(<CustomeFullscreen closeIconvisible={false} />);

    expect(screen.getAllByRole("button")).toHaveLength(1);
    expect(screen.getByTestId("FullscreenIcon")).toBeInTheDocument();
    expect(screen.queryByTestId("CloseIcon")).not.toBeInTheDocument();
  });

  test("hides both buttons when both visibility props are false", () => {
    const { container } = render(
      <CustomeFullscreen
        closeIconvisible={false}
        isFullScreenvisible={false}
      />
    );

    expect(container.querySelectorAll("button")).toHaveLength(0);
  });

  test("uses the custom tooltip title for the fullscreen button", async () => {
    render(
      <CustomeFullscreen fullscreenTooltipTitle="Change display size" />
    );

    fireEvent.mouseOver(screen.getByTestId("FullscreenIcon").closest("button"));

    expect(await screen.findByRole("tooltip")).toHaveTextContent(
      "Change display size"
    );
  });

  test("shows the Close tooltip for the close button", async () => {
    render(<CustomeFullscreen />);

    fireEvent.mouseOver(screen.getByTestId("CloseIcon").closest("button"));

    expect(await screen.findByRole("tooltip")).toHaveTextContent("Close");
  });
});
