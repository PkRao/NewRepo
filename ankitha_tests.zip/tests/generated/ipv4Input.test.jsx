import { isValidIPv4 } from '../../src/components/Reusable/Input/IPv4Input';

describe('IPv4 input validation', () => {
  test.each(['192.168.1.1', '10.0.0.1', '255.255.255.255', '0.0.0.0'])('accepts complete IPv4 address %s', (ip) => {
    expect(isValidIPv4(ip)).toBe(true);
  });
  test.each(['', '192.168.1', '192.168.1.1.1', '256.1.1.1', '1.2.3.00', 'a.b.c.d'])('rejects invalid or incomplete address %s', (ip) => {
    expect(isValidIPv4(ip)).toBe(false);
  });
});
