import React from "react";
import { render, screen } from "@testing-library/react";
import "@testing-library/jest-dom";
import { MapLegend } from "../../src/Pages/CnmsDashboard/CnmsMap/components/MapLegends";

jest.mock("@/assets/CNMS/DCicon.png", () => "DCicon.png");

describe("MapLegend", () => {
  test("renders Online status", () => {
    render(<MapLegend />);

    expect(screen.getByText("Online")).toBeInTheDocument();
  });

  test("renders Offline status", () => {
    render(<MapLegend />);

    expect(screen.getByText("Offline")).toBeInTheDocument();
  });

  test("renders RNMS Down status", () => {
    render(<MapLegend />);

    expect(screen.getByText("RNMS Down")).toBeInTheDocument();
  });

  test("renders Maintenance Non-OPS status", () => {
    render(<MapLegend />);

    expect(screen.getByText("Maintenance Non-OPS")).toBeInTheDocument();
  });

  test("renders Maintenance R-OPS status", () => {
    render(<MapLegend />);

    expect(screen.getByText("Maintenance R-OPS")).toBeInTheDocument();
  });

  test("renders all five legend items", () => {
    const { container } = render(<MapLegend />);

    expect(container.querySelectorAll(".map-legend-item-cont")).toHaveLength(5);
  });

  test("renders five status color indicators", () => {
    const { container } = render(<MapLegend />);

    const indicators = container.querySelectorAll(
      ".map-legend-item-cont > div"
    );

    expect(indicators).toHaveLength(5);

    indicators.forEach((indicator) => {
      expect(indicator).toHaveStyle({ backgroundColor: expect.any(String) });
    });
  });
});
