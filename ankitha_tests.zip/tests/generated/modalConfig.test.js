import { MODAL_CONFIG } from '../../src/core/modal/modalConfig';

describe('modal configuration registry', () => {
  test('provides width configuration for standard modal types', () => {
    expect(MODAL_CONFIG.inventory.maxWidth).toBe('md');
    expect(MODAL_CONFIG.status.maxWidth).toBe('xl');
    expect(MODAL_CONFIG.deleteDevice.maxWidth).toBe('xs');
    expect(MODAL_CONFIG.cnmsAddSite.maxWidth).toBe('sm');
  });
  test('provides custom sizing for polling and alarm suppression dialogs', () => {
    expect(MODAL_CONFIG.pollingInterval.customSx.width.md).toBe('40%');
    expect(MODAL_CONFIG.addAlarmSuppression.customSx.width).toBe('650px');
    expect(MODAL_CONFIG.editAlarmSuppression.customSx.maxWidth).toBe('90vw');
  });
  test('every config entry has a maxWidth', () => {
    Object.values(MODAL_CONFIG).forEach((config) => expect(config.maxWidth).toBeTruthy());
  });
});
