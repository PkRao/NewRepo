 
let HelpDeskTable;
 
import React from "react";
import { jest } from "@jest/globals";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
let useSelector;
 let HelpDeskAxios, InventAxios;
let exportToCSV, exportToPDF;

// ---- Mocks ----
await jest.unstable_mockModule("react-redux", () => ({
  useSelector: jest.fn(),
}));

await jest.unstable_mockModule("@/RestAPI/api/axiosApicall", () => ({
  HelpDeskAxios: jest.fn(),
  InventAxios: jest.fn(),
}));

await jest.unstable_mockModule("@/RestAPI/url/endpoint", () => ({
  GET_ALL_TICKET_FOR_GIVEN_REMOTE_ID: "/api/tickets/remote",
  FETCH_CNMS_ADDRESS_DETAILS: "/api/cnms/address",
  GET_ALL_TICKET: "/api/tickets/all",
}));

await jest.unstable_mockModule("@/components/Reusable/Pdf/downloadPdf", () => ({
  exportToCSV: jest.fn(),
  exportToPDF: jest.fn(),
}));

await jest.unstable_mockModule("../../src/Pages/Rnmsdashboard/RightUtilityDrawer/components/HelpDesk/HandleReopenAction", () => {
  return { default: function MockHandleReopenAction({ id, actionType }) {
    return (
      <div data-testid="reopen-action-view">
        Reopen:{id}:{actionType}
      </div>
    );
  } };
});

await jest.unstable_mockModule("../../src/Pages/Rnmsdashboard/RightUtilityDrawer/components/HelpDesk/HandleCloseAction", () => {
  return { default: function MockHandleCloseAction({ id, actionType }) {
    return (
      <div data-testid="close-action-view">
        Close:{id}:{actionType}
      </div>
    );
  } };
});

await jest.unstable_mockModule("../../src/Pages/Rnmsdashboard/RightUtilityDrawer/components/HelpDesk/HandleStatusUpdateAction", () => {
  return { default: function MockHandleStatusUpdateAction({ id, mode }) {
    return (
      <div data-testid="status-update-action-view">
        Status:{id}:{mode}
      </div>
    );
  } };
});

await jest.unstable_mockModule("@/components/Reusable/Modal/MModal", () => {
  return { default: function MockMModal({ open, title, onClose, children }) {
    if (!open) return null;
    return (
      <div role="dialog" aria-label={title}>
        <h2>{title}</h2>
        <button type="button" onClick={onClose}>
          Close Modal
        </button>
        {children}
      </div>
    );
  } };
});

await jest.unstable_mockModule("@/components/Reusable/Table/MTable", () => {
  return { default: function MockMTable(props) {
    const {
      columns = [],
      collapseColumns = [],
      tableData = [],
      handleAdd,
      handleHistory,
      handleCloseAction,
      handleReopenAction,
      handleInProgressAction,
      handlePendingAction,
      handleResolvedAction,
      handleDownloadPDF,
      handleDownloadCSV,
      onRefreshClick,
    } = props;

    const priorityCol = columns.find((c) => c.uid === "priority");
    const statusCol = columns.find((c) => c.uid === "status");
    const dateCol = collapseColumns.find((c) => c.uid === "date");

    const sampleRow = tableData[0] || {
      id: "T-1",
      status: "Open",
      priority: "Major",
    };

    return (
      <div data-testid="mtable" data-row-count={tableData.length}>
        <div data-testid="rendered-priority-major">
          {priorityCol?.render?.("Major")}
        </div>
        <div data-testid="rendered-priority-custom">
          {priorityCol?.render?.("Custom")}
        </div>
        <div data-testid="rendered-status-open">
          {statusCol?.render?.("Open")}
        </div>
        <div data-testid="rendered-dates">
          <span>{dateCol?.render?.(null)}</span>
          <span>{dateCol?.render?.("not-a-date")}</span>
          <span>{dateCol?.render?.("2025-05-10T08:30:00Z")}</span>
        </div>

        <button type="button" onClick={() => handleAdd?.()}>
          Trigger Add
        </button>
        <button type="button" onClick={() => handleHistory?.(sampleRow)}>
          Trigger History
        </button>
        <button type="button" onClick={() => handleCloseAction?.(sampleRow)}>
          Trigger Close
        </button>
        <button type="button" onClick={() => handleReopenAction?.(sampleRow)}>
          Trigger Reopen
        </button>
        <button
          type="button"
          onClick={() => handleInProgressAction?.(sampleRow)}
        >
          Trigger InProgress
        </button>
        <button type="button" onClick={() => handlePendingAction?.(sampleRow)}>
          Trigger Pending
        </button>
        <button type="button" onClick={() => handleResolvedAction?.(sampleRow)}>
          Trigger Resolved
        </button>
        <button type="button" onClick={() => handleDownloadPDF?.()}>
          Export PDF
        </button>
        <button type="button" onClick={() => handleDownloadCSV?.()}>
          Export CSV
        </button>
        <button type="button" onClick={() => onRefreshClick?.()}>
          Refresh Table
        </button>
      </div>
    );
  } };
});

// Import mocked dependencies and the component after all native ESM mocks
// have been registered. This prevents the component's MTable dependency tree
// from resolving ViewAugmentation before Jest can apply the mocks.
({ useSelector } = await import("react-redux"));
({ HelpDeskAxios, InventAxios } = await import("@/RestAPI/api/axiosApicall"));
({ exportToCSV, exportToPDF } = await import("@/components/Reusable/Pdf/downloadPdf"));
({ default: HelpDeskTable } = await import(
  "../../src/Pages/Rnmsdashboard/RightUtilityDrawer/components/HelpDesk/HelpDeskTable"
));

describe("HelpDeskTable", () => {
  const setTableData = jest.fn();
  const handleAdd = jest.fn();
  const handleHistory = jest.fn();

  const makeState = (isCnms = false, remoteId = "REM-10") => ({
    nodeDetails: {
      isCnms,
      repDetails: remoteId ? { id: remoteId } : null,
    },
  });

  beforeEach(() => {
    jest.clearAllMocks();
    useSelector.mockImplementation((fn) => fn(makeState(false, "REM-10")));
    InventAxios.mockResolvedValue({ data: { address: "10.0.0.1" } });
    HelpDeskAxios.mockResolvedValue({ data: [] });
  });

  test("does not fetch when neither remoteId nor CNMS mode is active", () => {
    useSelector.mockImplementation((fn) => fn(makeState(false, null)));

    render(<HelpDeskTable tableData={[]} setTableData={setTableData} />);

    expect(InventAxios).not.toHaveBeenCalled();
    expect(HelpDeskAxios).not.toHaveBeenCalled();
    expect(screen.getByTestId("mtable")).toBeInTheDocument();
  });

  test("fetches tickets by remoteId in non-CNMS mode, normalizes data, and renders column formatters", async () => {
    InventAxios.mockResolvedValueOnce({ data: { address: "10.0.0.5:8443" } });
    HelpDeskAxios.mockResolvedValueOnce({
      data: [
        {
          id: "1001",
          ticketAlarmDetail: "Link down",
          ticketedDevice: "Core-SW",
          hdTicketPriority: { priority: "MAJOR" },
          hdTicketStatus: { statusName: "Open" },
          hdTicketSubDetails: [
            {
              sequenceNum: 1,
              loggedinUser: "admin",
              statement: "Opened ticket",
              date: "2025-02-15T12:00:00Z",
              hdTicketStatus: { statusName: "Open" },
            },
          ],
        },
        {
          id: "1002",
          priority: "Minor",
          status: "Closed",
          date: "2025-02-16T10:00:00Z",
          hdTicketSubDetails: [
            {
              date: "invalid-date",
              statusName: "Closed",
              user: "legacy.user",
            },
          ],
        },
      ],
    });

    render(
      <HelpDeskTable
        tableData={[{ id: "1001", status: "Open", priority: "Major" }]}
        setTableData={setTableData}
        handleAdd={handleAdd}
        handleHistory={handleHistory}
      />
    );

    await waitFor(() => {
      expect(HelpDeskAxios).toHaveBeenCalledWith(
        "/api/tickets/remote/REM-10",
        "get",
        null,
        null,
        "10.0.0.5:8443"
      );
      expect(setTableData).toHaveBeenCalledWith([
        expect.objectContaining({
          id: "1001",
          sno: 1,
          priority: "MAJOR",
          status: "Open",
          hdTicketSubDetails: [
            expect.objectContaining({
              statusName: "Open",
              searchUser: "admin",
            }),
          ],
        }),
        expect.objectContaining({
          id: "1002",
          sno: 2,
          priority: "Minor",
          status: "Closed",
          hdTicketSubDetails: [
            expect.objectContaining({
              date: "invalid-date",
              statusName: "Closed",
              searchUser: "legacy.user",
            }),
          ],
        }),
      ]);
    });

    expect(screen.getByText("Major")).toBeInTheDocument();
    expect(screen.getByText("Custom")).toBeInTheDocument();
    expect(screen.getByText("Open")).toBeInTheDocument();
    expect(screen.getAllByText("-")).toHaveLength(1);
    expect(screen.getByText("not-a-date")).toBeInTheDocument();

    fireEvent.click(screen.getByRole("button", { name: "Trigger Add" }));
    expect(handleAdd).toHaveBeenCalledWith({
      mode: "CREATE",
      title: "Create Ticket",
    });

    fireEvent.click(screen.getByRole("button", { name: "Trigger History" }));
    expect(handleHistory).toHaveBeenCalledWith(
      expect.objectContaining({
        id: "1001",
        mode: "HISTORY",
        title: "Ticket History",
      })
    );

    fireEvent.click(screen.getByRole("button", { name: "Export PDF" }));
    expect(exportToPDF).toHaveBeenCalledWith(
      "Help Desk Profile",
      expect.any(Array),
      expect.any(Array),
      "Assign_Profile"
    );

    fireEvent.click(screen.getByRole("button", { name: "Export CSV" }));
    expect(exportToCSV).toHaveBeenCalledWith(
      "HelpDesk_Export",
      expect.any(Array),
      expect.any(Array)
    );
  });

  test("handles missing CNMS address and API errors gracefully", async () => {
    const errSpy = jest.spyOn(console, "error").mockImplementation(() => {});
    InventAxios.mockResolvedValueOnce({ data: {} });

    render(<HelpDeskTable tableData={[]} setTableData={setTableData} />);

    await waitFor(() => {
      expect(HelpDeskAxios).not.toHaveBeenCalled();
    });

    InventAxios.mockRejectedValueOnce(new Error("Network error"));
    fireEvent.click(screen.getByRole("button", { name: "Refresh Table" }));

    await waitFor(() => {
      expect(errSpy).toHaveBeenCalledWith(
        "HelpDesk fetch error:",
        expect.any(Error)
      );
    });

    errSpy.mockRestore();
  });

  test("supports CNMS mode actions, opens modal for close/reopen/status modes, and closes modal", async () => {
    useSelector.mockImplementation((fn) => fn(makeState(true, null)));
    InventAxios.mockResolvedValueOnce({ data: { address: "192.168.50.1" } });
    HelpDeskAxios.mockResolvedValueOnce({
      data: [{ id: "CNMS-1", status: "Open", priority: "Warning" }],
    });

    render(
      <HelpDeskTable
        tableData={[{ id: "CNMS-1", status: "Open", priority: "Warning" }]}
        setTableData={setTableData}
      />
    );

    await waitFor(() => {
      expect(HelpDeskAxios).toHaveBeenCalledWith(
        "/api/tickets/all",
        "get",
        null,
        null,
        expect.stringMatching(/^192\.168\.50\.1:(9012|8786)$/)
      );
    });

    // Open InProgress modal on Open row
    fireEvent.click(screen.getByRole("button", { name: "Trigger InProgress" }));
    expect(
      screen.getByRole("dialog", { name: "In-Progress Comment" })
    ).toBeInTheDocument();
    expect(screen.getByTestId("status-update-action-view")).toHaveTextContent(
      "Status:CNMS-1:inprogress"
    );
    fireEvent.click(screen.getByRole("button", { name: "Close Modal" }));
    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();

    // Open Pending modal on Open row
    fireEvent.click(screen.getByRole("button", { name: "Trigger Pending" }));
    expect(
      screen.getByRole("dialog", { name: "Pending Comment" })
    ).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "Close Modal" }));

    // Open Resolved modal on Open row
    fireEvent.click(screen.getByRole("button", { name: "Trigger Resolved" }));
    expect(
      screen.getByRole("dialog", { name: "Resolved Comment" })
    ).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "Close Modal" }));
  });

  test("opens Close and Reopen modals in non-CNMS mode based on row status", async () => {
    useSelector.mockImplementation((fn) => fn(makeState(false, "REM-20")));

    const { rerender } = render(
      <HelpDeskTable
        tableData={[{ id: "T-50", status: "Open", priority: "Minor" }]}
        setTableData={setTableData}
      />
    );

    await waitFor(() => {
      expect(HelpDeskAxios).toHaveBeenCalled();
    });

    // Open row allows Close action
    fireEvent.click(screen.getByRole("button", { name: "Trigger Close" }));
    expect(
      screen.getByRole("dialog", { name: "Close Comment" })
    ).toBeInTheDocument();
    expect(screen.getByTestId("close-action-view")).toHaveTextContent(
      "Close:T-50:CLOSE"
    );
    fireEvent.click(screen.getByRole("button", { name: "Close Modal" }));

    // Closed row allows Reopen action
    rerender(
      <HelpDeskTable
        tableData={[{ id: "T-51", status: "Closed", priority: "Minor" }]}
        setTableData={setTableData}
      />
    );
    fireEvent.click(screen.getByRole("button", { name: "Trigger Reopen" }));
    expect(
      screen.getByRole("dialog", { name: "Reopen Comment" })
    ).toBeInTheDocument();
    expect(screen.getByTestId("reopen-action-view")).toHaveTextContent(
      "Reopen:T-51:REOPEN"
    );
  });
});

