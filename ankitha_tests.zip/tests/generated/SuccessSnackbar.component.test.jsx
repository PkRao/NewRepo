import React from "react";
import { jest } from "@jest/globals";
import { render, screen, fireEvent } from "@testing-library/react";

const alertMock = jest.fn();

jest.unstable_mockModule("antd", () => ({
  Alert: (props) => {
    alertMock(props);
    return (
      <div data-testid="success-alert" data-type={props.type}>
        <span>{props.title}</span>
        <span>{props.description}</span>
        <button type="button" onClick={props.onClose}>
          Close alert
        </button>
        {props.showIcon && <span data-testid="alert-icon">Icon</span>}
      </div>
    );
  },
}));

const { default: SuccessSnackbar } = await import(
  "../../src/components/Popup/SuccessSnackbar"
);

describe("SuccessSnackbar", () => {
  let consoleLogSpy;

  beforeEach(() => {
    jest.clearAllMocks();
    consoleLogSpy = jest.spyOn(console, "log").mockImplementation(() => {});
  });

  afterEach(() => {
    consoleLogSpy.mockRestore();
  });

  test("does not render the Alert when open is false", () => {
    render(
      <SuccessSnackbar
        open={false}
        message="Saved successfully"
        onClose={jest.fn()}
      />
    );

    expect(screen.queryByTestId("success-alert")).not.toBeInTheDocument();
    expect(alertMock).not.toHaveBeenCalled();
  });

  test("renders a success Alert when open is true", () => {
    const onClose = jest.fn();

    render(
      <SuccessSnackbar
        open={true}
        message="Record saved"
        onClose={onClose}
      />
    );

    expect(screen.getByTestId("success-alert")).toBeInTheDocument();
    expect(screen.getByText("Success!")).toBeInTheDocument();
    expect(screen.getByText("Record saved")).toBeInTheDocument();
    expect(screen.getByTestId("alert-icon")).toBeInTheDocument();

    expect(alertMock).toHaveBeenCalledWith(
      expect.objectContaining({
        title: "Success!",
        description: "Record saved",
        type: "success",
        showIcon: true,
        onClose,
      })
    );
  });

  test("uses the default success message when message is an empty string", () => {
    render(
      <SuccessSnackbar open={true} message="" onClose={jest.fn()} />
    );

    expect(
      screen.getByText("Operation completed successfully.")
    ).toBeInTheDocument();
    expect(alertMock).toHaveBeenCalledWith(
      expect.objectContaining({
        description: "Operation completed successfully.",
      })
    );
  });

  test("uses the default success message when message is undefined", () => {
    render(<SuccessSnackbar open={true} onClose={jest.fn()} />);

    expect(
      screen.getByText("Operation completed successfully.")
    ).toBeInTheDocument();
  });

  test("forwards the close callback to the Alert", () => {
    const onClose = jest.fn();

    render(
      <SuccessSnackbar
        open={true}
        message="Completed"
        onClose={onClose}
      />
    );

    fireEvent.click(screen.getByRole("button", { name: "Close alert" }));

    expect(onClose).toHaveBeenCalledTimes(1);
  });

  test("logs the received props and render message", () => {
    const onClose = jest.fn();

    render(
      <SuccessSnackbar
        open={true}
        message="Logged message"
        onClose={onClose}
      />
    );

    expect(consoleLogSpy).toHaveBeenCalledWith(
      "SuccessSnackbar props:",
      {
        open: true,
        message: "Logged message",
        onClose,
      }
    );
    expect(consoleLogSpy).toHaveBeenCalledWith(
      "SuccessSnackbar rendering"
    );
  });
});
