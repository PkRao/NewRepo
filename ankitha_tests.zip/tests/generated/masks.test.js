import { formatIPv4, formatIPv6, formatLatitude, formatLongitude } from "../../src/utility/masks";

describe("formatIPv4", () => {
  test("removes invalid characters and normalizes separators", () => {
    expect(formatIPv4("192a.168..1")).toBe("192.168.1");
    expect(formatIPv4(".192.168")).toBe("192.168.");
  });
  test("limits octets to three digits and 255", () => {
    expect(formatIPv4("300.001.0000")).toBe("255.1.0");
  });
  test("adds a trailing dot after a complete octet", () => {
    expect(formatIPv4("192")).toBe("192.");
    expect(formatIPv4("192.168.1.1")).toBe("192.168.1.1");
  });
  test("limits output to four octets", () => {
    expect(formatIPv4("1.2.3.4.5")).toBe("1.2.3.4");
  });
});

describe("formatIPv6", () => {
  test("lowercases and removes non-hex characters", () => {
    expect(formatIPv6("ABCD:EF01:ZZ")).toBe("abcd:ef01:");
  });
  test("normalizes triple colons and limits length", () => {
    expect(formatIPv6("2001:::db8")).toBe("2001::db8");
    expect(formatIPv6("a".repeat(50))).toHaveLength(39);
  });
});

describe("coordinate masks", () => {
  test("cleans latitude and enforces range and decimal precision", () => {
    expect(formatLatitude("91")).toBe("90");
    expect(formatLatitude("-91")).toBe("-90");
    expect(formatLatitude("12.123456")).toBe("12.1234");
    expect(formatLatitude("1a2.3")).toBe("12.3");
  });
  test("cleans longitude and enforces range and decimal precision", () => {
    expect(formatLongitude("181")).toBe("180");
    expect(formatLongitude("-181")).toBe("-180");
    expect(formatLongitude("12.123456")).toBe("12.1234");
  });
});
