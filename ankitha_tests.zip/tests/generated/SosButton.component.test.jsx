import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import SosButton from "../../src/components/Topbar/SosButton";

describe("SosButton", () => {
  test("renders the SOS image with the supplied source and alt text", () => {
    render(
      <SosButton
        src="/assets/sos-icon.png"
        alt="Emergency SOS"
        onOpenModal={jest.fn()}
      />
    );

    const image = screen.getByRole("img", { name: "Emergency SOS" });

    expect(image).toBeInTheDocument();
    expect(image).toHaveAttribute("src", "/assets/sos-icon.png");
    expect(image).toHaveAttribute("alt", "Emergency SOS");
  });

  test("calls onOpenModal when the SOS button is clicked", () => {
    const onOpenModal = jest.fn();

    render(
      <SosButton
        src="/assets/sos-icon.png"
        alt="Emergency SOS"
        onOpenModal={onOpenModal}
      />
    );

    fireEvent.click(screen.getByRole("button"));

    expect(onOpenModal).toHaveBeenCalledTimes(1);
  });

  test("does not call onOpenModal before the button is clicked", () => {
    const onOpenModal = jest.fn();

    render(
      <SosButton
        src="/assets/sos-icon.png"
        alt="Emergency SOS"
        onOpenModal={onOpenModal}
      />
    );

    expect(onOpenModal).not.toHaveBeenCalled();
  });

  test("uses updated image props when rerendered", () => {
    const onOpenModal = jest.fn();

    const { rerender } = render(
      <SosButton
        src="/assets/sos-old.png"
        alt="Old SOS image"
        onOpenModal={onOpenModal}
      />
    );

    rerender(
      <SosButton
        src="/assets/sos-new.png"
        alt="Updated SOS image"
        onOpenModal={onOpenModal}
      />
    );

    expect(
      screen.getByRole("img", { name: "Updated SOS image" })
    ).toHaveAttribute("src", "/assets/sos-new.png");
    expect(
      screen.queryByRole("img", { name: "Old SOS image" })
    ).not.toBeInTheDocument();
  });
});
