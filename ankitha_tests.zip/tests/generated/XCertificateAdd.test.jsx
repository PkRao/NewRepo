import React from "react";
import { jest } from "@jest/globals";
import {
  render,
  screen,
  fireEvent,
  waitFor,
  act,
} from "@testing-library/react";
import "@testing-library/jest-dom";


/* -------------------------------------------------------
   MOCKS
------------------------------------------------------- */

jest.unstable_mockModule("@/RestAPI/api/axiosApicall", () => ({
  CertAxios: jest.fn(),
  InventoryAxios: jest.fn(),
}));

jest.unstable_mockModule("@/RestAPI/url/endpoint", () => ({
  CREATE_CSR_URL: "/create-csr",
  FETCH_TERMINAL_BY_TERMINAL_NAME: "/fetch-terminal-by-name",
  GET_IP_ADDRESS_AT_CNMS_URL: "/get-ip-at-cnms",
  GET_MAC_ADDRESS: "/get-mac-address",
}));

jest.unstable_mockModule("@/components/Reusable/Toast/Toast", () => ({
  __esModule: true,
  default: jest.fn(),
}));

jest.unstable_mockModule("react-redux", () => ({
  useSelector: jest.fn(),
}));

jest.unstable_mockModule("@/components/Reusable/Select/MSelect", () => ({
  __esModule: true,
  default: ({
    options = [],
    value,
    onChange,
    placeholder,
    error,
    errorMessage,
    disabled,
  }) => (
    <div>
      <select
        aria-label={placeholder || "Select"}
        data-testid={`select-${placeholder || "field"}`}
        value={value ?? ""}
        disabled={disabled}
        onChange={(e) => onChange(e.target.value)}
      >
        <option value="">{placeholder}</option>
        {options.map((opt) => (
          <option key={opt.value} value={opt.value}>
            {opt.label}
          </option>
        ))}
      </select>
      {error && (
        <span data-testid={`select-error-${placeholder || "field"}`}>
          {errorMessage}
        </span>
      )}
    </div>
  ),
}));

jest.unstable_mockModule("@/components/Reusable/Form/FormField", () => ({
  __esModule: true,
  default: ({
    label,
    value,
    onChange,
    onBlur,
    placeholder,
    error,
    errorMessage,
    disabled,
  }) => {
    const key = label
      ? label
          .trim()
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, "-")
          .replace(/^-+|-+$/g, "")
      : "list-item";
    return (
      <div>
        {label && <label htmlFor={key}>{label}</label>}
        <input
          id={key}
          data-testid={`input-${key}`}
          value={value ?? ""}
          placeholder={placeholder}
          disabled={disabled}
          onChange={onChange}
          onBlur={onBlur}
        />
        {error && <span data-testid={`error-${key}`}>{errorMessage}</span>}
      </div>
    );
  },
}));

jest.unstable_mockModule("@/components/Reusable/Button/MButtonPrimary", () => ({
  __esModule: true,
  default: ({ children, onClick, disabled, type }) => (
    <button
      type={type || "button"}
      disabled={disabled}
      onClick={onClick}
      data-testid={
        typeof children === "string"
          ? `btn-${children.toLowerCase()}`
          : "btn-icon"
      }
    >
      {children}
    </button>
  ),
}));

let latestDialogProps;

jest.unstable_mockModule("@/components/Reusable/Dialog/MDialog", () => ({
  __esModule: true,
  default: (props) => {
    latestDialogProps = props;
    return props.open ? (
      <div data-testid="confirm-dialog">
        <span>{props.title}</span>
        <span>{props.message}</span>
        <button
          type="button"
          data-testid="dialog-confirm"
          onClick={props.onConfirm}
        >
          Confirm
        </button>
        <button
          type="button"
          data-testid="dialog-cancel"
          onClick={props.onClose}
        >
          Cancel
        </button>
      </div>
    ) : null;
  },
}));


// Import mocked application modules only after all ESM mocks are registered.
const { default: XCertificateAdd } = await import(
  "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/XCertificate/XCertificateAdd"
);
const {
  CREATE_CSR_URL,
  FETCH_TERMINAL_BY_TERMINAL_NAME,
  GET_IP_ADDRESS_AT_CNMS_URL,
  GET_MAC_ADDRESS,
} = await import("@/RestAPI/url/endpoint");
const { default: Toast } = await import("@/components/Reusable/Toast/Toast");
const { CertAxios, InventoryAxios } = await import("@/RestAPI/api/axiosApicall");
const { useSelector } = await import("react-redux");


/* -------------------------------------------------------
   HELPERS & SAMPLE DATA
------------------------------------------------------- */

const sampleTerminals = [
  { terminalTypeName: "CNMS" },
  { terminalTypeName: "HUB-NMS" },
  { terminalTypeName: "VSAT" },
];

const sampleSitesResponse = {
  data: {
    lstSiteDetails: [
      { id: 101, siteName: "Alpha Site" },
      { siteId: 102 },
    ],
  },
};

const defaultStoreState = {
  nodeDetails: {
    allTerminalTypeDetails: sampleTerminals,
    repDetails: [{ id: 201, siteName: "CNMS HQ" }],
  },
  userSlice: {
    userDetails: {
      data: { userName: "csrOperator" },
    },
  },
};

const defaultProps = (overrides = {}) => ({
  row: null,
  mode: "CREATE",
  onClose: jest.fn(),
  onSuccess: jest.fn(),
  onRefresh: jest.fn(),
  refreshTrigger: 0,
  isGrandchildFullScreen: false,
  allCertData: [],
  ...overrides,
});

const renderComponent = (props = {}, storeOverrides = defaultStoreState) => {
  useSelector.mockImplementation((selector) => selector(storeOverrides));
  return render(<XCertificateAdd {...defaultProps(props)} />);
};

const waitForSiteOptions = async (siteName = "Alpha Site") => {
  await screen.findByRole("option", { name: siteName });
};

const addValidSanEntries = () => {
  const dnsInput = screen.getByTestId("input-dns");
  const ipInput = screen.getByTestId("input-ip-address");
  const addButtons = screen.getAllByTestId("btn-icon");

  fireEvent.change(dnsInput, { target: { value: "cnmsksl.iaf.in" } });
  fireEvent.click(addButtons[0]);

  fireEvent.change(ipInput, { target: { value: "10.20.30.40" } });
  fireEvent.click(addButtons[1]);
};

/* -------------------------------------------------------
   TEST SUITE
------------------------------------------------------- */

describe("XCertificateAdd Component", () => {
  beforeEach(() => {
    jest.clearAllMocks();
    InventoryAxios.mockReset();
    CertAxios.mockReset();
    latestDialogProps = undefined;

    InventoryAxios.mockImplementation((url) => {
      if (url.startsWith(FETCH_TERMINAL_BY_TERMINAL_NAME)) {
        return Promise.resolve(sampleSitesResponse);
      }
      if (url.startsWith(GET_IP_ADDRESS_AT_CNMS_URL)) {
        return Promise.resolve({ data: "192.168.10.25" });
      }
      if (url === GET_MAC_ADDRESS) {
        return Promise.resolve({ data: "AA:BB:CC:DD:EE:FF" });
      }
      return Promise.resolve({ data: {} });
    });

    CertAxios.mockResolvedValue({
      status: 200,
      data: { id: 1, message: "CSR created" },
    });

    jest.spyOn(console, "log").mockImplementation(() => {});
    jest.spyOn(console, "error").mockImplementation(() => {});
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  /* -------------------------------------------------------
     INITIALIZATION & TERMINAL / SITE SELECTION
  ------------------------------------------------------- */

  describe("Initialization and terminal/site selection", () => {
    it("renders default values with Generate button disabled", () => {
      renderComponent({ isGrandchildFullScreen: true });

      expect(screen.getByTestId("input-organization-o")).toHaveValue("IAF");
      expect(screen.getByTestId("input-country")).toHaveValue("IN");
      expect(screen.getByTestId("input-country")).toBeDisabled();
      expect(screen.getByTestId("btn-generate")).toBeDisabled();
      expect(latestDialogProps.isGrandchildFullScreen).toBe(true);
    });

    it("handles non-array terminal list in Redux store", () => {
      renderComponent(
        {},
        {
          nodeDetails: {
            allTerminalTypeDetails: null,
            repDetails: null,
          },
          userSlice: { userDetails: { data: { userName: "u1" } } },
        }
      );

      expect(screen.getByTestId("select-Select Terminal")).toBeDisabled();
    });

    it("fetches sites for non-CNMS terminal and MAC address for site selection", async () => {
      renderComponent();

      fireEvent.change(screen.getByTestId("select-Select Terminal"), {
        target: { value: "VSAT" },
      });

      await waitFor(() => {
        expect(InventoryAxios).toHaveBeenCalledWith(
          `${FETCH_TERMINAL_BY_TERMINAL_NAME}/VSAT`,
          "get"
        );
      });
      await waitForSiteOptions();

      fireEvent.change(screen.getByTestId("select-Select Site ID"), {
        target: { value: "101" },
      });

      await waitFor(() => {
        expect(InventoryAxios).toHaveBeenCalledWith(GET_MAC_ADDRESS, "post", {
          terminal: "VSAT",
          siteId: "101",
        });
      });

      expect(screen.getByTestId("input-mac-address")).toHaveValue(
        "AABBCCDDEEFF"
      );
    });

    it("uses repDetails for CNMS terminal and fetches IP address for HUB-NMS", async () => {
      const { unmount } = renderComponent();

      fireEvent.change(screen.getByTestId("select-Select Terminal"), {
        target: { value: "CNMS" },
      });

      await waitForSiteOptions("CNMS HQ");
      fireEvent.change(screen.getByTestId("select-Select Site ID"), {
        target: { value: "201" },
      });

      expect(screen.getAllByTestId("input-ip-address")[0]).toHaveValue("");
      unmount();

      renderComponent();

      fireEvent.change(screen.getByTestId("select-Select Terminal"), {
        target: { value: "HUB-NMS" },
      });

      await waitFor(() => {
        expect(InventoryAxios).toHaveBeenCalledWith(
          `${FETCH_TERMINAL_BY_TERMINAL_NAME}/HUB-NMS`,
          "get"
        );
      });
      await waitForSiteOptions();

      fireEvent.change(screen.getByTestId("select-Select Site ID"), {
        target: { value: "101" },
      });

      await waitFor(() => {
        expect(InventoryAxios).toHaveBeenCalledWith(
          `${GET_IP_ADDRESS_AT_CNMS_URL}/101`,
          "get"
        );
      });

      expect(screen.getAllByTestId("input-ip-address")[0]).toHaveValue(
        "192.168.10.25"
      );
    });

    it("shows an error toast when fetching site details fails", async () => {
      InventoryAxios.mockRejectedValueOnce(new Error("Sites load failed"));

      renderComponent();

      fireEvent.change(screen.getByTestId("select-Select Terminal"), {
        target: { value: "VSAT" },
      });

      await waitFor(() => {
        expect(Toast).toHaveBeenCalledWith(
          "Error!",
          "Failed to load site details",
          "error"
        );
      });
    });

    it("shows an error toast when fetching the common name fails", async () => {
      renderComponent();

      fireEvent.change(screen.getByTestId("select-Select Terminal"), {
        target: { value: "VSAT" },
      });
      await waitForSiteOptions();

      InventoryAxios.mockRejectedValueOnce(new Error("MAC load failed"));
      fireEvent.change(screen.getByTestId("select-Select Site ID"), {
        target: { value: "101" },
      });

      await waitFor(() => {
        expect(Toast).toHaveBeenCalledWith(
          "Error!",
          "Failed to fetch Common Name",
          "error"
        );
      });
    });
  });

  /* -------------------------------------------------------
     VALIDATION & SAN (DNS / IP) MANAGEMENT
  ------------------------------------------------------- */

  describe("Form validation and SAN fields", () => {
    it("validates fields on blur and displays error messages", async () => {
      renderComponent();

      fireEvent.change(screen.getByTestId("input-organization-o"), {
        target: { value: "a" },
      });
      fireEvent.blur(screen.getByTestId("input-organization-o"));

      fireEvent.change(screen.getByTestId("input-organization-unit-ou"), {
        target: { value: "bad@ou!" },
      });
      fireEvent.blur(screen.getByTestId("input-organization-unit-ou"));

      fireEvent.change(screen.getByTestId("input-location"), {
        target: { value: "123" },
      });
      fireEvent.blur(screen.getByTestId("input-location"));

      fireEvent.change(screen.getByTestId("input-state"), {
        target: { value: "456" },
      });
      fireEvent.blur(screen.getByTestId("input-state"));

      await waitFor(() => {
        expect(
          screen.getByTestId("error-organization-o")
        ).toBeInTheDocument();
        expect(
          screen.getByTestId("error-organization-unit-ou")
        ).toBeInTheDocument();
        expect(screen.getByTestId("error-location")).toBeInTheDocument();
        expect(screen.getByTestId("error-state")).toBeInTheDocument();
      });
    });

    it("adds, edits, and removes DNS and IP SAN entries and resets when unchecked", async () => {
      renderComponent();

      const dnsInput = screen.getByTestId("input-dns");
      const ipInput = screen.getByTestId("input-ip-address");

      fireEvent.change(dnsInput, { target: { value: "   " } });
      expect(screen.getByTestId("error-dns")).toHaveTextContent(
        "DNS should not be empty"
      );

      fireEvent.change(dnsInput, { target: { value: "-invalid-" } });
      expect(screen.getByTestId("error-dns")).toHaveTextContent("Invalid DNS");

      // Changing an already-empty controlled input to "" does not fire
      // React's change handler. Enter a value first, then clear it.
      fireEvent.change(ipInput, { target: { value: "10.20.30.40" } });
      fireEvent.change(ipInput, { target: { value: "" } });
      await waitFor(() => {
        expect(screen.getByTestId("error-ip-address")).toHaveTextContent(
          "IP address should not be empty"
        );
      });

      // The component sanitizes IPv4 segments and rejects more than four.
      fireEvent.change(ipInput, { target: { value: "10.20.30.40.50" } });
      await waitFor(() => {
        expect(screen.getByTestId("error-ip-address")).toHaveTextContent(
          "IP address cannot have more than 4 segments"
        );
      });

      addValidSanEntries();

      expect(screen.getByDisplayValue("cnmsksl.iaf.in")).toBeInTheDocument();
      expect(screen.getByDisplayValue("10.20.30.40")).toBeInTheDocument();

      // Edit list items
      fireEvent.change(screen.getByDisplayValue("cnmsksl.iaf.in"), {
        target: { value: "updated.iaf.in" },
      });
      expect(screen.getByDisplayValue("updated.iaf.in")).toBeInTheDocument();

      fireEvent.change(screen.getByDisplayValue("10.20.30.40"), {
        target: { value: "10.20.30.41" },
      });
      expect(screen.getByDisplayValue("10.20.30.41")).toBeInTheDocument();

      // Remove list items
      const deleteButtons = screen.getAllByLabelText("Remove");
      fireEvent.click(deleteButtons[0]);
      fireEvent.click(screen.getByLabelText("Remove"));

      expect(screen.queryByDisplayValue("updated.iaf.in")).not.toBeInTheDocument();
      expect(screen.queryByDisplayValue("10.20.30.41")).not.toBeInTheDocument();

      // Uncheck SAN checkbox clears SAN fields
      const sanCheckbox = screen.getByRole("checkbox");
      fireEvent.click(sanCheckbox);
      expect(screen.queryByTestId("input-dns")).not.toBeInTheDocument();

      fireEvent.click(sanCheckbox);
      expect(screen.getByTestId("input-dns")).toBeInTheDocument();
    });
  });

  /* -------------------------------------------------------
     CSR SUBMISSION, DUPLICATES & ERROR HANDLING
  ------------------------------------------------------- */

  describe("CSR submission and API handling", () => {
    it("opens confirmation dialog, cancels, and submits CSR payload on confirm", async () => {
      const props = defaultProps();
      renderComponent(props);

      fireEvent.change(screen.getByTestId("select-Select Terminal"), {
        target: { value: "VSAT" },
      });

      await waitFor(() => {
        expect(screen.getByTestId("select-Select Site ID")).toBeEnabled();
      });
      await waitForSiteOptions();

      fireEvent.change(screen.getByTestId("select-Select Site ID"), {
        target: { value: "101" },
      });

      await waitFor(() => {
        expect(screen.getByTestId("input-mac-address")).toHaveValue(
          "AABBCCDDEEFF"
        );
      });

      const organizationUnitInput = screen.getByTestId("input-organization-unit-ou");
      fireEvent.change(organizationUnitInput, {
        target: { value: "Signal Corps" },
      });
      fireEvent.blur(organizationUnitInput);
      await waitFor(() => {
        expect(screen.queryByTestId("error-organization-unit-ou")).not.toBeInTheDocument();
      });
      fireEvent.change(screen.getByTestId("input-location"), {
        target: { value: "Bengaluru" },
      });
      fireEvent.change(screen.getByTestId("input-state"), {
        target: { value: "Karnataka" },
      });

      addValidSanEntries();

      await waitFor(() => {
        expect(screen.getByTestId("btn-generate")).toBeEnabled();
      });

      fireEvent.click(screen.getByTestId("btn-generate"));
      expect(await screen.findByTestId("confirm-dialog")).toBeInTheDocument();

      fireEvent.click(screen.getByTestId("dialog-cancel"));
      expect(screen.queryByTestId("confirm-dialog")).not.toBeInTheDocument();

      fireEvent.click(screen.getByTestId("btn-generate"));
      fireEvent.click(await screen.findByTestId("dialog-confirm"));

      await waitFor(() => {
        expect(CertAxios).toHaveBeenCalledWith(CREATE_CSR_URL, "post", {
          organization: "IAF",
          organizationUnit: "Signal Corps",
          country: "IN",
          commonName: "AABBCCDDEEFF",
          algorthimName: "RSA",
          keySize: "2048",
          user: "csrOperator",
          terminal: "VSAT",
          siteId: "101",
          location: "Bengaluru",
          state: "Karnataka",
          dnsNames: ["cnmsksl.iaf.in"],
          ipAddresses: ["10.20.30.40"],
        });
      });

      expect(Toast).toHaveBeenCalledWith(
        "Success!",
        "CSR generated successfully!",
        "success"
      );
      expect(props.onRefresh).toHaveBeenCalledTimes(1);
      expect(props.onSuccess).toHaveBeenCalledWith({
        status: 200,
        data: { id: 1, message: "CSR created" },
      });
      expect(props.onClose).toHaveBeenCalledTimes(1);
    });

    it("prevents duplicate CSR generation when commonName already exists", async () => {
      renderComponent({
        allCertData: [{ commonName: "AABBCCDDEEFF" }],
      });

      fireEvent.change(screen.getByTestId("select-Select Terminal"), {
        target: { value: "VSAT" },
      });

      await waitFor(() => {
        expect(screen.getByTestId("select-Select Site ID")).toBeEnabled();
      });
      await waitForSiteOptions();

      fireEvent.change(screen.getByTestId("select-Select Site ID"), {
        target: { value: "101" },
      });

      await waitFor(() => {
        expect(screen.getByTestId("input-mac-address")).toHaveValue(
          "AABBCCDDEEFF"
        );
      });

      const organizationUnitInput = screen.getByTestId("input-organization-unit-ou");
      fireEvent.change(organizationUnitInput, {
        target: { value: "OpsUnit" },
      });
      fireEvent.blur(organizationUnitInput);
      await waitFor(() => {
        expect(screen.queryByTestId("error-organization-unit-ou")).not.toBeInTheDocument();
      });
      fireEvent.change(screen.getByTestId("input-location"), {
        target: { value: "Bengaluru" },
      });
      fireEvent.change(screen.getByTestId("input-state"), {
        target: { value: "Karnataka" },
      });
      addValidSanEntries();

      await waitFor(() => {
        expect(screen.getByTestId("btn-generate")).toBeEnabled();
      });
      fireEvent.click(screen.getByTestId("btn-generate"));
      fireEvent.click(await screen.findByTestId("dialog-confirm"));

      await waitFor(() => {
        expect(Toast).toHaveBeenCalledWith(
          "Error!",
          "CSR already exists for AABBCCDDEEFF",
          "error"
        );
      });
      expect(CertAxios).not.toHaveBeenCalled();
    });

    it("handles non-2xx response and rejected API error toasts", async () => {
      CertAxios.mockResolvedValueOnce({ status: 500, data: {} });

      renderComponent();

      fireEvent.change(screen.getByTestId("select-Select Terminal"), {
        target: { value: "VSAT" },
      });

      await waitFor(() => {
        expect(screen.getByTestId("select-Select Site ID")).toBeEnabled();
      });
      await waitForSiteOptions();

      fireEvent.change(screen.getByTestId("select-Select Site ID"), {
        target: { value: "101" },
      });

      await waitFor(() => {
        expect(screen.getByTestId("input-mac-address")).toHaveValue(
          "AABBCCDDEEFF"
        );
      });

      const organizationUnitInput = screen.getByTestId("input-organization-unit-ou");
      fireEvent.change(organizationUnitInput, {
        target: { value: "OpsUnit" },
      });
      fireEvent.blur(organizationUnitInput);
      await waitFor(() => {
        expect(screen.queryByTestId("error-organization-unit-ou")).not.toBeInTheDocument();
      });
      fireEvent.change(screen.getByTestId("input-location"), {
        target: { value: "Bengaluru" },
      });
      fireEvent.change(screen.getByTestId("input-state"), {
        target: { value: "Karnataka" },
      });
      addValidSanEntries();

      await waitFor(() => {
        expect(screen.getByTestId("btn-generate")).toBeEnabled();
      });
      fireEvent.click(screen.getByTestId("btn-generate"));
      fireEvent.click(await screen.findByTestId("dialog-confirm"));

      await waitFor(() => {
        expect(Toast).toHaveBeenCalledWith(
          "Error!",
          "Failed to generate CSR",
          "error"
        );
      });

      CertAxios.mockRejectedValueOnce({
        response: { data: { message: "CA signing error" } },
      });

      fireEvent.click(screen.getByTestId("btn-generate"));
      fireEvent.click(await screen.findByTestId("dialog-confirm"));

      await waitFor(() => {
        expect(Toast).toHaveBeenCalledWith(
          "Error!",
          "CA signing error",
          "error"
        );
      });
    });
  });
});
