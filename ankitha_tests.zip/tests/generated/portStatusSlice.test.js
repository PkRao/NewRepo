import reducer, { setAvailableResources, setwebSocketPortStatus } from '../../src/store/features/PortStatus/portStatusSlice';

describe('port status slice', () => {
  test('normalizes port descriptions from API data', () => {
    const next = reducer(undefined, setAvailableResources([{ resourceId: 'R1', lstPortInfoDtl: [
      { ifindex: 1, ifdesc: '  GigabitEthernet 0/1  ' },
      { ifindex: 2, ifdesc: ' ', ifportname: 'Port-2' },
      { ifindex: 3 },
    ] }]));
    expect(next.availableResources[0].lstPortInfoDtl.map((p) => p.ifdesc)).toEqual(['GigabitEthernet 0/1', 'Port-2', 'port-3']);
  });
  test('creates an empty port list when API omits port details', () => {
    expect(reducer(undefined, setAvailableResources([{ resourceId: 'R1' }])).availableResources[0].lstPortInfoDtl).toEqual([]);
  });
  test('updates existing websocket port without losing its prior description', () => {
    const state = { availableResources: [{ resourceId: 'R1', lstPortInfoDtl: [{ ifindex: 2, ifdesc: 'GE0/2', status: 'up' }] }], webSocketPortStatus: [] };
    const next = reducer(state, setwebSocketPortStatus({ resourceId: 'R1', ifindex: 2, ifdesc: null, status: 'down' }));
    expect(next.availableResources[0].lstPortInfoDtl[0]).toMatchObject({ ifindex: 2, ifdesc: 'GE0/2', status: 'down' });
  });
  test('adds a newly reported port and creates fallback description', () => {
    const state = { availableResources: [{ resourceId: 'R1', lstPortInfoDtl: [] }], webSocketPortStatus: [] };
    const next = reducer(state, setwebSocketPortStatus({ resourceId: 'R1', ifindex: 9, ifdesc: ' ', status: 'up' }));
    expect(next.availableResources[0].lstPortInfoDtl).toEqual([{ resourceId: 'R1', ifindex: 9, ifdesc: 'port-9', status: 'up' }]);
  });
  test('records websocket status even when resource is not found', () => {
    const next = reducer(undefined, setwebSocketPortStatus({ resourceId: 'missing', ifindex: 1 }));
    expect(next.webSocketPortStatus.resourceId).toBe('missing');
  });
});
