import { jest } from '@jest/globals';

jest.unstable_mockModule('@/utility/portFilterUtils', () => ({
  filterSwitchPorts: (ports) => ports.filter((p) => p.keep),
}));

const {
  default: reducer,
  toggleTableMaximize,
  toggleAlarmDrawer,
  setTableMaximized,
  setSegments,
  setResources,
  updateMaxSeverity,
  setRealTimePerfPoint,
  clearRealTimeStream,
  markRealtimeActive,
  markRealtimeInactive,
  startRealTimeSession,
  clearRealTimeSession,
  updateResourceStatus,
  updateDiscoveredDeviceStatusFabric,
  updateInventoryDetails,
} = await import('../../src/store/features/Inventory/inventorySlice');

describe('inventory slice UI and realtime state', () => {
  test('toggles table and alarm drawer flags', () => {
    let state = reducer(undefined, toggleTableMaximize());
    expect(state.isTableMaximized).toBe(true);
    state = reducer(state, toggleAlarmDrawer());
    expect(state.isAlarmDrawer).toBe(true);
    state = reducer(state, setTableMaximized(false));
    expect(state.isTableMaximized).toBe(false);
  });
  test('sets segments and normalizes/sorts switch ports', () => {
    let state = reducer(undefined, setSegments({ segments: [{ id: 1 }] }));
    expect(state.segments).toEqual([{ id: 1 }]);
    state = reducer(state, setResources({ resources: [
      { resourceId: 'MCT_EP_SWITCH-24PORT', lstPortInfoDtl: [{ ifindex: 3, keep: true }, { ifindex: 1, keep: true }, { ifindex: 2, keep: false }] },
      { resourceId: 'OTHER', lstPortInfoDtl: [{ ifindex: 9 }] },
    ] }));
    expect(state.resources[0].lstPortInfoDtl.map((p) => p.ifindex)).toEqual([1, 3]);
    expect(state.resources[1].lstPortInfoDtl).toEqual([{ ifindex: 9 }]);
  });
  test('updates polling severity and polling info', () => {
    let state = reducer(undefined, updateMaxSeverity(2));
    expect(state.nePollingInfo.maxSeverity).toBe(2);
    // setNePollingInfo is intentionally not exported by this slice.
    // Verify the public reducer action that updates the polling metadata.
    expect(state.nePollingInfo.pollingInterval).toBe(10);
    expect(state.nePollingInfo.isReachable).toBe(true);
  });
  test('appends realtime points and clears active stream state', () => {
    let state = reducer(undefined, setRealTimePerfPoint({ resourceId: 'R1', paramId: 1400, point: { value: '12.5', timestamp: '2026-01-01T00:00:00Z' } }));
    expect(state.realtimePerformance['R1_1400'][0]).toEqual({ value: 12.5, timestamp: '2026-01-01T00:00:00.000Z' });
    state = reducer(state, markRealtimeActive('R1_1400'));
    expect(state.activeRealtimeKeys['R1_1400']).toBe(true);
    state = reducer(state, markRealtimeInactive('R1_1400'));
    expect(state.activeRealtimeKeys['R1_1400']).toBeUndefined();
    state = reducer(state, clearRealTimeStream('R1_1400'));
    expect(state.realtimePerformance['R1_1400']).toBeUndefined();
  });
  test('starts and clears realtime session', () => {
    let state = reducer(undefined, startRealTimeSession({ resourceId: 'R1' }));
    expect(state.activeRealtimeConfig).toEqual({ resourceId: 'R1' });
    state = reducer(state, clearRealTimeSession());
    expect(state.activeRealtimeConfig).toBeNull();
  });
  test('updates matching resource status and ignores unknown resource', () => {
    const state = { resources: [{ resourceId: 'R1', isDiscovered: false }] };
    const next = reducer(state, updateResourceStatus({ resourceId: 'R1', isDiscovered: true, isMaintainance: false, lstPortInfoDtl: [] }));
    expect(next.resources[0].isDiscovered).toBe(true);
    expect(reducer(state, updateResourceStatus({ resourceId: 'R2', isDiscovered: true })).resources).toEqual(state.resources);
  });
  test('applies batch discovered status updates only to matching resources', () => {
    const state = { resources: [{ resourceId: 'R1', isDiscovered: false }] };
    const next = reducer(state, updateDiscoveredDeviceStatusFabric([{ resourceId: 'R1', isDiscovered: true, status: 'up', resourceIp: '10.0.0.1' }, { resourceId: 'R2' }]));
    expect(next.resources[0]).toMatchObject({ isDiscovered: true, status: 'up', resourceIp: '10.0.0.1', lstPortInfoDtl: [] });
    expect(reducer(state, updateDiscoveredDeviceStatusFabric(null)).resources).toEqual(state.resources);
  });
  test('ignores inventory updates without resourceId', () => {
    const warn = jest.spyOn(console, 'warn').mockImplementation(() => {});
    const next = reducer(undefined, updateInventoryDetails({ name: 'invalid' }));
    expect(next.resources).toEqual([]);
    expect(warn).toHaveBeenCalled();
    warn.mockRestore();
  });
});
