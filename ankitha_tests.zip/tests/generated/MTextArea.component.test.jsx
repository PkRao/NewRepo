import React from "react";
import { jest } from "@jest/globals";
import { render, screen, fireEvent } from "@testing-library/react";

const textAreaMock = jest.fn();

jest.unstable_mockModule("antd", () => ({
  Input: {
    TextArea: (props) => {
      textAreaMock(props);
      const { autoSize, ...textareaProps } = props;

      return (
        <textarea
          {...textareaProps}
          data-testid="mock-textarea"
          data-autosize={
            autoSize === undefined ? "undefined" : JSON.stringify(autoSize)
          }
        />
      );
    },
  },
}));

jest.unstable_mockModule("@mui/material", () => ({
  Typography: {
    Text: ({ children, type, style }) => (
      <span data-testid="error-text" data-type={type} style={style}>
        {children}
      </span>
    ),
  },
}));

const { default: MTextArea } = await import(
  "../../src/components/Reusable/Texarea/MTextArea"
);

describe("MTextArea", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  test("renders the textarea with its controlled value", () => {
    render(<MTextArea value="Initial notes" onChange={jest.fn()} />);

    expect(screen.getByRole("textbox")).toHaveValue("Initial notes");
  });

  test("forwards changes through the supplied onChange callback", () => {
    let valueSeenByHandler;
    const onChange = jest.fn((event) => {
      valueSeenByHandler = event.target.value;
    });

    render(<MTextArea value="" onChange={onChange} />);

    fireEvent.change(screen.getByRole("textbox"), {
      target: { value: "Updated notes" },
    });

    expect(onChange).toHaveBeenCalledTimes(1);
    // Capture the value inside the handler: React may restore the controlled
    // textarea's DOM value after the event because this test does not rerender.
    expect(valueSeenByHandler).toBe("Updated notes");
  });

  test("applies default textarea styles when no custom style is supplied", () => {
    render(<MTextArea value="" onChange={jest.fn()} />);

    expect(textAreaMock.mock.calls[0][0].style).toEqual({
      resize: "none",
      paddingRight: "0px",
    });
  });

  test("allows custom styles to override the default styles", () => {
    render(
      <MTextArea
        value=""
        onChange={jest.fn()}
        style={{ resize: "vertical", paddingRight: "48px", color: "red" }}
      />
    );

    expect(textAreaMock.mock.calls[0][0].style).toEqual({
      resize: "vertical",
      paddingRight: "48px",
      color: "red",
    });
  });

  test("forwards autoSize and additional textarea properties", () => {
    const autoSize = { minRows: 2, maxRows: 5 };

    render(
      <MTextArea
        value="Text"
        onChange={jest.fn()}
        autoSize={autoSize}
        placeholder="Enter details"
        disabled
        maxLength={250}
        aria-label="Description"
      />
    );

    const textarea = screen.getByRole("textbox", { name: "Description" });

    expect(textarea).toHaveAttribute("placeholder", "Enter details");
    expect(textarea).toBeDisabled();
    expect(textarea).toHaveAttribute("maxlength", "250");
    expect(textarea).toHaveAttribute(
      "data-autosize",
      JSON.stringify(autoSize)
    );

    expect(textAreaMock).toHaveBeenCalledWith(
      expect.objectContaining({
        autoSize,
        placeholder: "Enter details",
        disabled: true,
        maxLength: 250,
        "aria-label": "Description",
      })
    );
  });

  test("does not render a unit when showUnit is false by default", () => {
    render(<MTextArea value="" onChange={jest.fn()} unit="km" />);

    expect(screen.queryByText("km")).not.toBeInTheDocument();
  });

  test("renders the supplied unit when showUnit is true", () => {
    render(
      <MTextArea
        value=""
        onChange={jest.fn()}
        showUnit
        unit="kilometres"
      />
    );

    expect(screen.getByText("kilometres")).toBeInTheDocument();
    expect(screen.getByText("kilometres")).toHaveClass("unit-container");
  });

  test("renders the error message with danger styling when provided", () => {
    render(
      <MTextArea
        value=""
        onChange={jest.fn()}
        errorMessage="Description is required"
      />
    );

    const error = screen.getByTestId("error-text");

    expect(error).toHaveTextContent("Description is required");
    expect(error).toHaveAttribute("data-type", "danger");
    expect(error).toHaveStyle({
      fontSize: "12px",
      marginTop: "4px",
    });
  });

  test("does not render error text when errorMessage is empty", () => {
    render(
      <MTextArea
        value=""
        onChange={jest.fn()}
        errorMessage=""
      />
    );

    expect(screen.queryByTestId("error-text")).not.toBeInTheDocument();
  });
});
