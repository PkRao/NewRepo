import reducer, {
  setCnmsActiveStatuses, updateCnmsActiveStatusFromSocket,
  setCnmsActiveStatusLoading, setCnmsActiveStatusError, clearCnmsActiveStatuses,
} from '../../src/store/features/Cnms/remoteRepDetails/cnmsActiveStatusSlice';

describe('CNMS active site status slice', () => {
  test('normalizes array, object and data-wrapped API responses', () => {
    const next = reducer(undefined, setCnmsActiveStatuses({ data: [
      { ipaddress: ' 10.0.0.1 ', linkStatus: '1', siteType: '2' },
      { linkStatus: 0 },
    ] }));
    expect(next.sites).toEqual([{ ipaddress: '10.0.0.1', linkStatus: 1, siteType: 2 }]);
    expect(next.loading).toBe(false);
    expect(next.error).toBeNull();
    expect(reducer(undefined, setCnmsActiveStatuses({ ipaddress: '10.0.0.2', linkStatus: 0, siteType: 1 })).sites).toHaveLength(1);
    expect(reducer(undefined, setCnmsActiveStatuses(null)).sites).toEqual([]);
  });
  test('socket updates merge matching IP and append new sites', () => {
    const initial = { sites: [{ ipaddress: '10.0.0.1', linkStatus: 0, siteType: 1, name: 'old' }], loading: false, error: null };
    const next = reducer(initial, updateCnmsActiveStatusFromSocket([
      { ipaddress: ' 10.0.0.1 ', linkStatus: '1', siteType: '2', name: 'updated' },
      { ipaddress: '10.0.0.2', linkStatus: '0', siteType: '1' },
      { linkStatus: 1 },
    ]));
    expect(next.sites).toHaveLength(2);
    expect(next.sites[0]).toMatchObject({ ipaddress: '10.0.0.1', linkStatus: 1, siteType: 2, name: 'updated' });
    expect(next.sites[1]).toMatchObject({ ipaddress: '10.0.0.2', linkStatus: 0, siteType: 1 });
  });
  test('tracks loading and errors, then clears all status data', () => {
    let state = reducer(undefined, setCnmsActiveStatusLoading(true));
    expect(state.loading).toBe(true);
    state = reducer(state, setCnmsActiveStatusError('request failed'));
    expect(state).toMatchObject({ loading: false, error: 'request failed' });
    expect(reducer(state, clearCnmsActiveStatuses())).toEqual({ sites: [], loading: false, error: null });
  });
});
