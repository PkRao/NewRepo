import React from "react";
import { jest } from "@jest/globals";
import { fireEvent, render, screen, within } from "@testing-library/react";
import { ThemeProvider, createTheme } from "@mui/material/styles";

jest.unstable_mockModule("@/components/Reusable/Table/MTable", () => ({
  default: function MockMTable({
    columns = [],
    tableData = [],
    tableTitle,
    ...props
  }) {
    return (
      <section data-testid="mock-mtable">
        <h2>{tableTitle}</h2>
        <div data-testid="table-props">
          {JSON.stringify({
            showPagination: props.showPagination,
            showSearch: props.showSearch,
            showVisibleContent: props.showVisibleContent,
            showMaximazed: props.showMaximazed,
            showSelect: props.showSelect,
            typeHeight: props.typeHeight,
          })}
        </div>
        <div data-testid="table-headers">
          {columns.map((column) => (
            <span key={column.uid} data-testid={`header-${column.uid}`}>
              {column.name}
            </span>
          ))}
        </div>
        <div data-testid="table-rows">
          {tableData.map((row, index) => (
            <div
              key={row.terminal ?? index}
              data-testid={`row-${index}`}
              onClick={() => window.__alarmSummaryRowClick?.()}
            >
              <span>{row.terminal}</span>
              <span>{row.major}</span>
              <span>{row.minor}</span>
              <span>{row.warning}</span>
              <span>{row.ack}</span>
              <span>{row.notAck}</span>
              <span>{row.total}</span>
              <div data-testid={`action-${index}`}>{row.action}</div>
            </div>
          ))}
        </div>
      </section>
    );
  },
}));

jest.unstable_mockModule(
  "../../src/Pages/CnmsDashboard/CnmsAlarmSummary/CnmsAlarmModals/CNMSAlarmDetailsModal",
  () => ({
    default: function MockCNMSAlarmDetailsModal({ open, onClose, terminal }) {
      return (
        <div
          data-testid="alarm-details-modal"
          data-open={String(open)}
          data-terminal={terminal ? JSON.stringify(terminal) : "null"}
        >
          <button type="button" onClick={onClose}>
            Close alarm details
          </button>
        </div>
      );
    },
  })
);

const { default: AlarmSummaryTable } = await import(
  "../../src/Pages/CnmsDashboard/CnmsAlarmSummary/components/AlarmSummaryTable"
);

const theme = createTheme({
  palette: {
    primary: {
      main: "#123456",
    },
  },
});

const renderTable = (data) =>
  render(
    <ThemeProvider theme={theme}>
      <AlarmSummaryTable {...(data === undefined ? {} : { data })} />
    </ThemeProvider>
  );

const getModal = () => screen.getByTestId("alarm-details-modal");

describe("AlarmSummaryTable", () => {
  const sampleRows = [
    {
      terminal: "Terminal-A",
      major: 3,
      minor: 4,
      warning: 2,
      ack: 5,
      notAck: 4,
      total: 9,
      siteId: 101,
    },
    {
      terminal: "Terminal-B",
      major: 1,
      minor: 2,
      warning: 3,
      ack: 2,
      notAck: 4,
      total: 6,
      siteId: 102,
    },
  ];

  beforeEach(() => {
    delete window.__alarmSummaryRowClick;
  });

  test("renders the Alarm Summary table and all configured columns", () => {
    renderTable(sampleRows);

    expect(screen.getByRole("heading", { name: "Alarm Summary" })).toBeInTheDocument();

    [
      "terminal",
      "major",
      "minor",
      "warning",
      "ack",
      "notAck",
      "total",
      "action",
    ].forEach((uid) => {
      expect(screen.getByTestId(`header-${uid}`)).toBeInTheDocument();
    });
  });

  test("configures the table display options", () => {
    renderTable(sampleRows);

    expect(screen.getByTestId("table-props")).toHaveTextContent(
      JSON.stringify({
        showPagination: true,
        showSearch: true,
        showVisibleContent: false,
        showMaximazed: false,
        showSelect: false,
        typeHeight: "configuration",
      })
    );
  });

  test("forwards all supplied rows and their alarm values to MTable", () => {
    renderTable(sampleRows);

    expect(screen.getByTestId("row-0")).toHaveTextContent("Terminal-A342549");
    expect(screen.getByTestId("row-1")).toHaveTextContent("Terminal-B123246");
  });

  test("uses an empty array when data is omitted", () => {
    renderTable();

    expect(screen.getByTestId("table-rows")).toBeEmptyDOMElement();
  });

  test("handles an explicitly empty data array", () => {
    renderTable([]);

    expect(screen.getByTestId("table-rows")).toBeEmptyDOMElement();
  });

  test("passes a closed modal with no selected terminal initially", () => {
    renderTable(sampleRows);

    expect(getModal()).toHaveAttribute("data-open", "false");
    expect(getModal()).toHaveAttribute("data-terminal", "null");
  });

  test("opens the alarm details modal for the selected row", () => {
    renderTable(sampleRows);

    fireEvent.click(screen.getByTestId("action-0").querySelector("button"));

    expect(getModal()).toHaveAttribute("data-open", "true");
    expect(getModal()).toHaveAttribute(
      "data-terminal",
      JSON.stringify(sampleRows[0])
    );
  });

  test("selects the correct terminal when another row action is clicked", () => {
    renderTable(sampleRows);

    fireEvent.click(screen.getByTestId("action-1").querySelector("button"));

    expect(getModal()).toHaveAttribute("data-open", "true");
    expect(getModal()).toHaveAttribute(
      "data-terminal",
      JSON.stringify(sampleRows[1])
    );
  });

  test("closes the alarm details modal when onClose is invoked", () => {
    renderTable(sampleRows);

    fireEvent.click(screen.getByTestId("action-0").querySelector("button"));
    expect(getModal()).toHaveAttribute("data-open", "true");

    fireEvent.click(screen.getByRole("button", { name: "Close alarm details" }));

    expect(getModal()).toHaveAttribute("data-open", "false");
    expect(getModal()).toHaveAttribute(
      "data-terminal",
      JSON.stringify(sampleRows[0])
    );
  });

  test("prevents the row click handler from firing when the view-details action is clicked", () => {
    const rowClick = jest.fn();
    window.__alarmSummaryRowClick = rowClick;

    renderTable(sampleRows);
    fireEvent.click(screen.getByTestId("action-0").querySelector("button"));

    expect(rowClick).not.toHaveBeenCalled();
    expect(getModal()).toHaveAttribute("data-open", "true");
  });

  test("preserves additional row properties in the selected terminal object", () => {
    renderTable(sampleRows);

    fireEvent.click(screen.getByTestId("action-0").querySelector("button"));

    const selected = JSON.parse(getModal().getAttribute("data-terminal"));
    expect(selected.siteId).toBe(101);
    expect(selected.terminal).toBe("Terminal-A");
  });

  test("renders action controls for each supplied row", () => {
    renderTable(sampleRows);

    expect(screen.getByTestId("action-0").querySelector("button")).toBeInTheDocument();
    expect(screen.getByTestId("action-1").querySelector("button")).toBeInTheDocument();
  });
});
