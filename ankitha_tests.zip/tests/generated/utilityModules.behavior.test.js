import { severityConfig } from '../../src/Pages/Rnmsdashboard/AlarmDrawer/utils';
import { formatIPMask, isValidIpV4 } from '../../src/components/Dialogs/deviceMaintenance/utils';
import { linksMap, terminalType, UpdateURlFun } from '../../src/components/shared/utilis/utils';
import { ContextMenuOptions } from '../../src/components/Contextmenu/utils';
import { CNMSContextMenuOptions } from '../../src/components/Contextmenu/CNMS_Utils';
import { filterSwitchPorts } from '../../src/utility/portFilterUtils';
import { searchTree } from '../../src/utility/treeSearch';
import { formatIPv4, formatIPv6, formatLatitude, formatLongitude } from '../../src/utility/masks';

describe('utility module behaviour', () => {
  test('alarm severity configuration exposes all supported severities', () => {
    expect(Object.keys(severityConfig)).toEqual(['MAJOR', 'MINOR', 'WARNING']);
    expect(severityConfig.MAJOR.label).toBe('Major');
    expect(severityConfig.MINOR.dotGradient).toContain('linear-gradient');
  });

  test('device maintenance IP mask pads four octets and truncates extra input', () => {
    expect(formatIPMask('1921681')).toBe('192.168.1__. ___'.replace(' ', ''));
    expect(formatIPMask('1921681001255')).toBe('192.168.100.125');
    expect(formatIPMask('')).toBe('___.___.___.___');
  });

  test('device maintenance IPv4 validation handles valid and invalid boundaries', () => {
    expect(isValidIpV4('192.168.1.1')).toBe(true);
    expect(isValidIpV4('255.255.255.255')).toBe(true);
    expect(isValidIpV4('256.1.1.1')).toBe(false);
    expect(isValidIpV4('1.2.3')).toBe(false);
    expect(isValidIpV4('192.168.___.1')).toBe(false);
  });

  test('shared URL helper replaces host while preserving protocol and port', () => {
    expect(UpdateURlFun('https://10.0.0.1:8080/api', '10.0.0.2')).toBe('https://10.0.0.2:8080/api');
    expect(linksMap[2]).toBe('E1/LOS');
    expect(terminalType.MCT_MK_II).toBe(5);
  });

  test('context menu definitions contain expected actions and nested fault actions', () => {
    expect(ContextMenuOptions.find((item) => item.value === 'inventory')).toMatchObject({ label: 'Inventory', show: true });
    const fault = ContextMenuOptions.find((item) => item.value === 'fault');
    expect(fault.submenu.map((item) => item.value)).toEqual(['viewActiveAlarm', 'pollingInterval', 'alarmSuppression']);
    expect(CNMSContextMenuOptions).toBeDefined();
    expect(Object.keys(CNMSContextMenuOptions).length).toBeGreaterThan(0);
  });

  test('port filter rejects invalid input and applies configured matching rules', () => {
  expect(filterSwitchPorts(null)).toEqual([]);

  expect(
    filterSwitchPorts([
      { ifdesc: null },
      {},
      { ifdesc: 12 },
    ])
  ).toEqual([]);

  const input = [
    { ifdesc: 'GigabitEthernet0/1' },
    { ifdesc: 'TenGigabitEthernet0/1' },
    { ifdesc: 'FastEthernet0/1' },
  ];

  const result = filterSwitchPorts(input);

  expect(Array.isArray(result)).toBe(true);

  result.forEach((port) => {
    expect(port).toHaveProperty('ifdesc');
    expect(typeof port.ifdesc).toBe('string');
  });

  expect(result.length).toBeLessThanOrEqual(input.length);
});

  test('tree search returns original input for empty search and prunes unmatched branches', () => {
    const tree = { label: 'Root', children: [{ label: 'Alpha' }, { label: 'Beta', children: [{ label: 'Target node' }] }] };
    expect(searchTree(tree, '')).toBe(tree);
    expect(searchTree(tree, 'target')).toEqual({ label: 'Root', children: [{ label: 'Beta', children: [{ label: 'Target node' }] }] });
    expect(searchTree({ title: 'Device', kids: [{ title: 'Router' }] }, 'router', { keys: ['title'], childrenKey: 'kids' })).toEqual({ title: 'Device', kids: [{ title: 'Router' }] });
    expect(searchTree({ label: 'No match' }, 'missing')).toBeNull();
  });

  test('address masks sanitize, constrain and truncate input', () => {
    expect(formatIPv4('192..168.001.300x')).toBe('192.168.1.255');
    expect(formatIPv4('.10.0.0.1')).toBe('10.0.0.1');
    expect(formatIPv6('ABCD::::1234!')).toBe('abcd::1234');
    expect(formatIPv6('1'.repeat(50))).toHaveLength(39);
    expect(formatLatitude('91.123456')).toBe('90');
    expect(formatLatitude('-91')).toBe('-90');
    expect(formatLatitude('12.123456')).toBe('12.1234');
    expect(formatLongitude('181.1')).toBe('180');
    expect(formatLongitude('-181')).toBe('-180');
    expect(formatLongitude('77.123456')).toBe('77.1234');
  });
});
