import reducer, { setToggleLeftSideBar } from '../../src/store/features/LeftSideBar/leftSideBar';

describe('left sidebar slice', () => {
  test('starts hidden', () => expect(reducer(undefined, { type: '@@INIT' })).toEqual({ leftSidebarVisible: false }));
  test('toggles visibility regardless of action payload', () => {
    let state = reducer(undefined, setToggleLeftSideBar());
    expect(state.leftSidebarVisible).toBe(true);
    state = reducer(state, setToggleLeftSideBar(false));
    expect(state.leftSidebarVisible).toBe(false);
  });
});
