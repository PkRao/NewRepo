import cnmsReducer, {
  setMountAbuDetails, setKasauliDetails, setRepresentatives,
  clearCnmsData, setLoading, setSavedRnmsDetails as setCnmsSavedRnmsDetails,
} from '../../src/store/features/Cnms/cnmsSlice';
import cnmsStatusReducer, {
  setHealthStatus, setCnmsLinkAvailable,
} from '../../src/store/features/LinkStatus/cnmsStatusSlice';
import terminalReducer, {
  setRnmsterminaltypesData, clearRnmsterminaltypesData,
} from '../../src/store/features/Cnms/remoteRepDetails/rnmsTerminalTypes';
import delayReducer, {
  initDelayAndResponseChart, addDelayAndResponseChartPoint,
  clearDelayAndResponseChartData, setSubscribeToDelayAndResponsetSocket,
} from '../../src/store/features/Reports/PerformanceReports/delayAndResponseSlice';
import interfaceReducer, {
  initRealTimeInterfaceLevelChart, addRealtimeInterfaceLevelChartPoint,
  clearRealtimeInterfaceLevelChartData,
  setSubscribeToRealtimeInterfaceLevelReportSocket,
} from '../../src/store/features/Reports/PerformanceReports/realTimeInterfaceLevelSlice';
import systemReducer, {
  initRealTimeChart, addRealtimeChartPoint, clearRealtimeChartData,
  setSubscribeToRealtimeReportSocket,
} from '../../src/store/features/Reports/PerformanceReports/realTimeSystemSlice';
import certificateReducer, {
  setCertificateExportResponse, clearCertificateExportResponse,
} from '../../src/store/features/X509Certificate/certificateExportSlice';
import nodeReducer, {
  setDeployedSiteDetails, setRepDetails, setSavedRnmsDetails, setIsCnms,
  updateCnmsDetailsFromSidebar, setAllTerminalTypeDetails, updateRnmsLatLong,
} from '../../src/store/features/nodeDetailsSlice';

const quiet = (fn) => {
  const spy = jest.spyOn(console, 'log').mockImplementation(() => {});
  try { return fn(); } finally { spy.mockRestore(); }
};

describe('additional Redux slice behaviour', () => {
  test('CNMS form data can be populated, saved and cleared', () => {
    let state = cnmsReducer(undefined, { type: '@@init' });
    state = cnmsReducer(state, setMountAbuDetails({ site: 'Mount Abu' }));
    state = cnmsReducer(state, setKasauliDetails({ site: 'Kasauli' }));
    state = cnmsReducer(state, setRepresentatives({ mountAbu: ['A'], kasauli: ['B'] }));
    state = cnmsReducer(state, setLoading(true));
    expect(state).toMatchObject({ mountAbu: { site: 'Mount Abu' }, kasauli: { site: 'Kasauli' }, loading: true });
    state = cnmsReducer(state, setCnmsSavedRnmsDetails({ id: 9 }));
    expect(state).toMatchObject({ savedData: { id: 9 }, mountAbu: null, kasauli: null, representatives: { mountAbu: [], kasauli: [] } });
    state = cnmsReducer(state, setMountAbuDetails({ id: 1 }));
    state = cnmsReducer(state, clearCnmsData());
    expect(state.mountAbu).toBeNull();
    expect(state.representatives).toEqual({ mountAbu: [], kasauli: [] });
  });

  test('RNMS terminal types are replaced and cleared', () => {
    let state = terminalReducer(undefined, setRnmsterminaltypesData([{ id: 1 }, { id: 2 }]));
    expect(state.rnmsterminaltypesData).toHaveLength(2);
    state = terminalReducer(state, clearRnmsterminaltypesData());
    expect(state.rnmsterminaltypesData).toEqual([]);
  });

test('CNMS health status and availability reset to initial values', () => {
  let state = quiet(() =>
    cnmsStatusReducer(
      undefined,
      setHealthStatus({
        status: 1,
        timestamp: '2026-11-22T10:00:00Z',
      })
    )
  );

  state = quiet(() => cnmsStatusReducer(state, setCnmsLinkAvailable(true)));

  expect(state).toMatchObject({
    healthStatus: 1,
    lastUpdateTime: '2026-11-22T10:00:00Z',
    cnmsLinkAvailable: true,
  });
});

  test('delay chart initializes with a fallback window and optional initial point', () => {
    let state = delayReducer(undefined, initDelayAndResponseChart({ initialPoint: null, windowMinutes: '0' }));
    expect(state.delayAndResponseActiveWindowMinutes).toBe(1);
    expect(state.delayAndResponseChartData).toEqual([]);
    state = delayReducer(state, initDelayAndResponseChart({ initialPoint: { date: '2026-01-01T00:00:00Z' }, windowMinutes: '5.5' }));
    expect(state.delayAndResponseActiveWindowMinutes).toBe(5.5);
    expect(state.delayAndResponseChartData).toHaveLength(1);
  });

  test('delay chart appends points, trims one expired oldest point and supports clear and subscription', () => {
    const log = jest.spyOn(console, 'log').mockImplementation(() => {});
    try {
      let state = delayReducer(undefined, initDelayAndResponseChart({ initialPoint: { date: '2026-01-01T00:00:00Z' }, windowMinutes: 1 }));
      state = delayReducer(state, addDelayAndResponseChartPoint({ date: '2026-01-01T00:02:00Z' }));
      expect(state.delayAndResponseChartData).toHaveLength(1);
      state = delayReducer(state, setSubscribeToDelayAndResponsetSocket({ subscribe: true, resourceId: 'R1' }));
      expect(state).toMatchObject({ subscribeToDelayAndResponseSocket: true, currentDelayAndResponseResource: 'R1' });
      state = delayReducer(state, clearDelayAndResponseChartData());
      expect(state.delayAndResponseChartData).toEqual([]);
    } finally { log.mockRestore(); }
  });

  test('interface chart rejects invalid points, replaces duplicate timestamps and sorts valid points', () => {
    let state = interfaceReducer(undefined, initRealTimeInterfaceLevelChart({ initialPoint: null, windowMinutes: '3' }));
    state = interfaceReducer(state, addRealtimeInterfaceLevelChartPoint({ data: 1 }));
    state = interfaceReducer(state, addRealtimeInterfaceLevelChartPoint({ date: 'invalid', data: 1 }));
    state = interfaceReducer(state, addRealtimeInterfaceLevelChartPoint({ date: '2026-01-01T00:01:00Z', data: 'bad' }));
    expect(state.realtimeInterfaceLevelChartData).toEqual([]);
    state = interfaceReducer(state, addRealtimeInterfaceLevelChartPoint({ date: '2026-01-01T00:01:00Z', data: '2' }));
    state = interfaceReducer(state, addRealtimeInterfaceLevelChartPoint({ date: '2026-01-01T00:00:00Z', data: '1' }));
    state = interfaceReducer(state, addRealtimeInterfaceLevelChartPoint({ date: '2026-01-01T00:01:00Z', data: '3' }));
    expect(state.realtimeInterfaceLevelChartData.map((p) => p.data)).toEqual([1, 3]);
    state = interfaceReducer(state, setSubscribeToRealtimeInterfaceLevelReportSocket({ subscribe: true, resourceId: 'R2', paramId: 7, portId: 8 }));
    expect(state).toMatchObject({ subscribeToRealtimeInterfaceLevelReportSocket: true, currentRealtimeInterfaceResource: 'R2', currentRealtimeInterfaceParamId: 7, currentRealtimeInterfacePortId: 8 });
    state = interfaceReducer(state, clearRealtimeInterfaceLevelChartData());
    expect(state.realtimeInterfaceLevelChartData).toEqual([]);
  });

  test('interface chart trims points outside the active time window', () => {
    let state = interfaceReducer(undefined, initRealTimeInterfaceLevelChart({ initialPoint: null, windowMinutes: '1' }));
    state = interfaceReducer(state, addRealtimeInterfaceLevelChartPoint({ date: '2026-01-01T00:00:00Z', data: 1 }));
    state = interfaceReducer(state, addRealtimeInterfaceLevelChartPoint({ date: '2026-01-01T00:03:00Z', data: 2 }));
    expect(state.realtimeInterfaceLevelChartData.map((p) => p.data)).toEqual([2]);
  });

  test('system chart validates, replaces duplicates, sorts and trims points', () => {
    let state = systemReducer(undefined, initRealTimeChart({ initialPoint: null, windowMinutes: '2' }));
    state = systemReducer(state, addRealtimeChartPoint({ date: null, data: 1 }));
    state = systemReducer(state, addRealtimeChartPoint({ date: '2026-01-01T00:00:00Z', data: 'NaN' }));
    expect(state.realtimeChartData).toEqual([]);
    state = systemReducer(state, addRealtimeChartPoint({ date: '2026-01-01T00:02:00Z', data: '2' }));
    state = systemReducer(state, addRealtimeChartPoint({ date: '2026-01-01T00:01:00Z', data: '1' }));
    state = systemReducer(state, addRealtimeChartPoint({ date: '2026-01-01T00:02:00Z', data: '3' }));
    expect(state.realtimeChartData.map((p) => p.data)).toEqual([1, 3]);
    state = systemReducer(state, addRealtimeChartPoint({ date: '2026-01-01T00:05:00Z', data: '5' }));
    expect(state.realtimeChartData.map((p) => p.data)).toEqual([5]);
    state = systemReducer(state, setSubscribeToRealtimeReportSocket({ subscribe: true, resourceId: 'R3', paramId: 10 }));
    expect(state).toMatchObject({ subscribeToRealtimeReportSocket: true, realTimeCurrentDevice: 'R3', realTimeCurrentParamId: 10 });
    state = systemReducer(state, clearRealtimeChartData());
    expect(state.realtimeChartData).toEqual([]);
  });

  test('certificate response accepts values, defaults falsy values and clears', () => {
    let state = quiet(() => certificateReducer(undefined, setCertificateExportResponse('created')));
    expect(state.commandResponse).toBe('created');
    state = quiet(() => certificateReducer(state, setCertificateExportResponse(null)));
    expect(state.commandResponse).toBe('');
    state = certificateReducer(state, clearCertificateExportResponse());
    expect(state.commandResponse).toBe('');
  });

  test('node details setters, matching sidebar updates and coordinate updates', () => {
    let state = nodeReducer(undefined, setDeployedSiteDetails({ siteId: 1 }));
    state = nodeReducer(state, setRepDetails([{ id: 1, name: 'Old' }, { id: 2, name: 'Keep' }]));
    state = nodeReducer(state, setSavedRnmsDetails({ saved: true }));
    state = nodeReducer(state, setIsCnms(true));
    state = nodeReducer(state, setAllTerminalTypeDetails(['A', 'B']));
    state = nodeReducer(state, updateCnmsDetailsFromSidebar([{ id: 1, name: 'New', active: true }, { id: 3, name: 'Ignore' }]));
    expect(state.repDetails).toEqual([{ id: 1, name: 'New', active: true }, { id: 2, name: 'Keep' }]);
    expect(state).toMatchObject({ siteDetails: { siteId: 1 }, savedRnmsDetails: { saved: true }, isCnms: true, allTerminalTypeDetails: ['A', 'B'] });
    state = nodeReducer(state, updateCnmsDetailsFromSidebar('not-an-array'));
    expect(state.repDetails[0].name).toBe('New');
    state = nodeReducer(state, setRepDetails({ id: 10, name: 'Representative' }));
    state = nodeReducer(state, updateRnmsLatLong({ latitude: 12.3, longitude: 77.5 }));
    expect(state.repDetails).toMatchObject({ latitude: 12.3, longitude: 77.5 });
  });
});
