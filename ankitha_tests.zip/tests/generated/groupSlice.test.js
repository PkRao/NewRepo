import reducer, { setAllGroups, setLoading, setError, updateGroup } from '../../src/store/features/Cnms/GetAllGroups/groupSlice';

describe('CNMS groups slice', () => {
  test('initializes group collection and request state', () => expect(reducer(undefined, { type: '@@INIT' })).toEqual({ allGroups: [], loading: false, error: null }));
  test('stores groups and clears previous loading/error state', () => {
    const next = reducer({ allGroups: [], loading: true, error: 'old' }, setAllGroups([{ id: 1 }]));
    expect(next).toEqual({ allGroups: [{ id: 1 }], loading: false, error: null });
  });
  test('sets loading and error states', () => {
    let next = reducer(undefined, setLoading(true));
    expect(next.loading).toBe(true);
    next = reducer(next, setError('network error'));
    expect(next).toMatchObject({ loading: false, error: 'network error' });
  });
  test('updates an existing group and ignores an unknown id', () => {
    const state = { allGroups: [{ id: 1, name: 'Old' }] };
    expect(reducer(state, updateGroup({ id: 1, name: 'New' })).allGroups[0].name).toBe('New');
    expect(reducer(state, updateGroup({ id: 2, name: 'Missing' })).allGroups).toEqual(state.allGroups);
  });
});
