import {
  SiteNumberValidator, SitenameValidator, SiteNicknameValidator, UnitNameValidator,
  UsernameValidator, PasswordValidator, DynamicRangeValidator, createDynamicSchema,
  generateDynamicSchema, isValidIpV4, ipToLong, isValidIpRange,
} from '../../src/utility/FormValidation/YupSchema';

describe('Yup field validators', () => {
  test('validates site number range and integer constraint', async () => {
    await expect(SiteNumberValidator.validate(10)).resolves.toBe(10);
    await expect(SiteNumberValidator.validate(0)).rejects.toThrow();
    await expect(SiteNumberValidator.validate(1.5)).rejects.toThrow();
  });
  test('validates site names and nicknames', async () => {
    await expect(SitenameValidator.validate('Main-Site')).resolves.toBe('Main-Site');
    await expect(SitenameValidator.validate('1Invalid')).rejects.toThrow();
    await expect(SiteNicknameValidator.validate('Site_01')).resolves.toBe('Site_01');
    await expect(SiteNicknameValidator.validate('@invalid')).rejects.toThrow();
  });
  test('validates unit names, usernames and passwords', async () => {
    await expect(UnitNameValidator.validate('Router 01')).resolves.toBe('Router 01');
    await expect(UnitNameValidator.validate('123')).rejects.toThrow();
    await expect(UsernameValidator.validate('operator_1')).resolves.toBe('operator_1');
    await expect(UsernameValidator.validate('a')).rejects.toThrow();
    await expect(PasswordValidator.validate('Admin123')).resolves.toBe('Admin123');
    await expect(PasswordValidator.validate('password')).rejects.toThrow();
  });
  test('supports dynamic numeric and text field schemas', async () => {
    const schema = createDynamicSchema([
      { label: 'threshold', dataType: 'Number', minValue: 1, maxValue: 10 },
      { label: 'name', type: 'Text', minValue: 2, maxValue: 8 },
    ]);
    await expect(schema.validate({ threshold: 5, name: 'Router' })).resolves.toMatchObject({ threshold: 5, name: 'Router' });
    await expect(schema.validate({ threshold: 11, name: 'Router' })).rejects.toThrow();
    await expect(schema.validate({ threshold: '', name: 'R' })).rejects.toThrow();
  });
  test('supports a dynamic range schema and generated id-based schema', async () => {
    await expect(DynamicRangeValidator(2, 5).validate(3)).resolves.toBe(3);
    await expect(DynamicRangeValidator(2, 5).validate(1)).rejects.toThrow();
    const schema = generateDynamicSchema([{ id: 'rtt', min: 1, max: 100 }]);
    await expect(schema.validate({ rtt: 20 })).resolves.toEqual({ rtt: 20 });
    await expect(schema.validate({ rtt: 101 })).rejects.toThrow();
  });
});

describe('IPv4 range helpers', () => {
  test.each(['10.0.0.1', '192.168.1.254', '1.2.3.4'])('accepts valid IPv4 %s', (ip) => expect(isValidIpV4(ip)).toBe(true));
  test.each(['256.1.1.1', '10.0.0', '0.0.0.0', '255.255.255.255', 'abc'])('rejects invalid IPv4 %s', (ip) => expect(isValidIpV4(ip)).toBe(false));
  test('converts IPv4 to unsigned integer', () => expect(ipToLong('192.168.1.1')).toBe(3232235777));
  test('validates ordered IP ranges and rejects invalid/reversed ranges', () => {
    expect(isValidIpRange('10.0.0.1', '10.0.0.20')).toBe(true);
    expect(isValidIpRange('10.0.0.20', '10.0.0.1')).toBe(false);
    expect(isValidIpRange('bad', '10.0.0.1')).toBe(false);
  });
});
