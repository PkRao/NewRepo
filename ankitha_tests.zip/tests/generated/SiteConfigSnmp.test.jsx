import React from "react";
import { jest } from "@jest/globals";
import {
  render,
  screen,
  fireEvent,
  waitFor,
} from "@testing-library/react";

// ---------------------------------------------------------
// Mock functions
// ---------------------------------------------------------

const mockTopologyAxios = jest.fn();
const mockToast = jest.fn();
const mockExportToCSV = jest.fn();
const mockExportToPDF = jest.fn();

// ---------------------------------------------------------
// Native ESM mocks
// All mocks must be registered before importing the component.
// ---------------------------------------------------------

jest.unstable_mockModule("@/RestAPI/api/axiosApicall", () => ({
  TopologyAxios: mockTopologyAxios,
}));

jest.unstable_mockModule("@/RestAPI/url/endpoint", () => ({
  FETCH_SNMP_PROFILE_DETAILS: "/api/snmp/list",
  DELETE_SNMP_PROFILE_DETAILS: "/api/snmp/delete",
}));

jest.unstable_mockModule("@/components/Reusable/Toast/Toast", () => ({
  default: mockToast,
}));

jest.unstable_mockModule("@/components/Reusable/Pdf/downloadPdf", () => ({
  exportToCSV: mockExportToCSV,
  exportToPDF: mockExportToPDF,
}));

jest.unstable_mockModule("@/assets/SVGIcons/Delete_Icon_.svg", () => ({
  default: "delete-icon.svg",
}));

jest.unstable_mockModule("@/lib/utils", () => ({
  SECURITY_LEVEL_MAP: {
    1: "noAuthNoPriv",
    3: "authPriv",
  },

  AUTH_PROTOCOL_MAP: {
    4: "SHA256",
  },

  PRIV_PROTOCOL_MAP: {
    4: "AES256",
  },
}));

// ---------------------------------------------------------
// MTable mock
// This prevents loading MTable's internal dependencies,
// including ViewAugmentation.
// ---------------------------------------------------------

jest.unstable_mockModule("@/components/Reusable/Table/MTable", () => ({
  default: function MockMTable({
    tableData = [],
    AddText = "Add",
    handleAdd,
    handleEdit,
    handleView,
    handleDelete,
    handleDownloadPDF,
    handleDownloadCSV,
  }) {
    return (
      <div data-testid="mtable">
        <span data-testid="row-count">{tableData.length}</span>

        <button
          type="button"
          onClick={() => handleAdd?.({ extra: "arg" })}
        >
          {AddText}
        </button>

        <button type="button" onClick={handleDownloadPDF}>
          Export PDF
        </button>

        <button type="button" onClick={handleDownloadCSV}>
          Export CSV
        </button>

        {tableData.map((row, idx) => (
          <div
            key={row.snmpProfileId || idx}
            data-testid={`row-${idx}`}
          >
            <span>{row.snmpProfileName}</span>

            <span data-testid={`version-${idx}`}>
              {String(row.version)}
            </span>

            <button
              type="button"
              onClick={() => handleView?.(row)}
            >
              View {idx}
            </button>

            <button
              type="button"
              onClick={() => handleEdit?.(row)}
            >
              Edit {idx}
            </button>

            <button
              type="button"
              onClick={() => handleDelete?.(row)}
            >
              Delete {idx}
            </button>
          </div>
        ))}
      </div>
    );
  },
}));

// ---------------------------------------------------------
// MDialog mock
// ---------------------------------------------------------

jest.unstable_mockModule("@/components/Reusable/Dialog/MDialog", () => ({
  default: function MockMDialog({
    open,
    title,
    message,
    onConfirm,
    onClose,
  }) {
    if (!open) return null;

    return (
      <div role="dialog" aria-label={title}>
        <p>{message}</p>

        <button type="button" onClick={onConfirm}>
          Confirm Delete
        </button>

        <button type="button" onClick={onClose}>
          Cancel Delete
        </button>
      </div>
    );
  },
}));

// ---------------------------------------------------------
// Import component AFTER registering all mocks
// ---------------------------------------------------------

const { default: SiteConfigSnmp } = await import(
  "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/SiteConfiguator/Snmp/SiteConfigSnmp"
);

// ---------------------------------------------------------
// Test Suite
// ---------------------------------------------------------

describe("SiteConfigSnmp", () => {
  const handleAdd = jest.fn();
  const handleView = jest.fn();
  const handleEdit = jest.fn();

  const sampleProfiles = [
    {
      snmpProfileId: 10,
      snmpProfileName: "V1-Profile",
      port: "161",
      retries: "1",
      timeout: "2",
      version: 0,
      readCommunity: "public",
      writeCommunity: "private",
      ipAddress: "10.0.0.1",
    },
    {
      snmpProfileId: 11,
      snmpProfileName: "V2c-Profile",
      port: "161",
      retries: "2",
      timeout: "3",
      version: 1,
    },
    {
      snmpProfileId: 12,
      snmpProfileName: "V3-Profile",
      port: "161",
      retries: "3",
      timeout: "5",
      version: 3,
      username: "snmpuser",
      securityLevel: "3",
      contextName: "ctx",
      authProtocol: "4",
      authPassword: "auth_secret",
      privProtocol: "4",
      privPassword: "priv_secret",
    },
    {
      snmpProfileId: 13,
      snmpProfileName: "CustomVer-Profile",
      version: "custom-v",
    },
  ];

  beforeEach(() => {
    jest.clearAllMocks();
  });

  // -------------------------------------------------------
  // Test 1: Fetch, version mapping, Add/Edit/View and Export
  // -------------------------------------------------------

  test(
    "fetches SNMP profiles, maps versions, triggers Add/Edit/View, and exports PDF & CSV",
    async () => {
      mockTopologyAxios.mockResolvedValueOnce({
        data: sampleProfiles,
      });

      render(
        <SiteConfigSnmp
          privilegeKey="SNMP_KEY"
          refreshTrigger={0}
          handleAdd={handleAdd}
          handleView={handleView}
          handleEdit={handleEdit}
        />
      );

      await waitFor(() => {
        expect(screen.getByTestId("row-count")).toHaveTextContent("4");
      });

      expect(mockTopologyAxios).toHaveBeenCalledWith(
        "/api/snmp/list",
        "get"
      );

      // Version mapping
      expect(screen.getByTestId("version-0")).toHaveTextContent("1");
      expect(screen.getByTestId("version-1")).toHaveTextContent("2c");
      expect(screen.getByTestId("version-2")).toHaveTextContent("3");
      expect(screen.getByTestId("version-3")).toHaveTextContent(
        "custom-v"
      );

      // Add
      fireEvent.click(
        screen.getByRole("button", { name: "Create" })
      );

      expect(handleAdd).toHaveBeenCalledWith({
        extra: "arg",
        mode: "CREATE",
        title: "Add SNMP Profile",
      });

      // Edit
      fireEvent.click(
        screen.getByRole("button", { name: "Edit 0" })
      );

      expect(handleEdit).toHaveBeenCalledWith(
        expect.objectContaining({
          snmpProfileId: 10,
          snmpProfileName: "V1-Profile",
          version: "1",
          mode: "EDIT",
          title: "Edit Profile: V1-Profile ",
        })
      );

      // View
      fireEvent.click(
        screen.getByRole("button", { name: "View 2" })
      );

      expect(handleView).toHaveBeenCalledWith(
        expect.objectContaining({
          snmpProfileId: 12,
          snmpProfileName: "V3-Profile",
          version: "3",
          mode: "VIEW",
          title: "View Profile: V3-Profile ",
        })
      );

      // Export PDF
      fireEvent.click(
        screen.getByRole("button", { name: "Export PDF" })
      );

      expect(mockExportToPDF).toHaveBeenCalledWith(
        "SNMP Report",
        expect.any(Array),
        expect.arrayContaining([
          expect.objectContaining({
            snmpProfileName: "V3-Profile",
            securityLevel: "authPriv",
            authProtocol: "SHA256",
            privProtocol: "AES256",
          }),

          expect.objectContaining({
            snmpProfileName: "V2c-Profile",
            username: "-",
            securityLevel: "-",
            contextName: "-",
            authPassword: "-",
            authProtocol: "-",
            privPassword: "-",
            privProtocol: "-",
            readCommunity: "-",
            writeCommunity: "-",
            ipAddress: "-",
          }),
        ]),
        "SNMP_Report"
      );

      // Export CSV
      fireEvent.click(
        screen.getByRole("button", { name: "Export CSV" })
      );

      expect(mockExportToCSV).toHaveBeenCalledWith(
        "SNMP_Export",
        expect.any(Array),
        expect.any(Array)
      );
    }
  );

  // -------------------------------------------------------
  // Test 2: Refresh trigger and fetch failure
  // -------------------------------------------------------

  test(
    "re-fetches data when refreshTrigger changes and handles fetch failure",
    async () => {
      mockTopologyAxios.mockResolvedValueOnce({
        data: [sampleProfiles[0]],
      });

      const { rerender } = render(
        <SiteConfigSnmp
          privilegeKey="SNMP_KEY"
          refreshTrigger={1}
          handleAdd={handleAdd}
          handleView={handleView}
          handleEdit={handleEdit}
        />
      );

      await waitFor(() => {
        expect(screen.getByTestId("row-count")).toHaveTextContent("1");
      });

      mockTopologyAxios.mockRejectedValueOnce(
        new Error("Fetch failed")
      );

      rerender(
        <SiteConfigSnmp
          privilegeKey="SNMP_KEY"
          refreshTrigger={2}
          handleAdd={handleAdd}
          handleView={handleView}
          handleEdit={handleEdit}
        />
      );

      await waitFor(() => {
        expect(mockToast).toHaveBeenCalledWith(
          "Error!",
          "Failed to fetch Snmp Details",
          "error"
        );
      });
    }
  );

  // -------------------------------------------------------
  // Test 3: Delete confirmation, cancellation and outcomes
  // -------------------------------------------------------

  test(
    "handles delete confirmation, cancel, success, assigned-profile response, and delete error",
    async () => {
      mockTopologyAxios.mockResolvedValueOnce({
        data: [
          sampleProfiles[0],
          sampleProfiles[1],
          sampleProfiles[2],
        ],
      });

      render(
        <SiteConfigSnmp
          privilegeKey="SNMP_KEY"
          refreshTrigger={0}
          handleAdd={handleAdd}
          handleView={handleView}
          handleEdit={handleEdit}
        />
      );

      await waitFor(() => {
        expect(screen.getByTestId("row-count")).toHaveTextContent("3");
      });

      // Open delete dialog and cancel
      fireEvent.click(
        screen.getByRole("button", { name: "Delete 0" })
      );

      expect(
        screen.getByRole("dialog", { name: "Confirm Action" })
      ).toBeInTheDocument();

      fireEvent.click(
        screen.getByRole("button", { name: "Cancel Delete" })
      );

      expect(screen.queryByRole("dialog")).not.toBeInTheDocument();

      // ---------------------------------------------------
      // 1. Delete success
      // ---------------------------------------------------

      mockTopologyAxios.mockResolvedValueOnce({
        data: { deleted: true },
      });

      fireEvent.click(
        screen.getByRole("button", { name: "Delete 0" })
      );

      fireEvent.click(
        screen.getByRole("button", { name: "Confirm Delete" })
      );

      await waitFor(() => {
        expect(mockTopologyAxios).toHaveBeenCalledWith(
          "/api/snmp/delete/10",
          "post",
          ""
        );

        expect(mockToast).toHaveBeenCalledWith(
          "Success!",
          "SNMP Profile  deleted Successfully.",
          "success"
        );

        expect(screen.getByTestId("row-count")).toHaveTextContent("2");
      });

      // ---------------------------------------------------
      // 2. Profile assigned to device
      // ---------------------------------------------------

      mockTopologyAxios.mockResolvedValueOnce({
        data: null,
      });

      fireEvent.click(
        screen.getByRole("button", { name: "Delete 0" })
      );

      fireEvent.click(
        screen.getByRole("button", { name: "Confirm Delete" })
      );

      await waitFor(() => {
        expect(mockToast).toHaveBeenCalledWith(
          "Error!",
          "Profile is assigned to a device and cannot be removed.",
          "error"
        );

        expect(screen.getByTestId("row-count")).toHaveTextContent("2");
      });

      // ---------------------------------------------------
      // 3. Delete request throws an error
      // ---------------------------------------------------

      mockTopologyAxios.mockRejectedValueOnce(
        new Error("Delete error")
      );

      fireEvent.click(
        screen.getByRole("button", { name: "Delete 0" })
      );

      fireEvent.click(
        screen.getByRole("button", { name: "Confirm Delete" })
      );

      await waitFor(() => {
        expect(mockToast).toHaveBeenCalledWith(
          "Error!",
          "Failed to delete user.",
          "error"
        );
      });
    }
  );
});
