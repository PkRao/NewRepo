import reducer, {
  setSiteSummary, updateSiteSummarySite, removeSiteFromSummary, clearSiteSummary,
} from '../../src/store/features/Cnms/SiteSummary/siteSummarySlice';

describe('CNMS site summary slice', () => {
  test('sets site summary and marks the slice initialized', () => {
    let state = reducer(undefined, setSiteSummary([{ siteId: 1 }]));
    expect(state).toMatchObject({ sites: [{ siteId: 1 }], initialized: true });
    state = reducer(state, setSiteSummary({ invalid: true }));
    expect(state.sites).toEqual([]);
  });
  test('updates an existing site and inserts a new site', () => {
    let state = reducer(undefined, setSiteSummary([{ siteId: 1, name: 'Old', active: false }]));
    state = reducer(state, updateSiteSummarySite({ siteId: 1, name: 'New', active: true }));
    expect(state.sites[0]).toEqual({ siteId: 1, name: 'New', active: true });
    state = reducer(state, updateSiteSummarySite({ siteId: 2, name: 'Added' }));
    expect(state.sites).toHaveLength(2);
    expect(state.sites[1]).toEqual({ siteId: 2, name: 'Added' });
  });
  test('ignores falsy updates and removes a site by id', () => {
    let state = reducer(undefined, setSiteSummary([{ siteId: 1 }, { siteId: 2 }]));
    expect(reducer(state, updateSiteSummarySite(null)).sites).toHaveLength(2);
    state = reducer(state, removeSiteFromSummary({ siteId: 1 }));
    expect(state.sites).toEqual([{ siteId: 2 }]);
  });
  test('clears sites and resets initialized state', () => {
    const state = reducer(undefined, setSiteSummary([{ siteId: 1 }]));
    expect(reducer(state, clearSiteSummary())).toEqual({ sites: [], loading: false, initialized: false });
  });
});
