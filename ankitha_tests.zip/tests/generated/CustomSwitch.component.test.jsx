import React from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import CustomSwitch from "../../src/components/Switch/CustomSwitch";

describe("CustomSwitch", () => {
  test("renders an unchecked switch by default", () => {
    render(<CustomSwitch />);

    const switchElement = screen.getByRole("switch");
    expect(switchElement).toBeInTheDocument();
    expect(switchElement).not.toBeChecked();
    expect(switchElement).toBeEnabled();
  });

  test("renders the switch in the checked state", () => {
    render(<CustomSwitch checked onChange={() => {}} />);

    expect(screen.getByRole("switch")).toBeChecked();
  });

  test("forwards the change event and checked value to onChange", () => {
    const onChange = jest.fn();
    render(<CustomSwitch checked={false} onChange={onChange} />);

    fireEvent.click(screen.getByRole("switch"));

    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange.mock.calls[0][1]).toBe(true);
  });

  test("supports changing from checked to unchecked", () => {
    const onChange = jest.fn();
    render(<CustomSwitch checked onChange={onChange} />);

    fireEvent.click(screen.getByRole("switch"));

    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange.mock.calls[0][1]).toBe(false);
  });

  test("renders a disabled switch with the disabled attribute", () => {
    const onChange = jest.fn();
    render(<CustomSwitch disabled checked={false} onChange={onChange} />);

    const switchElement = screen.getByRole("switch");
    expect(switchElement).toBeDisabled();

    // A disabled native input is not interactable by a user. fireEvent dispatches
    // low-level synthetic events and is not a reliable simulation of that behavior.
    expect(switchElement).not.toBeChecked();
  });

  test("forwards name, value, and accessible input attributes through slotProps", () => {
    render(
      <CustomSwitch
        name="notifications"
        value="enabled"
        slotProps={{
          input: { "aria-label": "Notification preference" },
        }}
      />
    );

    const switchElement = screen.getByRole("switch", {
      name: "Notification preference",
    });

    expect(switchElement).toHaveAttribute("name", "notifications");
    expect(switchElement).toHaveAttribute("value", "enabled");
  });

  test("supports the small size", () => {
    render(<CustomSwitch size="small" />);

    expect(
      screen.getByRole("switch").closest(".MuiSwitch-root")
    ).toHaveClass("MuiSwitch-sizeSmall");
  });

  test("supports the medium size", () => {
    render(<CustomSwitch size="medium" />);

    expect(
      screen.getByRole("switch").closest(".MuiSwitch-root")
    ).toHaveClass("MuiSwitch-sizeMedium");
  });

  test("forwards a custom class name and id", () => {
    render(<CustomSwitch className="custom-switch" id="status-switch" />);

    const root = screen.getByRole("switch").closest(".MuiSwitch-root");
    expect(root).toHaveClass("custom-switch");
    expect(screen.getByRole("switch")).toHaveAttribute("id", "status-switch");
  });

  test("forwards color and edge properties to the underlying MUI switch", () => {
    render(<CustomSwitch color="secondary" edge="end" />);

    const root = screen.getByRole("switch").closest(".MuiSwitch-root");
    const switchBase = root.querySelector(".MuiSwitch-switchBase");

    expect(switchBase).toHaveClass("MuiSwitch-colorSecondary");
    expect(root).toHaveClass("MuiSwitch-edgeEnd");
  });
});
