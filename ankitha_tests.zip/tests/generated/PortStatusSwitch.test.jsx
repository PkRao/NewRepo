import React from "react";
import { render, screen, within } from "@testing-library/react";
import "@testing-library/jest-dom";
import { jest } from "@jest/globals";



// Mock port status metadata.
jest.unstable_mockModule(
  "@/Pages/Rnmsdashboard/PortStatus/data/portStatusData",
  () => ({
    PORT_STATUS_META: {
      UP: { label: "Up", icon: "up.svg" },
      DOWN: { label: "Down", icon: "down.svg" },
      WARNING: { label: "Warning", icon: "warning.svg" },
      notConfigured: {
        label: "Not Configured",
        icon: "not-configured.svg",
      },
    },
  })
);

// Import MUI theme utilities.
const { ThemeProvider, createTheme } = await import("@mui/material");

// Import component after registering mocks.
const { PortStatusSwitch } = await import(
  "@/Pages/Rnmsdashboard/PortStatus/PortStatusSwitch"
);

describe("PortStatusSwitch Component", () => {
  const mockTheme = createTheme({
    palette: {
      mode: "light",
      text: {
        porttextcolor: "#333333",
      },
    },
  });

  const mockDevice = {
    id: 1,
    title: "Switch Device 1",
    ports: [
      {
        id: "P1",
        name: "Port 1",
        visualIndex: 1,
        status: "UP",
      },
      {
        id: "P2",
        name: "Port 2",
        visualIndex: 2,
        status: "DOWN",
      },
      {
        id: "P3",
        name: "Port 3",
        visualIndex: 3,
        status: "WARNING",
      },
      {
        id: "P4",
        name: "Port 4",
        visualIndex: 4,
        status: "UP",
      },
    ],
  };

  const renderComponent = (device = mockDevice) => {
    return render(
      <ThemeProvider theme={mockTheme}>
        <PortStatusSwitch device={device} />
      </ThemeProvider>
    );
  };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  test("should render PortStatusSwitch successfully", () => {
    const { container } = renderComponent();

    expect(container.querySelector(".switch-card")).toBeInTheDocument();
  });

  test("should display device title", () => {
    renderComponent();

    expect(screen.getByText("Switch Device 1")).toBeInTheDocument();
  });

  test("should render switch background image", () => {
    renderComponent();

    expect(screen.getByAltText("switch shell")).toBeInTheDocument();
  });

  test("should render top and bottom port rows", () => {
    const { container } = renderComponent();

    expect(container.querySelector(".top-row")).toBeInTheDocument();
    expect(container.querySelector(".bottom-row")).toBeInTheDocument();
  });

  test("should render odd visualIndex ports in top row", () => {
    const { container } = renderComponent();

    const topRow = container.querySelector(".top-row");

    expect(within(topRow).getByText("Port 1")).toBeInTheDocument();
    expect(within(topRow).getByText("Port 3")).toBeInTheDocument();

    expect(within(topRow).queryByText("Port 2")).not.toBeInTheDocument();
    expect(within(topRow).queryByText("Port 4")).not.toBeInTheDocument();
  });

  test("should render even visualIndex ports in bottom row", () => {
    const { container } = renderComponent();

    const bottomRow = container.querySelector(".bottom-row");

    expect(within(bottomRow).getByText("Port 2")).toBeInTheDocument();
    expect(within(bottomRow).getByText("Port 4")).toBeInTheDocument();

    expect(within(bottomRow).queryByText("Port 1")).not.toBeInTheDocument();
    expect(within(bottomRow).queryByText("Port 3")).not.toBeInTheDocument();
  });

  test("should render all regular ports", () => {
    const { container } = renderComponent();

    expect(container.querySelectorAll(".port-face")).toHaveLength(4);
  });

  test("should display correct port title attribute", () => {
    renderComponent();

    expect(screen.getByTitle("Port 1 - Up")).toBeInTheDocument();
    expect(screen.getByTitle("Port 2 - Down")).toBeInTheDocument();
  });

  test("should render correct status icon for each port", () => {
    renderComponent();

    expect(
      screen.getByTitle("Port 1 - Up").querySelector("img")
    ).toHaveAttribute("src", "up.svg");

    expect(
      screen.getByTitle("Port 2 - Down").querySelector("img")
    ).toHaveAttribute("src", "down.svg");
  });

  test("should use notConfigured metadata for unknown port status", () => {
    const device = {
      ...mockDevice,
      ports: [
        {
          id: "P5",
          name: "Port 5",
          visualIndex: 1,
          status: "INVALID",
        },
      ],
    };

    renderComponent(device);

    expect(
      screen.getByTitle("Port 5 - Not Configured")
    ).toBeInTheDocument();

    expect(
      screen.getByTitle("Port 5 - Not Configured").querySelector("img")
    ).toHaveAttribute("src", "not-configured.svg");
  });

  test("should display top row port name before port button", () => {
    const { container } = renderComponent();

    const topPort = container.querySelector(".top-row .port-item");

    expect(topPort.querySelector(".port-name")).toHaveTextContent("Port 1");

    expect(topPort.querySelector(".port-name").nextElementSibling)
      .toHaveClass("port-face");
  });

  test("should display bottom row port name after port button", () => {
    const { container } = renderComponent();

    const bottomPort = container.querySelector(".bottom-row .port-item");

    expect(bottomPort.querySelector(".port-name")).toHaveTextContent("Port 2");

    expect(bottomPort.querySelector(".port-face").nextElementSibling)
      .toHaveClass("port-name");
  });

  test("should apply theme port text color", () => {
    const { container } = renderComponent();

    const portNames = container.querySelectorAll(".port-name");

    portNames.forEach((portName) => {
      expect(portName).toHaveStyle({
        color: "#333333",
      });
    });
  });

  test("should position a single port at 50 percent", () => {
    const device = {
      ...mockDevice,
      ports: [
        {
          id: "P1",
          name: "Port 1",
          visualIndex: 1,
          status: "UP",
        },
      ],
    };

    const { container } = renderComponent(device);

    const port = container.querySelector(".port-item");

    expect(port).toHaveStyle({ left: "50%" });
  });

  test("should position first and last ports at 0 and 100 percent", () => {
    const { container } = renderComponent();

    const topPorts = container.querySelectorAll(".top-row .port-item");

    expect(topPorts[0]).toHaveStyle({ left: "0%" });
    expect(topPorts[1]).toHaveStyle({ left: "100%" });
  });

  test("should render TenGigabit ports separately", () => {
    const device = {
      ...mockDevice,
      ports: [
        ...mockDevice.ports,
        {
          id: "P25",
          name: "TenGigabit 1",
          visualIndex: 25,
          isTenGigabit: true,
          status: "UP",
        },
        {
          id: "P26",
          name: "TenGigabit 2",
          visualIndex: 26,
          isTenGigabit: true,
          status: "DOWN",
        },
      ],
    };

    const { container } = renderComponent(device);

    const specialLayer = container.querySelector(".special-ports-layer");

    expect(specialLayer).toBeInTheDocument();

    expect(within(specialLayer).getByText("TenGigabit 1"))
      .toBeInTheDocument();

    expect(within(specialLayer).getByText("TenGigabit 2"))
      .toBeInTheDocument();
  });

  test("should not render TenGigabit ports in regular rows", () => {
    const device = {
      ...mockDevice,
      ports: [
        ...mockDevice.ports,
        {
          id: "P25",
          name: "TenGigabit 1",
          visualIndex: 25,
          isTenGigabit: true,
          status: "UP",
        },
      ],
    };

    const { container } = renderComponent(device);

    const topRow = container.querySelector(".top-row");
    const bottomRow = container.querySelector(".bottom-row");

    expect(within(topRow).queryByText("TenGigabit 1"))
      .not.toBeInTheDocument();

    expect(within(bottomRow).queryByText("TenGigabit 1"))
      .not.toBeInTheDocument();
  });

  test("should not render special ports layer when no TenGigabit ports exist", () => {
    const { container } = renderComponent();

    expect(
      container.querySelector(".special-ports-layer")
    ).not.toBeInTheDocument();
  });

  test("should render correctly when device has no ports", () => {
    const device = {
      id: 2,
      title: "Empty Switch",
      ports: [],
    };

    const { container } = renderComponent(device);

    expect(screen.getByText("Empty Switch")).toBeInTheDocument();
    expect(container.querySelectorAll(".port-face")).toHaveLength(0);
  });

  test("should render only top row ports when all visualIndex values are odd", () => {
    const device = {
      ...mockDevice,
      ports: [
        { id: "P1", name: "Port 1", visualIndex: 1, status: "UP" },
        { id: "P3", name: "Port 3", visualIndex: 3, status: "UP" },
      ],
    };

    const { container } = renderComponent(device);

    expect(container.querySelectorAll(".top-row .port-item")).toHaveLength(2);
    expect(container.querySelectorAll(".bottom-row .port-item")).toHaveLength(0);
  });

  test("should render only bottom row ports when all visualIndex values are even", () => {
    const device = {
      ...mockDevice,
      ports: [
        { id: "P2", name: "Port 2", visualIndex: 2, status: "UP" },
        { id: "P4", name: "Port 4", visualIndex: 4, status: "UP" },
      ],
    };

    const { container } = renderComponent(device);

    expect(container.querySelectorAll(".top-row .port-item")).toHaveLength(0);
    expect(container.querySelectorAll(".bottom-row .port-item")).toHaveLength(2);
  });

  test("should determine row using visualIndex instead of array position", () => {
    const device = {
      ...mockDevice,
      ports: [
        { id: "P2", name: "Port 2", visualIndex: 2, status: "UP" },
        { id: "P1", name: "Port 1", visualIndex: 1, status: "UP" },
      ],
    };

    const { container } = renderComponent(device);

    expect(
      within(container.querySelector(".top-row")).getByText("Port 1")
    ).toBeInTheDocument();

    expect(
      within(container.querySelector(".bottom-row")).getByText("Port 2")
    ).toBeInTheDocument();
  });

  test("should distribute special ports between 0 and 100 percent", () => {
    const device = {
      ...mockDevice,
      ports: [
        {
          id: "P25",
          name: "TenGigabit 1",
          visualIndex: 25,
          isTenGigabit: true,
          status: "UP",
        },
        {
          id: "P26",
          name: "TenGigabit 2",
          visualIndex: 26,
          isTenGigabit: true,
          status: "UP",
        },
      ],
    };

    const { container } = renderComponent(device);

    const specialPorts = container.querySelectorAll(
      ".special-ports-layer .port-item"
    );

    expect(specialPorts[0]).toHaveStyle({ left: "0%" });
    expect(specialPorts[1]).toHaveStyle({ left: "100%" });
  });

  test("should render port buttons with type button", () => {
    const { container } = renderComponent();

    container.querySelectorAll(".port-face").forEach((button) => {
      expect(button).toHaveAttribute("type", "button");
    });
  });

  test("should render port icons as decorative images", () => {
    const { container } = renderComponent();

    container.querySelectorAll(".port-face img").forEach((img) => {
      expect(img).toHaveAttribute("alt", "");
      expect(img).toHaveAttribute("aria-hidden", "true");
    });
  });
});
