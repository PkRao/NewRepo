import React, { createContext, useContext } from "react";
import { jest } from "@jest/globals";
import { render, screen, within } from "@testing-library/react";
import { createTheme, ThemeProvider } from "@mui/material/styles";

const ChartDataContext = createContext([]);

jest.unstable_mockModule("recharts", () => {
  const ReactModule = React;

  const ResponsiveContainer = ({ children, width, height }) =>
    ReactModule.createElement(
      "div",
      {
        "data-testid": "responsive-container",
        "data-width": String(width),
        "data-height": String(height),
      },
      children
    );

  const BarChart = ({ data = [], children, margin, barGap, barSize }) =>
    ReactModule.createElement(
      ChartDataContext.Provider,
      { value: data },
      ReactModule.createElement(
        "div",
        {
          "data-testid": "bar-chart",
          "data-margin": JSON.stringify(margin),
          "data-bar-gap": String(barGap),
          "data-bar-size": String(barSize),
        },
        children
      )
    );

  const XAxis = ({ dataKey, tick, children, ...props }) => {
    const data = useContext(ChartDataContext);
    return ReactModule.createElement(
      "div",
      {
        "data-testid": "x-axis",
        "data-key": dataKey,
        "data-interval": String(props.interval),
      },
      data.map((row, index) =>
        ReactModule.cloneElement(tick, {
          key: `tick-${index}`,
          x: index,
          y: 0,
          payload: { value: row[dataKey] },
        })
      ),
      children
    );
  };

  const YAxis = ({ children, allowDecimals, tick }) =>
    ReactModule.createElement(
      "div",
      {
        "data-testid": "y-axis",
        "data-allow-decimals": String(allowDecimals),
        "data-tick": JSON.stringify(tick),
      },
      children
    );

  const Legend = ({ content, verticalAlign, align, wrapperStyle }) => {
    const payload = [
      { value: "Major", fill: "#major-fill" },
      { value: "Minor", fill: "#minor-fill" },
      { value: "Warning", fill: "#warning-fill" },
      { value: "Other", fill: "#fallback-fill" },
    ];

    return ReactModule.createElement(
      "div",
      {
        "data-testid": "chart-legend",
        "data-vertical-align": verticalAlign,
        "data-align": align,
        "data-wrapper-style": JSON.stringify(wrapperStyle),
      },
      content({ payload, title: "Alarm Levels" })
    );
  };

  const Bar = ({ dataKey, name, stackId, fill, radius }) =>
    ReactModule.createElement("div", {
      "data-testid": `bar-${dataKey}`,
      "data-name": name,
      "data-stack-id": stackId,
      "data-fill": fill,
      "data-radius": radius ? JSON.stringify(radius) : "",
    });

  const CartesianGrid = ({ vertical, stroke }) =>
    ReactModule.createElement("div", {
      "data-testid": "cartesian-grid",
      "data-vertical": String(vertical),
      "data-stroke": stroke,
    });

  const Tooltip = ({ cursor, contentStyle, labelStyle, itemStyle }) =>
    ReactModule.createElement("div", {
      "data-testid": "chart-tooltip",
      "data-cursor": JSON.stringify(cursor),
      "data-content-style": JSON.stringify(contentStyle),
      "data-label-style": JSON.stringify(labelStyle),
      "data-item-style": JSON.stringify(itemStyle),
    });

  const Label = ({ value, position, offset, angle, style }) =>
    ReactModule.createElement(
      "span",
      {
        "data-testid": `axis-label-${value}`,
        "data-position": position,
        "data-offset": offset === undefined ? "" : String(offset),
        "data-angle": angle === undefined ? "" : String(angle),
        "data-style": JSON.stringify(style),
      },
      value
    );

  return {
    ResponsiveContainer,
    BarChart,
    Bar,
    XAxis,
    YAxis,
    CartesianGrid,
    Tooltip,
    Legend,
    Label,
  };
});

const { default: AlarmTerminalChart } = await import(
  "../../src/Pages/CnmsDashboard/CnmsAlarmSummary/components/AlarmTerminalChart"
);

const chartBackground = "#f0f4f8";
const commonBorder = "1px solid rgb(190, 190, 190)";
const theme = createTheme({
  palette: {
    text: {
      primary: "#202020",
      secondary: "#606060",
    },
    background: {
      paper: "#ffffff",
      cardbg: "#fafafa",
    },
    divider: "#dddddd",
    custom: {
      chart: {
        chartbg: chartBackground,
        grid: "#eeeeee",
        text: "#505050",
        cursor: "#eeeeee",
        tooltipBg: "#fefefe",
        tooltipText: "#303030",
      },
      commonBorder,
    },
  },
});

const fallbackTheme = createTheme({
  palette: {
    text: {
      primary: "#111111",
      secondary: "#666666",
    },
    background: {
      paper: "#ffffff",
      cardbg: "#f7f7f7",
    },
    divider: "#cccccc",
    custom: {
      chart: {},
      commonBorder: "1px solid #aaaaaa",
    },
  },
});

const sampleData = [
  { terminal: "Router", major: 4, minor: 8, warning: 3 },
  { terminal: "LongTerminalName-01", major: 7, minor: 5, warning: 4 },
  { terminal: "", major: 0, minor: 0, warning: 0 },
  { terminal: "Switch", major: 2, minor: 3, warning: 1 },
];

const renderChart = (data = sampleData, selectedTheme = theme) =>
  render(
    <ThemeProvider theme={selectedTheme}>
      <AlarmTerminalChart data={data} />
    </ThemeProvider>
  );

describe("AlarmTerminalChart", () => {
  test("renders the responsive container and bar chart", () => {
    renderChart();

    expect(screen.getByTestId("responsive-container")).toHaveAttribute(
      "data-width",
      "100%"
    );
    expect(screen.getByTestId("responsive-container")).toHaveAttribute(
      "data-height",
      "100%"
    );
    expect(screen.getByTestId("bar-chart")).toBeInTheDocument();
  });

  test("renders all supplied terminal labels and formats long and empty values", () => {
    renderChart();

    const xAxis = screen.getByTestId("x-axis");
    expect(xAxis).toHaveAttribute("data-key", "terminal");
    expect(within(xAxis).getByText("Router")).toBeInTheDocument();
    expect(within(xAxis).getByText("LongTerminal...")).toBeInTheDocument();
    expect(within(xAxis).getByText("Switch")).toBeInTheDocument();

    const tickTexts = xAxis.querySelectorAll("text");
    expect(tickTexts).toHaveLength(4);
    expect(tickTexts[2]).toHaveTextContent("");
  });

  test("renders terminal and alarm-count axis labels", () => {
    renderChart();

    expect(screen.getByTestId("axis-label-Terminal Types")).toBeInTheDocument();
    expect(screen.getByTestId("axis-label-Alarm Count")).toBeInTheDocument();
    expect(screen.getByTestId("axis-label-Terminal Types")).toHaveAttribute(
      "data-position",
      "bottom"
    );
    expect(screen.getByTestId("axis-label-Alarm Count")).toHaveAttribute(
      "data-angle",
      "-90"
    );
  });

  test("configures the chart grid and numeric y-axis", () => {
    renderChart();

    expect(screen.getByTestId("cartesian-grid")).toHaveAttribute(
      "data-vertical",
      "false"
    );
    expect(screen.getByTestId("cartesian-grid")).toHaveAttribute(
      "data-stroke",
      "#eeeeee"
    );
    expect(screen.getByTestId("y-axis")).toHaveAttribute(
      "data-allow-decimals",
      "false"
    );
    expect(screen.getByTestId("y-axis")).toHaveAttribute(
      "data-tick",
      JSON.stringify({ fill: "#505050" })
    );
  });

  test("renders all three stacked alarm bars with the expected gradients", () => {
    renderChart();

    expect(screen.getByTestId("bar-major")).toHaveAttribute("data-name", "Major");
    expect(screen.getByTestId("bar-major")).toHaveAttribute(
      "data-stack-id",
      "terminalStack"
    );
    expect(screen.getByTestId("bar-major")).toHaveAttribute(
      "data-fill",
      "url(#cnmsMajorGrad)"
    );

    expect(screen.getByTestId("bar-minor")).toHaveAttribute("data-name", "Minor");
    expect(screen.getByTestId("bar-minor")).toHaveAttribute(
      "data-fill",
      "url(#cnmsMinorGrad)"
    );

    expect(screen.getByTestId("bar-warning")).toHaveAttribute(
      "data-name",
      "Warning"
    );
    expect(screen.getByTestId("bar-warning")).toHaveAttribute(
      "data-fill",
      "url(#cnmsWarningGrad)"
    );
    expect(screen.getByTestId("bar-warning")).toHaveAttribute(
      "data-radius",
      "[4,4,0,0]"
    );
  });

  test("renders all SVG gradient definitions and color stops", () => {
    renderChart();

    expect(document.getElementById("cnmsMajorGrad")).toBeInTheDocument();
    expect(document.getElementById("cnmsMinorGrad")).toBeInTheDocument();
    expect(document.getElementById("cnmsWarningGrad")).toBeInTheDocument();

    expect(document.querySelectorAll("#cnmsMajorGrad stop")).toHaveLength(2);
    expect(document.querySelectorAll("#cnmsMinorGrad stop")).toHaveLength(2);
    expect(document.querySelectorAll("#cnmsWarningGrad stop")).toHaveLength(2);
  });

  test("renders the custom legend title and alarm categories", () => {
    renderChart();

    const legend = screen.getByTestId("chart-legend");
    expect(within(legend).getByText("Alarm Levels")).toBeInTheDocument();
    expect(within(legend).getByText("Major")).toBeInTheDocument();
    expect(within(legend).getByText("Minor")).toBeInTheDocument();
    expect(within(legend).getByText("Warning")).toBeInTheDocument();
    expect(within(legend).getByText("Other")).toBeInTheDocument();
  });

  test("uses the mapped gradient fills for known legend values and entry fill for unknown values", () => {
    renderChart();

    const legend = screen.getByTestId("chart-legend");
    const circles = legend.querySelectorAll("circle");

    expect(circles[0]).toHaveAttribute("fill", "url(#cnmsMajorGrad)");
    expect(circles[1]).toHaveAttribute("fill", "url(#cnmsMinorGrad)");
    expect(circles[2]).toHaveAttribute("fill", "url(#cnmsWarningGrad)");
    expect(circles[3]).toHaveAttribute("fill", "#fallback-fill");
  });

  test("applies the chart container dimensions, background, and border", () => {
    renderChart();

    const container = screen.getByTestId("responsive-container").parentElement;
    expect(container).toHaveStyle({
      width: "100%",
      height: "300px",
      borderRadius: "12px",
      padding: "8px",
      boxSizing: "border-box",
      background: chartBackground,
      border: commonBorder,
    });
  });

  test("uses theme fallback colors when custom chart colors are not configured", () => {
    renderChart(sampleData, fallbackTheme);

    expect(screen.getByTestId("cartesian-grid")).toHaveAttribute(
      "data-stroke",
      "#cccccc"
    );
    expect(screen.getByTestId("y-axis")).toHaveAttribute(
      "data-tick",
      JSON.stringify({ fill: "#666666" })
    );

    const tooltip = screen.getByTestId("chart-tooltip");
    const cursor = JSON.parse(tooltip.getAttribute("data-cursor"));
    const contentStyle = JSON.parse(
      tooltip.getAttribute("data-content-style")
    );
    const labelStyle = JSON.parse(tooltip.getAttribute("data-label-style"));
    const itemStyle = JSON.parse(tooltip.getAttribute("data-item-style"));

    expect(cursor.fill).toBe("rgba(128,128,128,0.08)");
    expect(contentStyle.backgroundColor).toBe("#ffffff");
    expect(contentStyle.color).toBe("#111111");
    expect(labelStyle.color).toBe("#111111");
    expect(itemStyle.color).toBe("#111111");
  });

  test("uses configured tooltip and cursor colors", () => {
    renderChart();

    const tooltip = screen.getByTestId("chart-tooltip");
    const cursor = JSON.parse(tooltip.getAttribute("data-cursor"));
    const contentStyle = JSON.parse(
      tooltip.getAttribute("data-content-style")
    );
    const labelStyle = JSON.parse(tooltip.getAttribute("data-label-style"));
    const itemStyle = JSON.parse(tooltip.getAttribute("data-item-style"));

    expect(cursor.fill).toBe("#eeeeee");
    expect(contentStyle.backgroundColor).toBe("#fefefe");
    expect(contentStyle.color).toBe("#303030");
    expect(labelStyle.color).toBe("#303030");
    expect(itemStyle.color).toBe("#303030");
  });

  test("accepts an empty data array and defaults data when omitted", () => {
    const { unmount } = renderChart([]);
    expect(screen.getByTestId("bar-chart")).toBeInTheDocument();
    expect(screen.getByTestId("x-axis").querySelectorAll("text")).toHaveLength(0);

    unmount();
    render(
      <ThemeProvider theme={theme}>
        <AlarmTerminalChart />
      </ThemeProvider>
    );
    expect(screen.getByTestId("bar-chart")).toBeInTheDocument();
    expect(screen.getByTestId("x-axis").querySelectorAll("text")).toHaveLength(0);
  });

  test("configures chart spacing and legend alignment", () => {
    renderChart();

    expect(screen.getByTestId("bar-chart")).toHaveAttribute("data-bar-gap", "8");
    expect(screen.getByTestId("bar-chart")).toHaveAttribute(
      "data-bar-size",
      "30"
    );
    expect(screen.getByTestId("chart-legend")).toHaveAttribute(
      "data-vertical-align",
      "top"
    );
    expect(screen.getByTestId("chart-legend")).toHaveAttribute(
      "data-align",
      "right"
    );
  });
});
