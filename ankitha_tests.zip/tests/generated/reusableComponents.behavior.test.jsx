import React from 'react';
import { fireEvent, render, screen } from '@testing-library/react';

let mockUserState = { isReadOnlyMode: false, isUserLoggedIn: false };
jest.mock('react-redux', () => ({ useSelector: (selector) => selector({ userSlice: mockUserState }) }));
jest.mock('@/components/Reusable/Table/MTable', () => ({ __esModule: true, default: (props) => <div data-testid="vertical-table" data-rows={props.tableData.length} data-title={props.tableTitle} /> }));
jest.mock('../../src/components/Reusable/Input/MInput', () => (props) => <input aria-label="form-input" disabled={props.disabled} aria-invalid={Boolean(props.error)} />);

import BaseWidget from '../../src/Pages/Rnmsdashboard/RightUtilityDrawer/components/SNMPConfigurator/widgets/core/BaseWidget';
import TitleWidget from '../../src/Pages/Rnmsdashboard/RightUtilityDrawer/components/SNMPConfigurator/widgets/title/TitleWidget';
import ThermometerWidget from '../../src/Pages/Rnmsdashboard/RightUtilityDrawer/components/SNMPConfigurator/widgets/thermometer/ThermometerWidget';
import VerticalTableWidget from '../../src/Pages/Rnmsdashboard/RightUtilityDrawer/components/SNMPConfigurator/widgets/VerticalTable/VerticalTableWidget';
import MButton from '../../src/components/Reusable/Button/MButton';
import MButtonPrimary from '../../src/components/Reusable/Button/MButtonPrimary';
import MButtonSecondary from '../../src/components/Reusable/Button/MButtonSecondary';
import FormField from '../../src/components/Reusable/Form/FormField';
import CustomCard from '../../src/components/Reusable/Card/CustomCard';
import Loader from '../../src/components/Reusable/Loader/Loader';

beforeEach(() => {
  mockUserState = { isReadOnlyMode: false, isUserLoggedIn: false };
});

describe('basic SNMP widget components', () => {
  test('renders BaseWidget header and child content', () => {
    render(<BaseWidget title="Device status"><span>Online</span></BaseWidget>);
    expect(screen.getByText('Device status')).toBeInTheDocument();
    expect(screen.getByText('Online')).toBeInTheDocument();
  });

  test('renders TitleWidget content', () => {
    render(<TitleWidget content="Interface statistics" />);
    expect(screen.getByText('Interface statistics')).toBeInTheDocument();
  });

  test.each([
    [{ value: 0 }, 'Thermometer'],
    [{ value: 45, name: 'CPU temperature', config: { min: 10, max: 90 } }, 'CPU temperature'],
    [{ value: 150, config: { min: 0, max: 100 } }, 'Thermometer'],
    [{ value: -10, config: { min: 0, max: 100 } }, 'Thermometer'],
  ])('renders thermometer values and configured title', (props, title) => {
    render(<ThermometerWidget {...props} />);
    expect(screen.getByText(title)).toBeInTheDocument();
    expect(screen.getByText(`${props.value ?? 0}°`)).toBeInTheDocument();
  });

  test('maps API table rows into dynamic OID columns and handles missing data', () => {
    const { rerender } = render(<VerticalTableWidget tableTitle="Ports" tableId="portTable" dynamicColumns={[{ field: '1.2' }]} rawApiResponse={{ data: [{ oid: '1.2' }, { oid: '1.3' }], table: { portTable: [{ '1.2': 'GE0/1', '1.3': 'up' }, { '1.2': '', '1.3': 'down' }] } }} />);
    expect(screen.getByTestId('vertical-table')).toHaveAttribute('data-rows', '2');
    expect(screen.getByTestId('vertical-table')).toHaveAttribute('data-title', 'Ports');
    rerender(<VerticalTableWidget tableTitle="Empty" tableId="missing" dynamicColumns={[]} rawApiResponse={{ data: [], table: {} }} />);
    expect(screen.getByTestId('vertical-table')).toHaveAttribute('data-rows', '0');
  });
});

describe('reusable button components', () => {
  test('MButton applies primary and secondary classes and handles clicks', () => {
    const onClick = jest.fn();
    const { rerender } = render(<MButton onClick={onClick}>Save</MButton>);
    fireEvent.click(screen.getByRole('button', { name: 'Save' }));
    expect(onClick).toHaveBeenCalledTimes(1);
    expect(screen.getByRole('button')).toHaveClass('primary-btn');
    rerender(<MButton type="secondary" disabled>Cancel</MButton>);
    expect(screen.getByRole('button', { name: 'Cancel' })).toBeDisabled();
    expect(screen.getByRole('button')).toHaveClass('secondary-btn');
  });

  test('MButtonPrimary disables actions for a logged-in read-only user', () => {
    const onClick = jest.fn();
    const { rerender } = render(<MButtonPrimary onClick={onClick}>Edit</MButtonPrimary>);
    fireEvent.click(screen.getByRole('button', { name: 'Edit' }));
    expect(onClick).toHaveBeenCalledTimes(1);
    mockUserState = { isReadOnlyMode: true, isUserLoggedIn: true };
    rerender(<MButtonPrimary onClick={onClick}>Edit</MButtonPrimary>);
    expect(screen.getByRole('button', { name: 'Edit' })).toBeDisabled();
    rerender(<MButtonPrimary disabled>Disabled</MButtonPrimary>);
    expect(screen.getByRole('button', { name: 'Disabled' })).toBeDisabled();
  });

  test('MButtonSecondary honors explicit and read-only disabled states', () => {
    const { rerender } = render(<MButtonSecondary toolTipText="Cancel operation">Cancel</MButtonSecondary>);
    expect(
  screen.getByRole('button', { name: 'Cancel operation' })
).toBeEnabled();

mockUserState = { isReadOnlyMode: true, isUserLoggedIn: true };

rerender(
  <MButtonSecondary toolTipText="Read only">
    Cancel
  </MButtonSecondary>
);

expect(
  screen.getByRole('button', { name: 'Read only' })
).toBeDisabled();
    rerender(<MButtonSecondary disabled>Disabled</MButtonSecondary>);
    expect(screen.getByRole('button', { name: 'Disabled' })).toBeDisabled();
  });
});

describe('form, card and loading primitives', () => {
  test('FormField displays required marker and passes disabled/error flags to input', () => {
    const { rerender } = render(<FormField label="IP address" required />);
    expect(screen.getByText('*')).toBeInTheDocument();
    expect(screen.getByLabelText('form-input')).toBeEnabled();
    rerender(<FormField label="IP address" disabled error errorMessage="Invalid IP" />);
    expect(screen.getByLabelText('form-input')).toBeDisabled();
    expect(screen.getByLabelText('form-input')).toHaveAttribute('aria-invalid', 'true');
  });

  test('CustomCard renders nested content and Loader exposes a progress indicator', () => {
    const { container } = render(<CustomCard><span>Card body</span></CustomCard>);
    expect(screen.getByText('Card body')).toBeInTheDocument();
    expect(container.firstChild).toHaveClass('rounded-[12px]');
    const { getByRole } = render(<Loader />);
    expect(getByRole('progressbar')).toBeInTheDocument();
  });
});
