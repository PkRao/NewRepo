jest.mock('@/Pages/Rnmsdashboard/Topology/utils', () => ({ SEVERITY_COLOR: {} }));
import React from 'react';
import { render, screen } from '@testing-library/react';
import { Badge, badgeVariants } from '../../src/components/ui/Badge';

describe('Badge', () => {
  test('renders children with default variant classes', () => {
    render(<Badge>Connected</Badge>);
    expect(screen.getByText('Connected')).toHaveClass('inline-flex');
    expect(screen.getByText('Connected')).toHaveClass('bg-primary');
  });
  test('applies selected variant and custom class', () => {
    render(<Badge variant="outline" className="test-badge">Offline</Badge>);
    expect(screen.getByText('Offline')).toHaveClass('test-badge');
    expect(screen.getByText('Offline')).toHaveClass('text-foreground');
  });
  test('exports variant helper', () => expect(badgeVariants({ variant: 'destructive' })).toContain('bg-destructive'));
});
