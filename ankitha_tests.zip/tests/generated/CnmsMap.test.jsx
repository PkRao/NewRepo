import React from "react";
import { jest } from "@jest/globals";
import { render, screen } from "@testing-library/react";
import "@testing-library/jest-dom";

// CnmsMap imports MapIndex as a default export. Mock that exact dependency
// before loading CnmsMap so its React-Leaflet implementation is never loaded.
jest.unstable_mockModule(
  "../../src/Pages/CnmsDashboard/CnmsMap/MapIndex",
  () => ({
    __esModule: true,
    default: () => <div data-testid="mapindex">MapIndex</div>,
  })
);

const { default: CnmsMap } = await import(
  "../../src/Pages/CnmsDashboard/CnmsMap/CnmsMap"
);

describe("CnmsMap", () => {
  test("renders without crashing", () => {
    render(<CnmsMap />);
  });

  test("renders the map component", () => {
    render(<CnmsMap />);
    expect(screen.getByTestId("mapindex")).toBeInTheDocument();
  });
});
