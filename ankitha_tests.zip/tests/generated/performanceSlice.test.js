import reducer, { updatePerformanceData, resetPerformanceData } from '../../src/store/features/Performance/performanceSlice';

describe('performance slice', () => {
  test('initializes an empty performance map', () => {
    expect(reducer(undefined, { type: '@@INIT' })).toMatchObject({ performanceData: {}, resourceId: null, cpu: 0, memory: 0, disk: 0 });
  });
  test('creates resource buckets and records independent metrics', () => {
    let state = reducer(undefined, updatePerformanceData({ resourceId: 'R1', paramId: 1400, value: 55 }));
    state = reducer(state, updatePerformanceData({ resourceId: 'R1', paramId: 1600, value: 70 }));
    state = reducer(state, updatePerformanceData({ resourceId: 'R2', paramId: 1400, value: 20 }));
    expect(state.performanceData).toEqual({ R1: { 1400: 55, 1600: 70 }, R2: { 1400: 20 } });
    expect(state.resourceId).toBe('R2');
    expect(new Date(state.lastUpdated).toString()).not.toBe('Invalid Date');
  });
  test('reset restores the initial state', () => {
    const changed = reducer(undefined, updatePerformanceData({ resourceId: 1, paramId: 2, value: 3 }));
    expect(reducer(changed, resetPerformanceData())).toMatchObject({ performanceData: {}, resourceId: null, lastUpdated: null });
  });
});
