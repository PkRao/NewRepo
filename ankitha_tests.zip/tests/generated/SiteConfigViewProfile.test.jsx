import React from "react";
import { render, screen } from "@testing-library/react";
import SiteConfigViewProfile from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/SiteConfiguator/Snmp/SiteConfigViewProfile";

// ---- Mocks ----
jest.mock("@/components/Reusable/Input/MInput", () => {
  return function MockMInput({ value, disabled, fullWidth }) {
    return (
      <input
        value={value ?? ""}
        disabled={disabled}
        data-fullwidth={String(Boolean(fullWidth))}
      />
    );
  };
});

// ---- Helpers ----
const getDisabledInputByLabel = (labelText) => {
  const label = screen.getByText(labelText);
  return label.parentElement.querySelector("input");
};

describe("SiteConfigViewProfile", () => {
  test("renders empty/fallback values safely when data is missing or empty", () => {
    render(<SiteConfigViewProfile data={{}} />);

    expect(getDisabledInputByLabel("Profile Name")).toHaveValue("");
    expect(getDisabledInputByLabel("Port")).toHaveValue("");
    expect(getDisabledInputByLabel("No of Retries")).toHaveValue("");
    expect(getDisabledInputByLabel("Timeout (Sec)")).toHaveValue("");
    expect(getDisabledInputByLabel("Version")).toHaveValue("");
    expect(getDisabledInputByLabel("Read Community")).toHaveValue("");
    expect(getDisabledInputByLabel("Write Community")).toHaveValue("");

    // V3-only fields should not appear
    expect(screen.queryByText("Security Level")).not.toBeInTheDocument();
    expect(screen.queryByText("USM User")).not.toBeInTheDocument();
    expect(screen.queryByText("Auth Protocol")).not.toBeInTheDocument();
    expect(screen.queryByText("Priv Protocol")).not.toBeInTheDocument();

    screen.getAllByRole("textbox").forEach((input) => {
      expect(input).toBeDisabled();
    });
  });

  test("renders SNMP v1/v2c profile fields and maps version labels ('1', '2', '2c', and fallback)", () => {
    const { rerender } = render(
      <SiteConfigViewProfile
        data={{
          snmpProfileName: "Edge-V2c",
          port: "161",
          retries: "2",
          timeout: "5",
          version: "2c",
          readCommunity: "public_ro",
          writeCommunity: "private_rw",
        }}
      />
    );

    expect(getDisabledInputByLabel("Profile Name")).toHaveValue("Edge-V2c");
    expect(getDisabledInputByLabel("Port")).toHaveValue("161");
    expect(getDisabledInputByLabel("No of Retries")).toHaveValue("2");
    expect(getDisabledInputByLabel("Timeout (Sec)")).toHaveValue("5");
    expect(getDisabledInputByLabel("Version")).toHaveValue("2c");
    expect(getDisabledInputByLabel("Read Community")).toHaveValue("public_ro");
    expect(getDisabledInputByLabel("Write Community")).toHaveValue("private_rw");

    // Version "1"
    rerender(<SiteConfigViewProfile data={{ version: "1" }} />);
    expect(getDisabledInputByLabel("Version")).toHaveValue("1");

    // Version "2" -> "2c"
    rerender(<SiteConfigViewProfile data={{ version: 2 }} />);
    expect(getDisabledInputByLabel("Version")).toHaveValue("2c");

    // Unknown version -> fallback string
    rerender(<SiteConfigViewProfile data={{ version: "custom-v" }} />);
    expect(getDisabledInputByLabel("Version")).toHaveValue("custom-v");
  });

  test("renders SNMP v3 with security level '1' (No Auth / No Privacy) and hides Auth/Priv fields", () => {
    render(
      <SiteConfigViewProfile
        data={{
          snmpProfileName: "V3-NoAuth",
          port: "161",
          retries: "1",
          timeout: "3",
          version: 3,
          securityLevel: "1",
          userName: "camelCaseUser",
          contextName: "ctx0",
        }}
      />
    );

    expect(getDisabledInputByLabel("Version")).toHaveValue("3");
    expect(getDisabledInputByLabel("Security Level")).toHaveValue(
      "No Auth / No Privacy"
    );
    expect(getDisabledInputByLabel("USM User")).toHaveValue("camelCaseUser");
    expect(getDisabledInputByLabel("Context Name")).toHaveValue("ctx0");

    expect(screen.queryByText("Read Community")).not.toBeInTheDocument();
    expect(screen.queryByText("Write Community")).not.toBeInTheDocument();
    expect(screen.queryByText("Auth Protocol")).not.toBeInTheDocument();
    expect(screen.queryByText("Priv Protocol")).not.toBeInTheDocument();
  });

  test("renders SNMP v3 with security level '2' (Auth / No Privacy) and shows Auth fields without Priv fields", () => {
    render(
      <SiteConfigViewProfile
        data={{
          snmpProfileName: "V3-AuthOnly",
          port: "161",
          retries: "3",
          timeout: "4",
          version: "3",
          securityLevel: "2",
          username: "authUser",
          contextName: "ctx1",
          authProtocol: "2",
          authPassword: "myAuthPassword",
        }}
      />
    );

    expect(getDisabledInputByLabel("Security Level")).toHaveValue(
      "Auth / No Privacy"
    );
    expect(getDisabledInputByLabel("USM User")).toHaveValue("authUser");
    expect(getDisabledInputByLabel("Auth Protocol")).toHaveValue("SHA");
    expect(getDisabledInputByLabel("Auth Password")).toHaveValue("myAuthPassword");

    expect(screen.queryByText("Priv Protocol")).not.toBeInTheDocument();
    expect(screen.queryByText("Private Password")).not.toBeInTheDocument();
  });

  test("renders SNMP v3 with security level '3' (Auth / Privacy) and maps Auth & Priv protocols (including fallbacks)", () => {
    const { rerender } = render(
      <SiteConfigViewProfile
        data={{
          snmpProfileName: "Core-V3-Priv",
          port: "161",
          retries: "2",
          timeout: "5",
          version: "3",
          securityLevel: "3",
          username: "privUser",
          contextName: "ctx2",
          authProtocol: "4",
          authPassword: "authSecret",
          privProtocol: "4",
          privPassword: "privSecret",
        }}
      />
    );

    expect(getDisabledInputByLabel("Security Level")).toHaveValue("Auth / Privacy");
    expect(getDisabledInputByLabel("Auth Protocol")).toHaveValue("SHA256");
    expect(getDisabledInputByLabel("Auth Password")).toHaveValue("authSecret");
    expect(getDisabledInputByLabel("Priv Protocol")).toHaveValue("AES256");
    expect(getDisabledInputByLabel("Private Password")).toHaveValue("privSecret");

    // Verify additional protocol mappings & fallback values
    rerender(
      <SiteConfigViewProfile
        data={{
          version: "3",
          securityLevel: "3",
          authProtocol: "6",
          privProtocol: "2",
        }}
      />
    );
    expect(getDisabledInputByLabel("Auth Protocol")).toHaveValue("SHA512");
    expect(getDisabledInputByLabel("Priv Protocol")).toHaveValue("AES128");

    rerender(
      <SiteConfigViewProfile
        data={{
          version: "3",
          securityLevel: "3",
          authProtocol: "99",
          privProtocol: "88",
        }}
      />
    );
    expect(getDisabledInputByLabel("Auth Protocol")).toHaveValue("99");
    expect(getDisabledInputByLabel("Priv Protocol")).toHaveValue("88");
  });
});