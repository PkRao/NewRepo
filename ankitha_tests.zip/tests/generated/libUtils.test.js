jest.mock('@/Pages/Rnmsdashboard/Topology/utils', () => ({ SEVERITY_COLOR: { major: '#e48087', minor: '#FAFC0B', warning: '#00FFFF', up: '#008000', offline: '#ff0000' } }));
import formatDate, {
  cn, formatDateTime, getIpMaskedValueAndPosition,
  getDeviceColor, getDeviceReachabilityColor, getDeviceReachabilityColorCnms,
  getDeviceStatusIndicator, getDeviceStatusIndicatorCnms,
  buildSearchText, fuzzyMatch, sanitizeLayoutKeys, convertSeconds,
  inputRestrict, restrict, syslogSeverityConfig, syslogFacilityMap,
} from "../../src/lib/utils";

const device = (stateId, overrides = {}) => ({
  imResourceType: { imResourceStateInfo: { resourceStateId: stateId } },
  ...overrides,
});

describe("general formatting helpers", () => {
  test("merges class names and formats date values", () => {
    expect(cn("p-2", "p-4", "text-sm")).toContain("p-4");
    expect(formatDateTime(null)).toBe("-");
    expect(formatDateTime("not-a-date")).toBe("not-a-date");
    expect(formatDateTime("2026-01-02T03:04:05")).toMatch(/^2026-01-02 /);
    expect(formatDate("2026-01-02T03:04:05")).toContain("02-Jan-2026");
  });

  test("masks IPv4 input and preserves cursor position", () => {
    expect(getIpMaskedValueAndPosition("192.168.1.1", 8, "old"))
      .toEqual({ maskedValue: "192.168.1.1", newCursorPosition: 8 });
    expect(getIpMaskedValueAndPosition("1..2.3.4.5", 4, "previous"))
      .toEqual({ maskedValue: "previous", newCursorPosition: 4 });
    expect(getIpMaskedValueAndPosition("1.1.1.256", 3, "previous"))
      .toEqual({ maskedValue: "previous", newCursorPosition: 3 });
    expect(getIpMaskedValueAndPosition("1.2.3.4.5", 2, "previous"))
      .toEqual({ maskedValue: "previous", newCursorPosition: 2 });
  });

  test("exposes syslog severity and facility mappings", () => {
    expect(syslogSeverityConfig[0].label).toBe("EMERGENCY");
    expect(syslogSeverityConfig[7].label).toBe("DEBUG");
    expect(syslogFacilityMap[0]).toBe("KERNEL");
    expect(syslogFacilityMap[88]).toBe("FTP");
  });
});

describe("device color helpers", () => {
  test("returns unmanaged and maintenance colors", () => {
    expect(getDeviceColor(device(2))).toBe("#9ca3af");
    expect(getDeviceColor(device(1, { isMaintainance: true }))).toBe("#b8860b");
    expect(getDeviceReachabilityColor(device(2))).toBe("#D3D3D3");
    expect(getDeviceReachabilityColor(device(1, { isMaintainance: true }))).toBe("#b8860b");
    expect(getDeviceReachabilityColorCnms(device(2))).toBe("#D3D3D3");
    expect(getDeviceReachabilityColorCnms(device(1, { isMaintainance: true }))).toBe("#b8860b");
  });

  test("handles discovered, undiscovered and reachability states", () => {
    expect(getDeviceColor(device(1, { isDiscovered: false }))).toBe("blue");
    expect(getDeviceColor(device(1, { isDiscovered: true, nePollingInfo: {} }))).toBe("green");
    expect(getDeviceColor(device(1, { isDiscovered: true, nePollingInfo: { isReachable: false } }))).toBe("red");
    expect(getDeviceReachabilityColor(device(1, { isDiscovered: false }))).toBe("#D3D3D3");
    expect(getDeviceReachabilityColor(device(1, { isDiscovered: true, nePollingInfo: { isReachable: false } }))).toBe("#ff0000");
    expect(getDeviceReachabilityColorCnms(device(1, { isDiscovered: true, isReachable: false }))).toBe("#ff0000");
    expect(getDeviceReachabilityColorCnms(device(1, { isDiscovered: true, isReachable: true }))).toBe("#008000");
  });

  test("maps polling severities to device colors", () => {
    expect(getDeviceColor(device(1, { isDiscovered: true, nePollingInfo: { isReachable: true, maxSeverity: -1 } }))).toBe("#008000");
    expect(getDeviceColor(device(1, { isDiscovered: true, nePollingInfo: { isReachable: true, maxSeverity: 0 } }))).toBe("#ff0000");
    expect(getDeviceColor(device(1, { isDiscovered: true, nePollingInfo: { isReachable: true, maxSeverity: 1 } }))).toBe("#FAFC0B");
    expect(getDeviceColor(device(1, { isDiscovered: true, nePollingInfo: { isReachable: true, maxSeverity: 2 } }))).toBe("#e48087");
    expect(getDeviceColor(device(1, { isDiscovered: true, nePollingInfo: { isReachable: true, maxSeverity: 99 } }))).toBe("#00FFFF");
  });

  test("returns status indicators for RNMS and CNMS states", () => {
    expect(getDeviceStatusIndicator(device(2))).toEqual({
      visible: true, color: "#D3D3D3", status: "unmanaged",
    });
    expect(getDeviceStatusIndicator(device(1, { isMaintainance: true })).status).toBe("no-alarm");
    expect(getDeviceStatusIndicator(device(1, { isDiscovered: false })).status).toBe("undiscovered");
    expect(getDeviceStatusIndicator(device(1, { isDiscovered: true, nePollingInfo: { isReachable: true, maxSeverity: 2 } })).status).toBe("major");
    expect(getDeviceStatusIndicator(device(1, { isDiscovered: true, nePollingInfo: { isReachable: true, maxSeverity: 1 } })).status).toBe("minor");
    expect(getDeviceStatusIndicator(device(1, { isDiscovered: true, nePollingInfo: { isReachable: true, maxSeverity: 0 } })).status).toBe("no-alarm");
    expect(getDeviceStatusIndicator(device(1, { isDiscovered: true, nePollingInfo: { isReachable: true, maxSeverity: 55 } })).status).toBe("warning");
    expect(getDeviceStatusIndicatorCnms(device(1, { isDiscovered: true, maxSeverity: 2 })).status).toBe("major");
    expect(getDeviceStatusIndicatorCnms(device(1, { isDiscovered: true, maxSeverity: 0 })).status).toBe("no-alarm");
    expect(getDeviceStatusIndicatorCnms(device(9))).toEqual({
      visible: false, color: "transparent", status: "no-alarm",
    });
  });
});

describe("search, sanitizing and duration helpers", () => {
  test("builds lowercase search text and handles nullish values", () => {
    expect(buildSearchText({ name: "ROUTER", count: 12, empty: null, missing: undefined }))
      .toContain("router 12");
  });

  test("performs case-insensitive fuzzy matching in order", () => {
    expect(fuzzyMatch("Network Management System", "nms")).toBe(true);
    expect(fuzzyMatch("Network Management System", "xyz")).toBe(false);
    expect(fuzzyMatch("", "n")).toBe(false);
    expect(fuzzyMatch("abc", "")).toBe(false);
  });

  test("trims object keys and string values recursively", () => {
    expect(sanitizeLayoutKeys({
      " title ": " value ",
      children: [{ " name ": " node " }],
      count: 2,
    })).toEqual({
      title: "value",
      children: [{ name: "node" }],
      count: 2,
    });
    expect(sanitizeLayoutKeys(null)).toBeNull();
    expect(sanitizeLayoutKeys([" a ", " b "])).toEqual(["a", "b"]);
  });

  test("formats seconds in compact and verbose forms", () => {
    expect(convertSeconds(65, false)).toBe("00:00:1:5");
    expect(convertSeconds(3665, false)).toBe("00:1:1:5");
    expect(convertSeconds(90061, true)).toBe("1 days, 1 hours, 1 minutes, 1 seconds");
    expect(convertSeconds(5, false)).toBe("00:00:00:5");
  });
});

describe("input restriction helpers", () => {
  const makeEvent = (value, start = value.length, end = value.length) => {
    const target = {
      value,
      selectionStart: start,
      selectionEnd: end,
      setSelectionRange: jest.fn(),
    };
    return { target };
  };

  test("removes disallowed characters and adjusts the cursor", () => {
    const event = makeEvent("abc123", 6, 6);
    inputRestrict(event, /\D/g);
    expect(event.target.value).toBe("123");
    expect(event.target.setSelectionRange).toHaveBeenCalledWith(3, 3);
  });

  test("supports common restrict presets", () => {
    const email = makeEvent("a b@c.com");
    restrict.email(email);
    expect(email.target.value).toBe("ab@c.com");
    const digits = makeEvent("12a34");
    restrict.digits(digits);
    expect(digits.target.value).toBe("1234");
    const host = makeEvent("192.168.a.1");
    restrict.host(host);
    expect(host.target.value).toBe("192.168..1");
  });
});
