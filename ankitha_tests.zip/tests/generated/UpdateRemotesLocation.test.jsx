import React from "react";
import { jest } from "@jest/globals";
import {
  render,
  screen,
  fireEvent,
  waitFor,
} from "@testing-library/react";
import { Provider } from "react-redux";
import { configureStore } from "@reduxjs/toolkit";

// --------------------------------------------------
// ESM-compatible mocks
// These must be registered before importing the component.
// --------------------------------------------------

const mockInventoryAxios = jest.fn();
const mockToast = jest.fn();

jest.unstable_mockModule("@/RestAPI/api/axiosApicall", () => ({
  InventoryAxios: mockInventoryAxios,
}));

jest.unstable_mockModule(
  "@/components/Reusable/Toast/Toast",
  () => ({
    __esModule: true,
    default: mockToast,
  })
);

jest.unstable_mockModule(
  "@/assets/SVGIcons/Confirmation_icon.svg",
  () => ({
    __esModule: true,
    default: "Confirmation_icon.svg",
  })
);

// Mock MSelect
jest.unstable_mockModule(
  "@/components/Reusable/Select/MSelect",
  () => ({
    __esModule: true,
    default: ({ label, options = [], value, onChange, disabled }) => (
      <div>
        <label htmlFor={`select-${label}`}>{label}</label>

        <select
          id={`select-${label}`}
          aria-label={label}
          disabled={disabled}
          value={value?.value || value?.siteId || value?.terminalTypeName || ""}
          onChange={(event) => {
            const selectedOption = options.find(
              (option) => option.value === event.target.value
            );

            onChange(selectedOption || null);
          }}
        >
          <option value="">Select {label}</option>

          {options.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
      </div>
    ),
  })
);

// Mock MInput
jest.unstable_mockModule(
  "@/components/Reusable/Input/MInput",
  () => ({
    __esModule: true,
    default: ({
      label,
      value,
      onChange,
      disabled,
      error,
      errorMessage,
    }) => (
      <div>
        <input
          aria-label={label}
          value={value}
          onChange={onChange}
          disabled={disabled}
          aria-invalid={error}
        />

        {error && errorMessage && (
          <span role="alert">{errorMessage}</span>
        )}
      </div>
    ),
  })
);

// Mock MButtonPrimary
jest.unstable_mockModule(
  "@/components/Reusable/Button/MButtonPrimary",
  () => ({
    __esModule: true,
    default: ({ children, onClick, disabled }) => (
      <button onClick={onClick} disabled={disabled}>
        {children}
      </button>
    ),
  })
);

// Mock MDialog
jest.unstable_mockModule(
  "@/components/Reusable/Dialog/MDialog",
  () => ({
    __esModule: true,
    default: ({ open, onConfirm, title, onClose }) =>
      open ? (
        <div role="dialog" aria-label={title}>
          <button onClick={onConfirm}>Confirm Update</button>
          <button onClick={onClose}>Cancel</button>
        </div>
      ) : null,
  })
);

// --------------------------------------------------
// Dynamic imports AFTER registering ESM mocks
// --------------------------------------------------

const { default: UpdateRemotesLocation } = await import(
  "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/Configuration/Location/UpdateRemotesLocation"
);

const { default: remoteRepDetailsReducer } = await import(
  "@/store/features/Cnms/remoteRepDetails/remoteRepDetailsSlice"
);

const { default: nodeDetailsReducer } = await import(
  "@/store/features/nodeDetailsSlice"
);

// --------------------------------------------------
// Test store
// --------------------------------------------------

const createTestStore = (preloadedState) => {
  return configureStore({
    reducer: {
      nodeDetails: nodeDetailsReducer,
      remoteRepDetails: remoteRepDetailsReducer,
    },
    preloadedState,
  });
};

// --------------------------------------------------
// Test data
// --------------------------------------------------

const preloadedState = {
  nodeDetails: {
    allTerminalTypeDetails: [
      { terminalTypeName: "CNMS" },
      { terminalTypeName: "VSAT" },
      { terminalTypeName: "SCPC" },
    ],
  },

  remoteRepDetails: {
    fetchSiteDetails: [
      {
        siteId: "SITE-001",
        siteName: "Alpha Site",
        siteNickName: "Alpha",
        latitude: "12.971600",
        longitude: "77.594600",
        imTerminalType: {
          terminalTypeName: "VSAT",
        },
      },
      {
        siteId: "SITE-002",
        siteName: "Beta Site",
        siteNickName: "Beta",
        latitude: "13.082700",
        longitude: "80.270700",
        imTerminalType: {
          terminalTypeName: "SCPC",
        },
      },
    ],

    remoteRepDetails: [],
  },
};

// --------------------------------------------------
// Test cases
// --------------------------------------------------

describe("UpdateRemotesLocation Component", () => {
  let store;

  beforeEach(() => {
    jest.clearAllMocks();

    mockInventoryAxios.mockReset();
    mockToast.mockReset();

    store = createTestStore(preloadedState);
  });

  // 1. Render component and filter CNMS
  test("renders component correctly and filters out CNMS terminal option", () => {
    render(
      <Provider store={store}>
        <UpdateRemotesLocation isChildFullScreen={false} />
      </Provider>
    );

    expect(
      screen.getByText(/Longitude \(Dec\)/i)
    ).toBeInTheDocument();

    expect(
      screen.getByText(/Latitude \(Dec\)/i)
    ).toBeInTheDocument();

    const terminalSelect = screen.getByLabelText(/Terminal\*/i);

    expect(terminalSelect).toBeInTheDocument();

    expect(screen.queryByText("CNMS")).not.toBeInTheDocument();

    expect(screen.getByText("VSAT")).toBeInTheDocument();

    expect(screen.getByText("SCPC")).toBeInTheDocument();
  });

  // 2. Enable Site ID dropdown after terminal selection
  test("enables Site ID dropdown when a valid terminal is selected", () => {
    render(
      <Provider store={store}>
        <UpdateRemotesLocation isChildFullScreen={false} />
      </Provider>
    );

    const terminalSelect = screen.getByLabelText(/Terminal\*/i);

    const siteSelect = screen.getByLabelText(/Site ID\*/i);

    expect(siteSelect).toBeDisabled();

    fireEvent.change(terminalSelect, {
      target: {
        value: "VSAT",
      },
    });

    expect(siteSelect).not.toBeDisabled();

    expect(screen.getByText("SITE-001")).toBeInTheDocument();

    expect(screen.queryByText("SITE-002")).not.toBeInTheDocument();
  });

  // 3. Fetch site details successfully
  test("fetches site details successfully on site selection and populates inputs", async () => {
    mockInventoryAxios.mockResolvedValueOnce({
      data: {
        siteId: "SITE-001",
        siteName: "Alpha Site Updated",
        siteNickName: "Alpha Updated",
        latitude: "15.000000",
        longitude: "75.000000",
      },
    });

    render(
      <Provider store={store}>
        <UpdateRemotesLocation isChildFullScreen={false} />
      </Provider>
    );

    fireEvent.change(screen.getByLabelText(/Terminal\*/i), {
      target: {
        value: "VSAT",
      },
    });

    fireEvent.change(screen.getByLabelText(/Site ID\*/i), {
      target: {
        value: "SITE-001",
      },
    });

    await waitFor(() => {
      expect(mockInventoryAxios).toHaveBeenCalledWith(
        expect.stringContaining("/SITE-001"),
        "get"
      );
    });

    await waitFor(() => {
      expect(
        screen.getByLabelText(/Latitude \(Dec\)/i)
      ).toHaveValue("15.000000");

      expect(
        screen.getByLabelText(/Longitude \(Dec\)/i)
      ).toHaveValue("75.000000");
    });
  });

  // 4. Handle site fetch failure
  test("handles fetch site error gracefully and triggers Toast", async () => {
    mockInventoryAxios.mockRejectedValueOnce(
      new Error("Failed to load")
    );

    render(
      <Provider store={store}>
        <UpdateRemotesLocation isChildFullScreen={false} />
      </Provider>
    );

    fireEvent.change(screen.getByLabelText(/Terminal\*/i), {
      target: {
        value: "VSAT",
      },
    });

    fireEvent.change(screen.getByLabelText(/Site ID\*/i), {
      target: {
        value: "SITE-001",
      },
    });

    await waitFor(() => {
      expect(mockInventoryAxios).toHaveBeenCalledWith(
        expect.stringContaining("/SITE-001"),
        "get"
      );
    });

    await waitFor(() => {
      expect(mockToast).toHaveBeenCalledWith(
        "",
        "Failed to load",
        "error"
      );
    });
  });

  // 5. Validation and invalid input
  test("displays validation errors when invalid latitude or longitude are entered", async () => {
    render(
      <Provider store={store}>
        <UpdateRemotesLocation isChildFullScreen={false} />
      </Provider>
    );

    fireEvent.change(screen.getByLabelText(/Terminal\*/i), {
      target: {
        value: "VSAT",
      },
    });

    fireEvent.change(screen.getByLabelText(/Site ID\*/i), {
      target: {
        value: "SITE-001",
      },
    });

    const latitudeInput = screen.getByLabelText(/Latitude \(Dec\)/i);

    fireEvent.change(latitudeInput, {
      target: {
        value: "invalid",
      },
    });

    const updateButton = screen.getByRole("button", {
      name: /Update/i,
    });

    expect(updateButton).toBeDisabled();
  });

  // 6. Handle non-200 response during submission
  test("handles submission failure gracefully with error toast when API returns non-200 status", async () => {
    mockInventoryAxios
      .mockResolvedValueOnce({
        data: {
          siteId: "SITE-001",
          siteName: "Alpha Site",
          siteNickName: "Alpha",
          latitude: "12.971600",
          longitude: "77.594600",
        },
      })
      .mockResolvedValueOnce({
        status: 400,
        data: null,
      });

    render(
      <Provider store={store}>
        <UpdateRemotesLocation isChildFullScreen={false} />
      </Provider>
    );

    fireEvent.change(screen.getByLabelText(/Terminal\*/i), {
      target: {
        value: "VSAT",
      },
    });

    fireEvent.change(screen.getByLabelText(/Site ID\*/i), {
      target: {
        value: "SITE-001",
      },
    });

    await waitFor(() => {
      expect(mockInventoryAxios).toHaveBeenCalledTimes(1);
    });

    const latitudeInput = screen.getByLabelText(/Latitude \(Dec\)/i);

    fireEvent.change(latitudeInput, {
      target: {
        value: "14.0000",
      },
    });

    const updateButton = screen.getByRole("button", {
      name: /Update/i,
    });

    expect(updateButton).not.toBeDisabled();

    fireEvent.click(updateButton);

    fireEvent.click(
      screen.getByRole("button", {
        name: /Confirm Update/i,
      })
    );

    await waitFor(() => {
      expect(mockInventoryAxios).toHaveBeenCalledTimes(2);
    });

    await waitFor(() => {
      expect(mockToast).toHaveBeenCalledWith(
        "",
        "Failed to update location",
        "error"
      );
    });
  });

  // 7. Handle API exception during submission
  test("handles catch block errors during submission gracefully", async () => {
    mockInventoryAxios
      .mockResolvedValueOnce({
        data: {
          siteId: "SITE-001",
          siteName: "Alpha Site",
          siteNickName: "Alpha",
          latitude: "12.971600",
          longitude: "77.594600",
        },
      })
      .mockRejectedValueOnce(
        new Error("Server down")
      );

    render(
      <Provider store={store}>
        <UpdateRemotesLocation isChildFullScreen={false} />
      </Provider>
    );

    fireEvent.change(screen.getByLabelText(/Terminal\*/i), {
      target: {
        value: "VSAT",
      },
    });

    fireEvent.change(screen.getByLabelText(/Site ID\*/i), {
      target: {
        value: "SITE-001",
      },
    });

    await waitFor(() => {
      expect(mockInventoryAxios).toHaveBeenCalledTimes(1);
    });

    const latitudeInput = screen.getByLabelText(/Latitude \(Dec\)/i);

    fireEvent.change(latitudeInput, {
      target: {
        value: "14.0000",
      },
    });

    const updateButton = screen.getByRole("button", {
      name: /Update/i,
    });

    expect(updateButton).not.toBeDisabled();

    fireEvent.click(updateButton);

    fireEvent.click(
      screen.getByRole("button", {
        name: /Confirm Update/i,
      })
    );

    await waitFor(() => {
      expect(mockInventoryAxios).toHaveBeenCalledTimes(2);
    });

    await waitFor(() => {
      expect(mockToast).toHaveBeenCalledWith(
        "",
        "Something went wrong",
        "error"
      );
    });
  });
});
