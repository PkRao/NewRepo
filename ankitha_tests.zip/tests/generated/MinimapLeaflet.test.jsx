import React from "react";
import { jest } from "@jest/globals";
import { render, screen, act } from "@testing-library/react";

const mockParentMap = {
  getBounds: jest.fn(() => "parent-bounds"),
  getZoom: jest.fn(() => 5),
  getCenter: jest.fn(() => [19.076, 72.8777]),
  setView: jest.fn(),
};

const mockMinimapMap = {
  setView: jest.fn(),
};

const MapContext = React.createContext(null);

globalThis.mockMinimapClickHandler = undefined;
globalThis.mockMinimapEventHandlers = undefined;

jest.unstable_mockModule("react-leaflet", () => ({
  MapProvider: ({ children, value }) => (
    <MapContext.Provider value={value}>{children}</MapContext.Provider>
  ),

  useMap: () => React.useContext(MapContext),

  useMapEvent: jest.fn((event, callback) => {
    if (event === "click") {
      globalThis.mockMinimapClickHandler = callback;
    }
  }),

  MapContainer: ({ children, ...props }) => (
    <MapContext.Provider value={mockMinimapMap}>
      <div data-testid="map-container" data-zoom={props.zoom}>
        {children}
      </div>
    </MapContext.Provider>
  ),

  TileLayer: (props) => <div data-testid="tile-layer" data-url={props.url} />,

  WMSTileLayer: (props) => (
    <div data-testid="wms-tile-layer" data-layers={props.layers} />
  ),

  Rectangle: (props) => (
    <div data-testid="rectangle" data-dragging={String(props.dragging)} />
  ),
}));

jest.unstable_mockModule("@react-leaflet/core", () => ({
  useEventHandlers: jest.fn((instance, handlers) => {
    globalThis.mockMinimapEventHandlers = handlers;
  }),
}));

jest.unstable_mockModule("@/RestAPI/url/baseUrl", () => ({
  GEO_SERVER_MAP_VIEW_URL: "https://example.com/geoserver",
}));

const { MapProvider } = await import("react-leaflet");
const { MinimapLeaflet } = await import(
  "../../src/Pages/CnmsDashboard/CnmsMap/components/MinimapLeaflet"
);

const renderMinimap = () =>
  render(
    <MapProvider value={mockParentMap}>
      <MinimapLeaflet />
    </MapProvider>
  );

describe("MinimapLeaflet", () => {
  beforeEach(() => {
    jest.clearAllMocks();

    globalThis.mockMinimapClickHandler = undefined;
    globalThis.mockMinimapEventHandlers = undefined;

    mockParentMap.getBounds.mockReturnValue("parent-bounds");
    mockParentMap.getZoom.mockReturnValue(5);
    mockParentMap.getCenter.mockReturnValue([19.076, 72.8777]);

    window.L = {
      CRS: {
        EPSG4326: {
          code: "EPSG:4326",
        },
      },
    };
  });

  afterAll(() => {
    delete window.L;
    delete globalThis.mockMinimapClickHandler;
    delete globalThis.mockMinimapEventHandlers;
  });

  test("renders minimap container", () => {
    renderMinimap();

    expect(screen.getByTestId("map-container")).toBeInTheDocument();
  });

  test("renders leaflet top right wrapper", () => {
    const { container } = renderMinimap();

    expect(
      container.querySelector(".leaflet-top.leaflet-right")
    ).toBeInTheDocument();
  });

  test("renders leaflet control bar", () => {
    const { container } = renderMinimap();

    expect(
      container.querySelector(".leaflet-control.leaflet-bar")
    ).toBeInTheDocument();
  });

  test("renders TileLayer", () => {
    renderMinimap();

    expect(screen.getByTestId("tile-layer")).toHaveAttribute(
      "data-url",
      "https://example.com/geoserver"
    );
  });

  test("renders WMS TileLayer", () => {
    renderMinimap();

    expect(screen.getByTestId("wms-tile-layer")).toHaveAttribute(
      "data-layers",
      "MCT_LSV_GIS:MCT_LSV_Map"
    );
  });

  test("renders rectangle with dragging enabled", () => {
    renderMinimap();

    expect(screen.getByTestId("rectangle")).toHaveAttribute(
      "data-dragging",
      "true"
    );
  });

  test("initializes parent map center and zoom", () => {
    renderMinimap();

    expect(mockParentMap.getCenter).toHaveBeenCalled();
    expect(mockParentMap.getZoom).toHaveBeenCalled();
  });

  test("initializes parent map bounds", () => {
    renderMinimap();

    expect(mockParentMap.getBounds).toHaveBeenCalled();
  });

  test("registers minimap click handler", () => {
    renderMinimap();

    expect(globalThis.mockMinimapClickHandler).toEqual(expect.any(Function));
  });

  test("updates parent map when minimap is clicked", () => {
    renderMinimap();

    act(() => {
      globalThis.mockMinimapClickHandler({
        latlng: {
          lat: 19.076,
          lng: 72.8777,
        },
      });
    });

    expect(mockParentMap.setView).toHaveBeenCalledWith(
      {
        lat: 19.076,
        lng: 72.8777,
      },
      5
    );
  });

  test("registers parent map move and zoom handlers", () => {
    renderMinimap();

    expect(globalThis.mockMinimapEventHandlers).toEqual(
      expect.objectContaining({
        move: expect.any(Function),
        zoom: expect.any(Function),
      })
    );
  });

  test("updates bounds when parent map moves", () => {
    renderMinimap();

    expect(globalThis.mockMinimapEventHandlers).toBeDefined();

    act(() => {
      globalThis.mockMinimapEventHandlers.move();
    });

    expect(mockParentMap.getBounds).toHaveBeenCalled();
    expect(mockParentMap.getCenter).toHaveBeenCalled();
  });

  test("updates bounds when parent map zooms", () => {
    renderMinimap();

    act(() => {
      globalThis.mockMinimapEventHandlers.zoom();
    });

    expect(mockParentMap.getBounds).toHaveBeenCalled();
  });

  test("handles zoom level found in supported zoom array", () => {
    mockParentMap.getZoom.mockReturnValue(8);

    renderMinimap();

    expect(screen.getByTestId("map-container")).toHaveAttribute(
      "data-zoom",
      "5"
    );
  });

  test("handles unsupported parent zoom level", () => {
    mockParentMap.getZoom.mockReturnValue(25);

    renderMinimap();

    expect(screen.getByTestId("map-container")).toBeInTheDocument();
  });

  test("uses EPSG4326 projection", () => {
    renderMinimap();

    expect(window.L.CRS.EPSG4326.code).toBe("EPSG:4326");
  });
});
