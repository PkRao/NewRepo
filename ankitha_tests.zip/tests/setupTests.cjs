require('@testing-library/jest-dom');

const { TextEncoder, TextDecoder } = require('node:util');

globalThis.TextEncoder = TextEncoder;
globalThis.TextDecoder = TextDecoder;

globalThis.__VITE_ENV__ = {
  VITE_APP_INVENTORY: 'http://localhost:8080',
  VITE_APP_SECURITY: 'http://localhost:8080',
  VITE_APP_AUTH: 'http://localhost:8080',
  VITE_APP_FAULT: 'http://localhost:8080',
  VITE_APP_REPORT: 'http://localhost:8080',
  VITE_APP_NMS: 'http://localhost:8080',
  MODE: 'test',
  DEV: true,
  PROD: false,
  BASE_URL: '/',
};
