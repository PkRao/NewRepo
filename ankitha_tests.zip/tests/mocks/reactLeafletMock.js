const React = require('react');

const MockContainer = ({ children, ...props }) =>
  React.createElement('div', { 'data-testid': 'react-leaflet-mock', ...props }, children);

const noop = () => undefined;
const useMap = () => ({
  setView: noop,
  fitBounds: noop,
  invalidateSize: noop,
  flyTo: noop,
  getZoom: () => 10,
  getCenter: () => ({ lat: 0, lng: 0 }),
  on: noop,
  off: noop,
});
const useMapEvents = () => useMap();

module.exports = {
  MapContainer: MockContainer,
  TileLayer: MockContainer,
  WMSTileLayer: MockContainer,
  Marker: MockContainer,
  Popup: MockContainer,
  Tooltip: MockContainer,
  GeoJSON: MockContainer,
  Circle: MockContainer,
  CircleMarker: MockContainer,
  FeatureGroup: MockContainer,
  LayersControl: Object.assign(MockContainer, {
    BaseLayer: MockContainer,
    Overlay: MockContainer,
  }),
  ScaleControl: MockContainer,
  ZoomControl: MockContainer,
  Pane: MockContainer,
  useMap,
  useMapEvents,
};
