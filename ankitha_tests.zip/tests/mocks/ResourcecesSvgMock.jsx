export const ResourcesSVG = () => null;
