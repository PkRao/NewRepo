const path = require("path");

module.exports = {
  __esModule: true,
  default: "mock-svg",
};
