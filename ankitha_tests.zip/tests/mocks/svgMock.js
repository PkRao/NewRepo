module.exports = "mock-svg";
